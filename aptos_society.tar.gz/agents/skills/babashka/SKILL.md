---
name: babashka
description: Execute Clojure code via Babashka, a fast native Clojure interpreter. Use for scripting, data processing, and leveraging Clojure's functional programming capabilities. Great for quick one-liners and data transformations.
compatibility: Requires Babashka (bb) installed. Available via brew on macOS.
---

# Babashka Clojure Scripting

Execute Clojure code through Babashka MCP server.

## When to Use

- Quick Clojure scripting without JVM startup
- Data transformations with Clojure's powerful core library
- Functional programming tasks
- Processing text/data streams
- One-liner utilities

## Setup

MCP server configured in `~/.mcp.json`:
```json
{
  "babashka": {
    "command": "node",
    "args": ["/Users/alice/babashka-mcp-server/build/index.js"]
  }
}
```

Babashka is installed at: `/Users/alice/.flox/run/aarch64-darwin.default.run/bin/bb`

## Tool: execute

Execute Babashka code with optional timeout:

```json
{
  "name": "execute",
  "arguments": {
    "code": "(+ 1 2 3)",
    "timeout": 5000
  }
}
```

## Example Usage

### Basic Math
```clojure
(+ 1 2 3)
;; => 6
```

### String Processing
```clojure
(defn hello [x] (str "Hello, " x "!"))
(hello "World")
;; => "Hello, World!"
```

### Data Transformation
```clojure
(->> [1 2 3 4 5]
     (filter odd?)
     (map #(* % %))
     (reduce +))
;; => 35
```

### File Operations
```clojure
(slurp "/path/to/file.txt")
```

### JSON Processing
```clojure
(require '[cheshire.core :as json])
(json/parse-string "{\"name\": \"alice\"}" true)
;; => {:name "alice"}
```

## Important: Tail Call Optimization

Use `recur` for tail-recursive functions:

```clojure
;; BAD - will stack overflow
(defn countdown [n]
  (if (zero? n) :done (countdown (dec n))))

;; GOOD - uses recur
(defn countdown [n]
  (if (zero? n) :done (recur (dec n))))
```

## Resources

Command history accessible via: `babashka://commands/{index}`

## Useful Libraries

Available in Babashka:
- `clojure.string` - String manipulation
- `clojure.java.io` - File I/O
- `clojure.edn` - EDN parsing
- `cheshire` - JSON processing
- `babashka.fs` - Filesystem utilities
