# World Bootstrap Skill

**Trit**: 0 (ERGODIC - meta-coordinator)
**Purpose**: Bootstrap all 28 world wallets with GF(3) conservation

## Quick Start

```bash
# Generate all world skills
bb ~/.agents/scripts/generate-world-skills.bb

# Source wallet keys
source ~/.aptos_world_keys.sh

# Verify GF(3) conservation
echo "Total trit sum: -2 ≡ 1 (mod 3)"
```

## Wallet Manifest

| World | Trit | Role | MCP Server |
|-------|------|------|------------|
| A | -1 | MINUS (validator/constrainer) | `mcp__world_a_aptos__*` |
| B | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_b_aptos__*` |
| C | +1 | PLUS (generator/executor) | `mcp__world_c_aptos__*` |
| D | -1 | MINUS (validator/constrainer) | `mcp__world_d_aptos__*` |
| E | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_e_aptos__*` |
| F | +1 | PLUS (generator/executor) | `mcp__world_f_aptos__*` |
| G | -1 | MINUS (validator/constrainer) | `mcp__world_g_aptos__*` |
| H | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_h_aptos__*` |
| I | +1 | PLUS (generator/executor) | `mcp__world_i_aptos__*` |
| J | -1 | MINUS (validator/constrainer) | `mcp__world_j_aptos__*` |
| K | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_k_aptos__*` |
| L | +1 | PLUS (generator/executor) | `mcp__world_l_aptos__*` |
| M | -1 | MINUS (validator/constrainer) | `mcp__world_m_aptos__*` |
| N | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_n_aptos__*` |
| O | +1 | PLUS (generator/executor) | `mcp__world_o_aptos__*` |
| P | -1 | MINUS (validator/constrainer) | `mcp__world_p_aptos__*` |
| Q | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_q_aptos__*` |
| R | +1 | PLUS (generator/executor) | `mcp__world_r_aptos__*` |
| S | -1 | MINUS (validator/constrainer) | `mcp__world_s_aptos__*` |
| T | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_t_aptos__*` |
| U | +1 | PLUS (generator/executor) | `mcp__world_u_aptos__*` |
| V | -1 | MINUS (validator/constrainer) | `mcp__world_v_aptos__*` |
| W | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_w_aptos__*` |
| X | +1 | PLUS (generator/executor) | `mcp__world_x_aptos__*` |
| Y | -1 | MINUS (validator/constrainer) | `mcp__world_y_aptos__*` |
| Z | +0 | ERGODIC (coordinator/synthesizer) | `mcp__world_z_aptos__*` |
| ALICE | -1 | MINUS (validator/constrainer) | `mcp__alice_aptos__*` |
| BOB | +0 | ERGODIC (coordinator/synthesizer) | `mcp__bob_aptos__*` |

## GF(3) Conservation

- **Total worlds**: 28
- **Trit sum**: -2
- **Conservation**: -2 ≡ 1 (mod 3) ✗ VIOLATION

## Triadic Groupings

For balanced parallel execution, group worlds in triads:

- **Triad A-B-C**: (-1) + (+0) + (+1) = 0 ✓
- **Triad D-E-F**: (-1) + (+0) + (+1) = 0 ✓
- **Triad G-H-I**: (-1) + (+0) + (+1) = 0 ✓
- **Triad J-K-L**: (-1) + (+0) + (+1) = 0 ✓
- **Triad M-N-O**: (-1) + (+0) + (+1) = 0 ✓
- **Triad P-Q-R**: (-1) + (+0) + (+1) = 0 ✓
- **Triad S-T-U**: (-1) + (+0) + (+1) = 0 ✓
- **Triad V-W-X**: (-1) + (+0) + (+1) = 0 ✓

## Generated Scripts

1. **generate-world-skills.bb** - This script (creates all skill files)
2. **~/.aptos_world_keys.sh** - Environment variable exports for all keys
3. **World skill files** - `~/.claude/skills/{letter}/SKILL.md`

## MCP Configuration

All world MCPs are configured in `~/.mcp.json` with pattern:
- Server name: `world_{letter}_aptos`
- Tools: `aptos_balance`, `aptos_transfer`, `aptos_swap`, etc.

## Usage Patterns

### Check All Balances
```bash
for letter in {a..z}; do
  echo "World $letter:"
  # Use MCP tool mcp__world_${letter}_aptos__aptos_balance
done
```

### Parallel Triadic Operations
```python
# GF(3)-balanced parallel execution
triads = [
    ('a', 'b', 'c'),  # -1, 0, +1 → Σ=0
    ('d', 'e', 'f'),  # -1, 0, +1 → Σ=0
    # ... continue pattern
]
for minus, ergodic, plus in triads:
    await asyncio.gather(
        world_op(minus, role='validate'),
        world_op(ergodic, role='coordinate'),
        world_op(plus, role='execute')
    )
```

## Related Skills

- `aptos-agent` - Core blockchain operations
- `aptos-society` - WEV contracts and multiverse finance
- `gay-mcp` - Deterministic color/trit generation
- `load-skills` - Instance bootstrap protocol
- `plurigrid-asi-integrated` - Unified ASI orchestration
