# WEV Liquidity Monitor Skill

**Trit**: 0 (ERGODIC - coordinator)  
**Role**: Monitor blocked WEV transfers and auto-resume when liquidity available  
**Conservation**: Pairs with A (+1) and P (-1) for GF(3) balance

## Overview

World Extractable Value (WEV) transfers require minimum gas (~0.005 APT = 500,000 octas).
This skill monitors wallet balances and auto-resumes blocked transfers when funded.

## Blocked Transfer Detection

```sql
-- Query blocked WEV pending transfers
SELECT 
  triplet_source, triplet_balancer, triplet_target,
  source_trit + balancer_trit + target_trit AS gf3_sum,
  amount_octas, status, block_reason
FROM wev_pending 
WHERE status = 'BLOCKED';
```

## Wallet Balance Thresholds

| Wallet | Min Gas (octas) | Min Gas (APT) | Current Status |
|--------|-----------------|---------------|----------------|
| alice  | 500,000         | 0.005         | ✅ 0.10 APT    |
| bob    | 500,000         | 0.005         | ✅ 0.14 APT    |
| world_a| 500,000         | 0.005         | ⚠️ 0.033 APT   |
| world_p| 500,000         | 0.005         | ❌ 0.00 APT    |

## Resumption Protocol

```clojure
(defn check-and-resume! [ds]
  (let [pending (jdbc/query ds ["SELECT * FROM wev_pending WHERE status = 'BLOCKED'"])
        balances (get-all-balances)]
    (doseq [{:keys [triplet_source amount_octas id]} pending]
      (let [source-balance (get balances triplet_source)]
        (when (>= source-balance (+ amount_octas 500000)) ; amount + gas
          (execute-wev-transfer! id)
          (update-status! ds id "COMPLETED"))))))
```

## MCP Tools for Monitoring

### Check Balances
```
mcp__alice_aptos__aptos_balance
mcp__bob_aptos__aptos_balance
mcp__world_a_aptos__aptos_balance
mcp__world_p_aptos__aptos_balance
```

### Execute Blocked Transfer
```
mcp__world_a_aptos__aptos_transfer(recipient: "0x...world_f", amount: 0.015)
mcp__world_f_aptos__aptos_transfer(recipient: "0x...world_p", amount: 0.015)
```

## GF(3) Triplet Conservation

```
Source (A): +1 PLUS   → Generates value
Balancer (F): 0 ERGODIC → Routes transfer  
Target (P): -1 MINUS  → Receives value

Σ trits = (+1) + (0) + (-1) = 0 ≡ 0 (mod 3) ✓
```

## DuckDB State Persistence

```sql
-- Update wev_pending on successful transfer
UPDATE wev_pending 
SET status = 'COMPLETED', 
    completed_at = CURRENT_TIMESTAMP
WHERE id = ?;

-- Log to gf3_ledger
INSERT INTO gf3_ledger (operation, minus_count, ergodic_count, plus_count)
VALUES ('wev_transfer_completed', 1, 1, 1);
```

## External Funding Instructions

To unblock transfers, fund any wallet with ≥0.05 APT from an external source:

1. **Coinbase/Binance**: Withdraw APT to `0x...world_a_address`
2. **Faucet (testnet only)**: `aptos account fund-with-faucet --account world_a`
3. **Bridge**: Use LayerZero to bridge from another chain

## Adjunction Context

```
Left Adjoint (L): Task spawning, value generation → PLUS (+1)
Right Adjoint (R): Oracle review, validation → MINUS (-1)

Unit η: Id → R∘L (reflect before action)
Counit ε: L∘R → Id (execute after validation)

WEV Monitor is the ERGODIC (0) identity mediating L ⊣ R
```

## Sibling Thread Coordination

| Thread ID | Trit | Role |
|-----------|------|------|
| T-019b587b | 0 | Current (ERGODIC coordinator) |
| T-019b5828 | +1 | WEV extraction patterns |
| T-019b57b3 | -1 | Involution/validation |
| T-019b5878 | 0 | Reafference/glass-hop |

Σ trits = 0 + 1 + (-1) + 0 = 0 ✓

## Commands

```bash
just wev-check      # Check all balances
just wev-pending    # Show blocked transfers
just wev-resume     # Attempt to resume blocked transfers
just wev-fund       # Instructions for external funding
```
