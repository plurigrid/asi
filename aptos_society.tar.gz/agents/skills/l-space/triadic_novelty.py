#!/usr/bin/env python3
"""
L-Space Triadic Token Novelty - 3-Level Likelihood System

Three levels of token probability:
  Level 1: P(token | conversation)   - Local context
  Level 2: P(token | training_data)  - Model priors  
  Level 3: P(token | ducklake)       - Persistent local knowledge

Adjusted novelty = weighted combination across all three levels

Usage:
    python triadic_novelty.py "text to analyze"
    python triadic_novelty.py -f file.txt --ducklake ~/.ducklake/knowledge.duckdb
"""

import argparse
import json
import math
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Iterator

# GF(3) constants
GAMMA = 0x9E3779B97F4A7C15
MIX = 0xBF58476D1CE4E5B9
MASK64 = 0xFFFFFFFFFFFFFFFF


@dataclass
class TriadicNovelty:
    """Token with 3-level novelty measurement"""
    token: str
    
    # Level 1: Conversation (local context)
    conv_logprob: float = 0.0
    conv_novelty: float = 0.0
    
    # Level 2: Training data (model priors)
    model_logprob: float = 0.0
    model_novelty: float = 0.0
    
    # Level 3: DuckLake (persistent local knowledge)
    lake_logprob: float = 0.0
    lake_novelty: float = 0.0
    
    # Derived
    adjusted_novelty: float = 0.0
    poincare_r: float = 0.0
    trit: int = 0  # -1 (center), 0 (interior), +1 (boundary)
    source: str = "unknown"  # Which level dominates
    
    def compute_adjusted(self, weights: tuple[float, float, float] = (0.4, 0.3, 0.3)):
        """
        Compute adjusted novelty as weighted difference.
        
        adjusted = conv_novelty - (w2 * model_novelty + w3 * lake_novelty)
        
        Positive = token surprising given what model+lake expect
        Negative = token common here but rare in model+lake (domain term)
        """
        w1, w2, w3 = weights
        expected_novelty = w2 * self.model_novelty + w3 * self.lake_novelty
        self.adjusted_novelty = self.conv_novelty - expected_novelty
        
        # Determine source (which level contributes most)
        novelties = [
            ("conversation", self.conv_novelty),
            ("model", self.model_novelty),
            ("ducklake", self.lake_novelty)
        ]
        self.source = min(novelties, key=lambda x: x[1])[0]  # Lowest novelty = most expected there
        
        # Poincaré radius from adjusted
        self.poincare_r = self._adjusted_to_poincare(self.adjusted_novelty)
        
        # GF(3) trit assignment
        if self.poincare_r < 0.33:
            self.trit = -1  # CENTER: domain vocabulary
        elif self.poincare_r > 0.66:
            self.trit = 1   # BOUNDARY: contextually surprising
        else:
            self.trit = 0   # INTERIOR: normal
    
    def _adjusted_to_poincare(self, adj: float) -> float:
        """Map adjusted novelty to Poincaré radius [0.01, 0.99]"""
        r = 0.5 + adj / 30.0
        return max(0.01, min(0.99, r))
    
    def to_dict(self) -> dict:
        return {
            "token": self.token,
            "conv_novelty": round(self.conv_novelty, 3),
            "model_novelty": round(self.model_novelty, 3),
            "lake_novelty": round(self.lake_novelty, 3),
            "adjusted": round(self.adjusted_novelty, 3),
            "poincare_r": round(self.poincare_r, 3),
            "trit": self.trit,
            "source": self.source
        }


class DuckLakeContext:
    """Interface to DuckLake persistent knowledge base"""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or self._find_ducklake()
        self.conn = None
        self.token_freqs: dict[str, float] = {}
        self.total_tokens = 0
        
        if self.db_path:
            self._load()
    
    def _find_ducklake(self) -> Optional[str]:
        """Find DuckLake database in standard locations"""
        candidates = [
            Path.home() / ".ducklake" / "knowledge.duckdb",
            Path.home() / ".ducklake" / "context.duckdb",
            Path("/tmp") / "ducklake.duckdb",
            Path.cwd() / "ducklake.duckdb",
            Path.cwd() / "trit_stream.duckdb",  # agent-o-rama default
        ]
        for p in candidates:
            if p.exists():
                return str(p)
        return None
    
    def _load(self):
        """Load token frequencies from DuckLake"""
        try:
            import duckdb
            self.conn = duckdb.connect(self.db_path, read_only=True)
            
            # Try to find a token frequency table
            tables = self.conn.execute("SHOW TABLES").fetchall()
            table_names = [t[0] for t in tables]
            
            # Look for token/text tables
            for table in ["tokens", "token_freqs", "interactions", "events", "logs"]:
                if table in table_names:
                    self._extract_tokens_from_table(table)
                    break
            else:
                # Fallback: scan all text columns
                for table in table_names[:5]:  # Limit scan
                    self._extract_tokens_from_table(table)
                    
        except ImportError:
            print("DuckDB not available: pip install duckdb", file=sys.stderr)
        except Exception as e:
            print(f"DuckLake load error: {e}", file=sys.stderr)
    
    def _extract_tokens_from_table(self, table: str):
        """Extract token frequencies from a table's text columns"""
        try:
            # Get column info
            cols = self.conn.execute(f"DESCRIBE {table}").fetchall()
            text_cols = [c[0] for c in cols if 'char' in c[1].lower() or 'text' in c[1].lower()]
            
            for col in text_cols[:3]:  # Limit columns
                try:
                    rows = self.conn.execute(f"SELECT {col} FROM {table} LIMIT 10000").fetchall()
                    for row in rows:
                        if row[0]:
                            tokens = re.findall(r'\b\w+\b', str(row[0]).lower())
                            for t in tokens:
                                self.token_freqs[t] = self.token_freqs.get(t, 0) + 1
                                self.total_tokens += 1
                except:
                    pass
        except:
            pass
    
    def get_logprob(self, token: str) -> float:
        """Get log probability of token in DuckLake context"""
        token_lower = token.lower()
        if self.total_tokens == 0:
            return -20.0  # No data, assume rare
        
        freq = self.token_freqs.get(token_lower, 0)
        if freq == 0:
            return -20.0  # Never seen
        
        return math.log(freq / self.total_tokens)
    
    def has_data(self) -> bool:
        return self.total_tokens > 0


class ModelPriors:
    """Approximate model training data frequencies"""
    
    # Rough English unigram frequencies (top words)
    # From Brown corpus / Wikipedia
    ENGLISH_FREQS = {
        "the": 0.07, "be": 0.04, "to": 0.03, "of": 0.03, "and": 0.03,
        "a": 0.02, "in": 0.02, "that": 0.01, "have": 0.01, "i": 0.01,
        "it": 0.01, "for": 0.01, "not": 0.01, "on": 0.01, "with": 0.01,
        "he": 0.01, "as": 0.01, "you": 0.01, "do": 0.01, "at": 0.01,
        "this": 0.008, "but": 0.008, "his": 0.008, "by": 0.008, "from": 0.007,
        "they": 0.007, "we": 0.007, "say": 0.006, "her": 0.006, "she": 0.006,
        "or": 0.006, "an": 0.006, "will": 0.005, "my": 0.005, "one": 0.005,
        "all": 0.005, "would": 0.005, "there": 0.005, "their": 0.004,
    }
    
    # Default frequency for unknown words (Zipf's law tail)
    DEFAULT_FREQ = 1e-6
    
    @classmethod
    def get_logprob(cls, token: str) -> float:
        """Get log probability from model priors (English baseline)"""
        token_lower = token.lower()
        freq = cls.ENGLISH_FREQS.get(token_lower, cls.DEFAULT_FREQ)
        return math.log(freq)


def analyze_conversation(text: str) -> dict[str, float]:
    """Level 1: Token frequencies in this conversation"""
    tokens = re.findall(r'\b\w+\b', text.lower())
    freqs = Counter(tokens)
    total = len(tokens)
    
    logprobs = {}
    for tok in set(tokens):
        logprobs[tok] = math.log(freqs[tok] / total)
    
    return logprobs


def triadic_analyze(
    text: str,
    ducklake_path: Optional[str] = None,
    weights: tuple[float, float, float] = (0.4, 0.3, 0.3)
) -> dict:
    """
    Full triadic novelty analysis.
    
    Returns analysis with tokens positioned in L-Space based on
    which of the 3 levels explains them best.
    """
    # Level 1: Conversation
    conv_logprobs = analyze_conversation(text)
    
    # Level 2: Model priors
    model_priors = ModelPriors()
    
    # Level 3: DuckLake
    ducklake = DuckLakeContext(ducklake_path)
    
    # Tokenize
    tokens_raw = re.findall(r'\b\w+\b', text.lower())
    tokens_unique = list(dict.fromkeys(tokens_raw))  # Preserve order, dedupe
    
    results = []
    for tok in tokens_unique:
        tn = TriadicNovelty(token=tok)
        
        # Level 1: Conversation
        tn.conv_logprob = conv_logprobs.get(tok, -20.0)
        tn.conv_novelty = -tn.conv_logprob
        
        # Level 2: Model priors
        tn.model_logprob = model_priors.get_logprob(tok)
        tn.model_novelty = -tn.model_logprob
        
        # Level 3: DuckLake
        tn.lake_logprob = ducklake.get_logprob(tok)
        tn.lake_novelty = -tn.lake_logprob
        
        # Compute adjusted
        tn.compute_adjusted(weights)
        
        results.append(tn)
    
    # Sort by adjusted novelty (most surprising first)
    results.sort(key=lambda x: x.adjusted_novelty, reverse=True)
    
    # GF(3) check
    trit_sum = sum(t.trit for t in results)
    trit_dist = Counter(t.trit for t in results)
    
    # Find octavo territory (boundary) and domain vocabulary (center)
    boundary_tokens = [t for t in results if t.trit == 1]
    center_tokens = [t for t in results if t.trit == -1]
    
    # Source distribution
    source_dist = Counter(t.source for t in results)
    
    return {
        "levels": {
            "conversation": "Local context (this thread)",
            "model": "Training data priors (English baseline)",
            "ducklake": f"Persistent knowledge ({ducklake.db_path or 'not found'})"
        },
        "ducklake_has_data": ducklake.has_data(),
        "ducklake_tokens": ducklake.total_tokens,
        "weights": {"conversation": weights[0], "model": weights[1], "ducklake": weights[2]},
        "total_unique_tokens": len(results),
        "gf3": {
            "distribution": {"minus": trit_dist[-1], "ergodic": trit_dist[0], "plus": trit_dist[1]},
            "sum": trit_sum,
            "balanced": trit_sum % 3 == 0
        },
        "source_distribution": dict(source_dist),
        "boundary_tokens": [t.to_dict() for t in boundary_tokens[:10]],
        "center_tokens": [t.to_dict() for t in center_tokens[:10]],
        "all_tokens": [t.to_dict() for t in results]
    }


def trace_hallucination(token: str, result: dict) -> dict:
    """
    Trace where a specific token came from across the 3 levels.
    
    For debugging fabrications like "barton@plgd.cc"
    """
    for t in result["all_tokens"]:
        if t["token"] == token.lower():
            return {
                "token": token,
                "found": True,
                "analysis": t,
                "diagnosis": _diagnose(t)
            }
    
    # Token not in conversation - MAXIMUM SURPRISE
    return {
        "token": token,
        "found": False,
        "diagnosis": {
            "level": "OCTAVO_BOUNDARY",
            "explanation": "Token not present in any level - pure fabrication",
            "poincare_r": 0.99,
            "trit": 1,
            "recommendation": "MINUS validation was skipped"
        }
    }


def _diagnose(t: dict) -> dict:
    """Generate diagnosis for a token's origin"""
    if t["adjusted"] > 5:
        return {
            "level": "OCTAVO_BOUNDARY",
            "explanation": "Token far more surprising here than model+lake expect",
            "risk": "Possible confabulation - verify grounding"
        }
    elif t["adjusted"] < -5:
        return {
            "level": "DOMAIN_CENTER",
            "explanation": "Domain-specific vocabulary - common here, rare globally",
            "risk": "Low - grounded in local context"
        }
    else:
        return {
            "level": "INTERIOR",
            "explanation": "Normal token - matches expectations across levels",
            "risk": "Low"
        }


def main():
    parser = argparse.ArgumentParser(description="L-Space Triadic Token Novelty")
    parser.add_argument("text", nargs="?", help="Text to analyze")
    parser.add_argument("-f", "--file", help="Read text from file")
    parser.add_argument("--ducklake", help="Path to DuckLake database")
    parser.add_argument("--trace", help="Trace a specific token's origin")
    parser.add_argument("--json", action="store_true", help="Output JSON")
    parser.add_argument("-w", "--weights", default="0.4,0.3,0.3",
                        help="Weights for conv,model,lake (default: 0.4,0.3,0.3)")
    
    args = parser.parse_args()
    
    # Get text
    if args.file:
        with open(args.file) as f:
            text = f.read()
    elif args.text:
        text = args.text
    elif not sys.stdin.isatty():
        text = sys.stdin.read()
    else:
        parser.print_help()
        sys.exit(1)
    
    # Parse weights
    weights = tuple(float(w) for w in args.weights.split(","))
    
    # Analyze
    result = triadic_analyze(text, args.ducklake, weights)
    
    # Trace specific token if requested
    if args.trace:
        trace = trace_hallucination(args.trace, result)
        if args.json:
            print(json.dumps(trace, indent=2))
        else:
            print(f"\n=== TRACING TOKEN: '{args.trace}' ===")
            print(json.dumps(trace, indent=2))
        return
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("=" * 60)
        print("L-SPACE TRIADIC NOVELTY ANALYSIS")
        print("=" * 60)
        print(f"\nLevels:")
        for k, v in result["levels"].items():
            print(f"  {k}: {v}")
        
        print(f"\nDuckLake: {'✓ ' + str(result['ducklake_tokens']) + ' tokens' if result['ducklake_has_data'] else '✗ No data'}")
        
        print(f"\nGF(3) Balance:")
        print(f"  Distribution: {result['gf3']['distribution']}")
        print(f"  Sum: {result['gf3']['sum']} ({'balanced' if result['gf3']['balanced'] else 'UNBALANCED'})")
        
        print(f"\nSource Distribution: {result['source_distribution']}")
        
        print(f"\nBOUNDARY (surprising, r > 0.66):")
        for t in result["boundary_tokens"][:5]:
            print(f"  '{t['token']}': adj={t['adjusted']:+.2f}, src={t['source']}")
        
        print(f"\nCENTER (domain vocab, r < 0.33):")
        for t in result["center_tokens"][:5]:
            print(f"  '{t['token']}': adj={t['adjusted']:+.2f}, src={t['source']}")


if __name__ == "__main__":
    main()
