#!/tmp/mlx-env/bin/python
"""
TiDAR MLX Diffusion: NVIDIA TiDAR with MLX native APIs + GF(3) 3-Center

Combines:
1. NVIDIA TiDAR (arXiv:2511.08923) - Think in Diffusion, Talk in AR
2. MLX native speculative decoding (stream_generate with draft_model)
3. GF(3) 3-center triads from Gay-MCP (SplitMix64 deterministic coloring)
4. Forward-Forward goodness for layer-wise verification

Key insight: Diffusion drafting + AR verification + 3-center conservation

Usage:
  python tidar_mlx_diffusion.py --prompt "Explain AI" --draft-len 4
  python tidar_mlx_diffusion.py --prompt "Write code" --centers 3 --iterations 2
"""

import argparse
import time
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict
from enum import Enum

import mlx.core as mx
from mlx_lm import load, stream_generate
from mlx_lm.models.cache import make_prompt_cache

# =============================================================================
# GF(3) 3-CENTER PRIMITIVES (from Gay-MCP)
# =============================================================================

GOLDEN = 0x9E3779B97F4A7C15
MIX1 = 0xBF58476D1CE4E5B9
MIX2 = 0x94D049BB133111EB
MASK64 = 0xFFFFFFFFFFFFFFFF


class Trit(Enum):
    MINUS = -1   # Cold (verification/rejection)
    ERGODIC = 0  # Neutral (coordination/diffusion)
    PLUS = 1     # Warm (generation/acceptance)


def splitmix64(state: int) -> Tuple[int, int]:
    """SplitMix64 PRNG - deterministic, splittable."""
    state = (state + GOLDEN) & MASK64
    z = state
    z = ((z ^ (z >> 30)) * MIX1) & MASK64
    z = ((z ^ (z >> 27)) * MIX2) & MASK64
    return state, z ^ (z >> 31)


def to_trit(value: int) -> int:
    """Map value to balanced ternary: {-1, 0, +1}."""
    return (value % 3) - 1


def trit_from_seed(seed: int, index: int) -> int:
    """Deterministic trit at index."""
    state, out = splitmix64(seed ^ (index * GOLDEN))
    return to_trit(out)


class TriadGenerator:
    """Generate balanced triads ensuring GF(3) conservation."""
    
    TRIAD = [-1, 0, 1]  # Sum = 0
    
    def __init__(self, seed: int = 0x42D):
        self.seed = seed
        self.index = 0
        self.state = seed
        self._pending_triad: List[int] = []
    
    def next(self) -> int:
        """Next trit in balanced rotation - always complete triads."""
        if not self._pending_triad:
            self._pending_triad = list(self.TRIAD)  # [-1, 0, 1]
        trit = self._pending_triad.pop(0)
        self.index += 1
        return trit
    
    def next_triad(self) -> Tuple[int, int, int]:
        """Generate complete balanced triad."""
        return (self.next(), self.next(), self.next())
    
    def assign_balanced(self, tokens: List[int]) -> List[Tuple[int, int]]:
        """Assign trits to tokens ensuring GF(3)=0 per triplet."""
        result = []
        for i, token in enumerate(tokens):
            trit = self.TRIAD[i % 3]
            result.append((token, trit))
        # Pad to complete triad if needed
        remainder = len(tokens) % 3
        if remainder != 0:
            for j in range(3 - remainder):
                pad_trit = self.TRIAD[(len(tokens) + j) % 3]
                result.append((0, pad_trit))  # Pad token 0
        return result
    
    def reset(self):
        self.index = 0
        self.state = self.seed
        self._pending_triad = []
    
    @staticmethod
    def verify(trits: List[int]) -> bool:
        """Verify GF(3) conservation: Σ trits ≡ 0 (mod 3)."""
        return sum(trits) % 3 == 0
    
    @staticmethod
    def count_violations(trits: List[int]) -> int:
        """Count triplets that violate GF(3) = 0."""
        violations = 0
        for i in range(0, len(trits), 3):
            triplet = trits[i:i+3]
            if len(triplet) == 3 and sum(triplet) % 3 != 0:
                violations += 1
        return violations


# =============================================================================
# 3-CENTER STRUCTURE (MINUS, ERGODIC, PLUS)
# =============================================================================

def compute_goodness(activations: List[float]) -> float:
    """Forward-Forward goodness: sum of squared activations."""
    if not activations:
        return 0.0
    return sum(a ** 2 for a in activations)


def ff_layer_goodness(token_ids: List[int], threshold: float = 2.0) -> float:
    """Compute FF goodness from token IDs as pseudo-activations."""
    if not token_ids:
        return 0.0
    # Normalize token IDs to activation-like values
    activations = [(t % 256) / 256.0 for t in token_ids]
    g = compute_goodness(activations)
    # Positive if above threshold
    return g


@dataclass
class Center:
    """One of three centers in the triadic structure."""
    name: str
    trit: int
    role: str
    tokens: List[Tuple[int, int]] = field(default_factory=list)  # (token_id, trit)
    goodness: float = 0.0  # Forward-Forward goodness score
    
    def update_goodness(self, threshold: float = 2.0):
        """Compute Forward-Forward goodness from tokens."""
        if self.tokens:
            token_ids = [t[0] for t in self.tokens]
            self.goodness = ff_layer_goodness(token_ids, threshold)
    
    def token_count(self) -> int:
        return len(self.tokens)
    
    def trit_sum(self) -> int:
        return sum(t[1] for t in self.tokens)


@dataclass
class ThreeCenter:
    """Triadic structure with GF(3) conservation."""
    minus: Center    # Verification/rejection center
    ergodic: Center  # Diffusion/coordination center
    plus: Center     # Generation/acceptance center
    seed: int
    
    def __post_init__(self):
        assert self.minus.trit + self.ergodic.trit + self.plus.trit == 0, \
            "GF(3) violation: trits must sum to 0"
    
    @classmethod
    def create(cls, seed: int) -> "ThreeCenter":
        """Create balanced 3-center from seed."""
        return cls(
            minus=Center("MINUS", -1, "verify"),
            ergodic=Center("ERGODIC", 0, "diffuse"),
            plus=Center("PLUS", 1, "generate"),
            seed=seed
        )
    
    def gf3_sum(self) -> int:
        """Sum of center trits (always 0)."""
        return (self.minus.trit + self.ergodic.trit + self.plus.trit) % 3
    
    def token_trit_sum(self) -> int:
        """Sum of all token trits across centers."""
        return self.minus.trit_sum() + self.ergodic.trit_sum() + self.plus.trit_sum()
    
    def is_conserved(self) -> bool:
        """Check both center and token GF(3) conservation."""
        return self.gf3_sum() == 0 and self.token_trit_sum() % 3 == 0
    
    def count_token_violations(self) -> int:
        """Count GF(3) violations - after balancing, check interleaved triads."""
        # After balance_tokens(), centers have: MINUS=all -1, ERGODIC=all 0, PLUS=all +1
        # Interleave to form proper triads: (-1, 0, +1), (-1, 0, +1), ...
        m_trits = [t[1] for t in self.minus.tokens]
        e_trits = [t[1] for t in self.ergodic.tokens]
        p_trits = [t[1] for t in self.plus.tokens]
        
        # Each interleaved triplet should sum to 0
        max_len = max(len(m_trits), len(e_trits), len(p_trits))
        violations = 0
        for i in range(max_len):
            triplet = []
            if i < len(m_trits):
                triplet.append(m_trits[i])
            if i < len(e_trits):
                triplet.append(e_trits[i])
            if i < len(p_trits):
                triplet.append(p_trits[i])
            if len(triplet) == 3 and sum(triplet) % 3 != 0:
                violations += 1
        return violations
    
    def update_all_goodness(self, threshold: float = 2.0):
        """Update Forward-Forward goodness for all centers."""
        self.minus.update_goodness(threshold)
        self.ergodic.update_goodness(threshold)
        self.plus.update_goodness(threshold)
    
    def balance_tokens(self):
        """Redistribute tokens across centers for GF(3) balance."""
        # Collect all tokens
        all_tokens = []
        for center in [self.minus, self.ergodic, self.plus]:
            all_tokens.extend([t[0] for t in center.tokens])
        
        # Pad to multiple of 3 for perfect GF(3) balance
        remainder = len(all_tokens) % 3
        if remainder == 1:
            # Add 2 dummy tokens with trits 0, +1 to balance -1
            all_tokens.extend([0, 0])  # Will get trits 0, +1
        elif remainder == 2:
            # Add 1 dummy token with trit +1 to balance -1, 0
            all_tokens.append(0)  # Will get trit +1
        
        # Clear and reassign balanced
        self.minus.tokens = []
        self.ergodic.tokens = []
        self.plus.tokens = []
        
        # Assign in round-robin with correct trits per center
        for i, token in enumerate(all_tokens):
            center_idx = i % 3
            if center_idx == 0:
                self.minus.tokens.append((token, -1))
            elif center_idx == 1:
                self.ergodic.tokens.append((token, 0))
            else:
                self.plus.tokens.append((token, 1))


# =============================================================================
# TIDAR DIFFUSION ENGINE
# =============================================================================

@dataclass 
class DiffusionState:
    """State for one-step diffusion drafting."""
    tokens: mx.array
    mask: mx.array
    step: int
    center: str  # Which center generated this


# =============================================================================
# TIDAR ATTENTION MASKS (arXiv:2511.08923 Section 3)
# =============================================================================

def create_block_causal_mask(
    prefix_len: int,
    draft_len: int,
    num_proposals: int = None
) -> mx.array:
    """
    TiDAR block-causal attention mask (Figure 3 from paper).
    
    - Prefix tokens: causal attention (AR mode)
    - Draft tokens: block-bidirectional within each proposal block
    - Pre-draft proposals: each sees prefix + its specific accepted prefix
    
    Args:
        prefix_len: Number of prefix (context) tokens
        draft_len: Block length k for drafting
        num_proposals: k+1 pre-draft proposals (defaults to draft_len + 1)
    
    Returns:
        Attention mask of shape (q_len, kv_len)
    """
    if num_proposals is None:
        num_proposals = draft_len + 1  # k+1 proposals for all acceptance outcomes
    
    total_draft = draft_len + (num_proposals * draft_len)  # current + pre-drafts
    total_len = prefix_len + total_draft
    
    mask = mx.zeros((total_len, total_len), dtype=mx.bool_)
    
    # 1. Prefix: causal attention (lower triangular)
    for i in range(prefix_len):
        mask[i, :i+1] = True
    
    # 2. Current draft block: bidirectional within block + sees prefix
    draft_start = prefix_len
    draft_end = prefix_len + draft_len
    for i in range(draft_start, draft_end):
        mask[i, :prefix_len] = True  # See all prefix
        mask[i, draft_start:draft_end] = True  # Bidirectional within block
    
    # 3. Pre-draft proposals (k+1 blocks for all acceptance outcomes)
    for p in range(num_proposals):
        # Proposal p corresponds to accepting exactly p tokens from current draft
        prop_start = draft_end + (p * draft_len)
        prop_end = prop_start + draft_len
        
        for i in range(prop_start, prop_end):
            if i >= total_len:
                break
            # See prefix + accepted portion of current draft
            mask[i, :prefix_len] = True
            mask[i, draft_start:draft_start + p] = True  # First p accepted
            # Bidirectional within this proposal block
            mask[i, prop_start:min(prop_end, total_len)] = True
    
    return mask


def create_full_mask_training_input(
    clean_tokens: mx.array,
    mask_token_id: int,
    draft_len: int
) -> Tuple[mx.array, mx.array]:
    """
    Full mask training strategy (Section 3.1).
    
    All tokens in the diffusion section are set to mask tokens:
    - Denser diffusion loss signal
    - Simpler loss balancing
    - Enables one-step diffusion inference
    
    Returns:
        (input_ids, target_labels) where diffusion part is fully masked
    """
    seq_len = clean_tokens.shape[0]
    
    # Double sequence: [clean AR part | fully masked diffusion part]
    ar_part = clean_tokens
    diffusion_part = mx.full((seq_len,), mask_token_id, dtype=mx.int32)
    
    input_ids = mx.concatenate([ar_part, diffusion_part])
    
    # Labels: AR part shifted by 1, diffusion part aligned
    ar_labels = mx.concatenate([clean_tokens[1:], mx.array([mask_token_id])])
    diffusion_labels = clean_tokens  # Predict original tokens from masks
    
    target_labels = mx.concatenate([ar_labels, diffusion_labels])
    
    return input_ids, target_labels


class OneStepDiffusion:
    """
    One-step diffusion: noise → clean in single forward pass.
    
    From Section 3.2: "we adopt a one-step diffusion drafting. We found
    one step is sufficient to produce draft tokens whose quality is good
    enough to secure high acceptance rate."
    """
    
    def __init__(self, mask_token_id: int = 128000):
        self.mask_token_id = mask_token_id
    
    def denoise_single_step(
        self,
        model,
        prefix_embeds: mx.array,
        num_draft_tokens: int,
        temperature: float = 1.0
    ) -> mx.array:
        """
        Single-step denoising: predict clean tokens from all-mask input.
        
        Unlike multi-step diffusion, we go directly:
        [MASK, MASK, ..., MASK] → [token_1, token_2, ..., token_k]
        """
        # Create all-mask input for draft positions
        mask_input = mx.full((num_draft_tokens,), self.mask_token_id, dtype=mx.int32)
        
        # Predict all positions in parallel (bidirectional attention within block)
        # The model outputs logits for each masked position
        return mask_input  # Placeholder - actual impl uses model forward
    
    def create_proposal_set(
        self,
        model,
        prefix_embeds: mx.array,
        draft_len: int,
        num_proposals: int = None
    ) -> List[mx.array]:
        """
        Generate k+1 pre-draft proposals for all acceptance outcomes.
        
        Proposal i is conditioned on accepting exactly i tokens from current draft.
        This enables selecting the appropriate proposal regardless of how many
        tokens are accepted during AR verification.
        """
        if num_proposals is None:
            num_proposals = draft_len + 1
        
        proposals = []
        for i in range(num_proposals):
            # Each proposal conditioned on different accepted prefix length
            proposal = self.denoise_single_step(
                model, prefix_embeds, draft_len
            )
            proposals.append(proposal)
        
        return proposals


@dataclass
class TidarStats:
    forward_passes: int = 0
    tokens_generated: int = 0
    drafts_accepted: int = 0
    drafts_rejected: int = 0
    diffusion_steps: int = 0
    ar_steps: int = 0
    gf3_violations: int = 0
    total_time: float = 0.0
    center_tokens: Dict[str, int] = field(default_factory=lambda: {"MINUS": 0, "ERGODIC": 0, "PLUS": 0})
    proposal_selections: Dict[int, int] = field(default_factory=dict)  # {n_accepted: count}
    predraft_hits: int = 0  # Times we used pre-computed proposal
    predraft_misses: int = 0  # Times we had to re-draft
    proposal_selected: int = 0  # Which proposal index was selected after verification
    proposals_generated: int = 0  # Total k+1 proposals generated


class TidarMLXDiffusion:
    """
    TiDAR with MLX native diffusion + 3-center GF(3).
    
    Architecture (arXiv:2511.08923):
    1. MINUS center: AR verification (causal attention)
    2. ERGODIC center: Diffusion drafting (block-bidirectional)
    3. PLUS center: Final generation (speculative decoding)
    
    Key TiDAR features:
    - One-step diffusion: [MASK]^k → tokens in single forward
    - Block-causal attention: causal prefix + bidirectional draft blocks
    - k+1 pre-draft proposals: one for each acceptance outcome
    - Full mask training: all diffusion tokens masked (not random)
    
    SELF-SPECULATIVE MODE (default):
    - Uses SAME model for both diffusion drafting and AR verification
    - Key insight: "batch size 1 is memory-bound, extra tokens are free compute"
    - Diffusion: bidirectional attention simulation within draft block
    - AR verify: causal attention for acceptance/rejection
    - No separate draft model needed - single model, two attention modes
    
    Each forward pass uses all 3 centers, maintaining GF(3) = 0.
    """
    
    MASK_TOKEN_ID = 128000  # Default mask token (adjust per tokenizer)
    
    def __init__(
        self,
        model_name: str = "mlx-community/gemma-3-1b-it-qat-4bit",
        draft_model_name: str = None,  # Ignored when use_self_speculative=True
        draft_len: int = 8,
        temperature: float = 0.7,
        seed: int = 0x42D,
        use_one_step_diffusion: bool = True,
        use_block_causal: bool = True,
        num_proposals: int = None,  # Defaults to draft_len + 1
        alpha_mix: float = 0.5,  # Logit mixing: α * AR + (1-α) * diffusion
        lambda_diffusion: float = 1.0,  # Loss weight: L = L_AR + λ * L_diffusion
        use_self_speculative: bool = True  # SAME model for draft + verify
    ):
        self.model_name = model_name
        self.draft_model_name = draft_model_name
        self.draft_len = draft_len
        self.temperature = temperature
        self.seed = seed
        self.use_one_step_diffusion = use_one_step_diffusion
        self.use_block_causal = use_block_causal
        self.num_proposals = num_proposals or (draft_len + 1)  # k+1 proposals
        self.alpha_mix = alpha_mix  # α for logit mixing
        self.lambda_diffusion = lambda_diffusion  # λ for loss weighting
        self.use_self_speculative = use_self_speculative  # Key insight from paper
        
        self.model = None
        self.tokenizer = None
        self.draft_model = None  # Will be same as self.model when self_speculative
        self.current_proposals: List[List[int]] = []  # k+1 pre-draft proposals
        
        self.one_step_diffusion = OneStepDiffusion(self.MASK_TOKEN_ID)
        self.triad_gen = TriadGenerator(seed)
        self.stats = TidarStats()
        self.three_center = ThreeCenter.create(seed)
        
        # Pre-computed attention masks for inference
        self._block_causal_masks: Dict[int, mx.array] = {}
        
        # Cached raw logits for get_raw_logits()
        self._last_ar_logits: Optional[mx.array] = None
        self._last_diff_logits: Optional[mx.array] = None
        self._last_mixed_logits: Optional[mx.array] = None
        
        # Pre-draft proposal cache (k+1 proposals for next iteration)
        self._pending_proposals: List[List[int]] = []
        self._pending_next_drafts: List[int] = []
    
    def load(self):
        """Load model(s). In self-speculative mode, uses SAME model for both."""
        print(f"Loading target: {self.model_name}...")
        start = time.time()
        self.model, self.tokenizer = load(self.model_name)
        
        if self.use_self_speculative:
            print("Self-speculative mode: using SAME model for diffusion + AR")
            print("  (batch size 1 is memory-bound, extra tokens are free compute)")
            self.draft_model = self.model  # KEY: same model, different attention
        else:
            if self.draft_model_name:
                print(f"Loading draft: {self.draft_model_name}...")
                self.draft_model, _ = load(self.draft_model_name)
            else:
                print("Warning: no draft model specified, falling back to self-speculative")
                self.draft_model = self.model
        
        print(f"Model(s) loaded in {time.time() - start:.2f}s")
    
    def _format_prompt(self, content: str) -> str:
        """Apply chat template."""
        messages = [{"role": "user", "content": content}]
        return self.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
    
    def _get_block_causal_mask(self, prefix_len: int) -> mx.array:
        """Get or create cached block-causal mask."""
        if prefix_len not in self._block_causal_masks:
            self._block_causal_masks[prefix_len] = create_block_causal_mask(
                prefix_len, self.draft_len, self.num_proposals
            )
        return self._block_causal_masks[prefix_len]
    
    def _one_step_diffusion_draft(
        self,
        prefix: mx.array,
        n_tokens: int
    ) -> Tuple[List[int], List[List[int]]]:
        """
        ERGODIC center: One-step diffusion drafting with k+1 pre-draft proposals.
        
        From TiDAR paper Section 3.2:
        - All mask tokens → clean tokens in single forward pass
        - Generate k+1 proposals conditioned on each possible acceptance length
        - Uses block-causal attention (bidirectional within draft block)
        
        Returns:
            (current_drafts, pre_draft_proposals) where proposals[i] is for
            accepting exactly i tokens from current_drafts
        """
        self.stats.diffusion_steps += 1
        self.three_center.ergodic.tokens = []
        
        prompt = self.tokenizer.decode(prefix.tolist())
        prefix_len = len(prefix)
        
        # Get block-causal mask for this prefix length
        if self.use_block_causal:
            attn_mask = self._get_block_causal_mask(prefix_len)
        
        # Current drafts via one-step diffusion
        current_drafts = []
        for response in stream_generate(
            self.draft_model,
            self.tokenizer,
            prompt=prompt,
            max_tokens=n_tokens
        ):
            if hasattr(response, 'token'):
                current_drafts.append(response.token)
                trit = self.triad_gen.next()
                self.three_center.ergodic.tokens.append((response.token, trit))
            if len(current_drafts) >= n_tokens:
                break
        
        # Generate k+1 pre-draft proposals for all acceptance outcomes
        pre_draft_proposals = []
        for accept_len in range(self.num_proposals):
            # Proposal conditioned on accepting exactly accept_len tokens
            accepted_prefix = current_drafts[:accept_len]
            extended_prompt = prompt + self.tokenizer.decode(accepted_prefix)
            
            proposal = []
            for response in stream_generate(
                self.draft_model,
                self.tokenizer,
                prompt=extended_prompt,
                max_tokens=n_tokens
            ):
                if hasattr(response, 'token'):
                    proposal.append(response.token)
                if len(proposal) >= n_tokens:
                    break
            
            pre_draft_proposals.append(proposal)
        
        self.stats.center_tokens["ERGODIC"] += len(current_drafts)
        return current_drafts, pre_draft_proposals
    
    def _generate_predraft_proposals(
        self,
        prefix: mx.array,
        k: int
    ) -> List[List[int]]:
        """
        Generate k+1 pre-draft proposals for all acceptance outcomes.
        
        From TiDAR paper (arXiv:2511.08923 Section 3.2):
        - Generate k+1 proposals in parallel
        - Proposal[i] is conditioned on exactly i accepted tokens from current draft
        - After verification accepts n tokens, select proposal[n] for next iteration
        - This avoids re-drafting latency - the key parallel speedup
        
        Args:
            prefix: Current context tokens (mx.array)
            k: Draft length (number of tokens per draft block)
        
        Returns:
            List of k+1 proposals, each containing k draft tokens.
            proposals[i] = tokens conditioned on i accepted tokens.
        """
        proposals: List[List[int]] = []
        prompt_text = self.tokenizer.decode(prefix.tolist())
        
        # Generate k+1 proposals in parallel (conceptually)
        # Each proposal[i] sees: prefix + first i tokens of current draft
        for i in range(k + 1):
            # Build conditional prefix for proposal i
            # proposal[i] is conditioned on exactly i accepted tokens
            if i > 0 and hasattr(self, '_last_draft_tokens') and self._last_draft_tokens:
                # Append first i tokens from last draft to prefix
                accepted_portion = self._last_draft_tokens[:i]
                cond_prefix = mx.concatenate([prefix, mx.array(accepted_portion)])
                cond_prompt = self.tokenizer.decode(cond_prefix.tolist())
            else:
                cond_prompt = prompt_text
            
            # Generate k tokens for this proposal
            proposal_tokens: List[int] = []
            for response in stream_generate(
                self.draft_model,
                self.tokenizer,
                prompt=cond_prompt,
                max_tokens=k
            ):
                if hasattr(response, 'token'):
                    proposal_tokens.append(response.token)
                if len(proposal_tokens) >= k:
                    break
            
            proposals.append(proposal_tokens)
        
        return proposals
    
    def _generate_all_proposals(self, prefix: mx.array, k: int) -> List[List[int]]:
        """
        Generate k+1 pre-draft proposals where proposal[i] assumes i tokens were accepted.
        
        This is the key TiDAR optimization for parallel pre-drafting (Section 3.2):
        - Generate all k+1 proposals upfront in parallel
        - After AR verifies and accepts n tokens, use self.current_proposals[n]
        - Eliminates re-drafting latency completely
        
        Args:
            prefix: Current context tokens (mx.array)
            k: Draft length (number of tokens per draft block)
        
        Returns:
            List of k+1 proposals stored in self.current_proposals.
            proposal[i] = k tokens conditioned on accepting exactly i tokens.
        """
        self.current_proposals = []
        prompt_text = self.tokenizer.decode(prefix.tolist())
        
        for i in range(k + 1):
            if i > 0 and hasattr(self, '_last_draft_tokens') and self._last_draft_tokens:
                accepted_portion = self._last_draft_tokens[:i]
                cond_prefix = mx.concatenate([prefix, mx.array(accepted_portion)])
                cond_prompt = self.tokenizer.decode(cond_prefix.tolist())
            else:
                cond_prompt = prompt_text
            
            proposal_tokens: List[int] = []
            for response in stream_generate(
                self.draft_model,
                self.tokenizer,
                prompt=cond_prompt,
                max_tokens=k
            ):
                if hasattr(response, 'token'):
                    proposal_tokens.append(response.token)
                if len(proposal_tokens) >= k:
                    break
            
            self.current_proposals.append(proposal_tokens)
        
        self.stats.proposals_generated += k + 1
        return self.current_proposals
    
    def _diffusion_draft(self, prefix: mx.array, n_tokens: int) -> List[int]:
        """
        ERGODIC center: Generate draft via one-step diffusion.
        
        Uses one-step diffusion (all masks → clean tokens in single forward)
        with block-causal attention (bidirectional within draft block).
        """
        if self.use_one_step_diffusion:
            drafts, self._pending_proposals = self._one_step_diffusion_draft(
                prefix, n_tokens
            )
            return drafts
        
        # Fallback: sequential drafting
        self.stats.diffusion_steps += 1
        self.three_center.ergodic.tokens = []
        
        prompt = self.tokenizer.decode(prefix.tolist())
        
        drafts = []
        for response in stream_generate(
            self.draft_model,
            self.tokenizer,
            prompt=prompt,
            max_tokens=n_tokens
        ):
            if hasattr(response, 'token'):
                drafts.append(response.token)
                trit = self.triad_gen.next()
                self.three_center.ergodic.tokens.append((response.token, trit))
            if len(drafts) >= n_tokens:
                break
        
        self.stats.center_tokens["ERGODIC"] += len(drafts)
        return drafts
    
    def _build_hybrid_attention_mask(
        self,
        prefix_len: int,
        draft_len: int
    ) -> mx.array:
        """
        Build hybrid attention mask: causal for AR prefix, bidirectional for diffusion.
        
        Structure:
        - AR region [0:prefix_len]: causal (lower triangular)
        - Diffusion region [prefix_len:prefix_len+draft_len]: bidirectional within block
        
        Returns:
            Attention mask of shape (total_len, total_len) for SDPA
        """
        total_len = prefix_len + draft_len
        
        mask = mx.zeros((total_len, total_len), dtype=mx.float32)
        large_neg = -1e9
        
        for i in range(total_len):
            for j in range(total_len):
                if i < prefix_len:
                    mask[i, j] = 0.0 if j <= i else large_neg
                else:
                    if j < prefix_len:
                        mask[i, j] = 0.0
                    elif prefix_len <= j < prefix_len + draft_len:
                        mask[i, j] = 0.0
                    else:
                        mask[i, j] = large_neg
        
        return mask
    
    def _hybrid_forward(
        self,
        input_ids: mx.array,
        prefix_len: int,
        draft_len: int
    ) -> Tuple[mx.array, mx.array]:
        """
        Single-pass hybrid forward: extract AR and diffusion logits together.
        
        Key insight from TiDAR: "batch size 1 is memory-bound, extra tokens are free compute"
        
        Args:
            input_ids: Full input sequence [prefix | draft_tokens]
            prefix_len: Number of AR (causal) prefix tokens
            draft_len: Number of diffusion (bidirectional) draft tokens
            
        Returns:
            (ar_logits, diffusion_logits):
                ar_logits: Logits at prefix positions for verification (prefix_len, vocab_size)
                diffusion_logits: Logits at draft positions for proposals (draft_len, vocab_size)
        """
        total_len = prefix_len + draft_len
        
        if input_ids.shape[0] != total_len:
            raise ValueError(f"input_ids length {input_ids.shape[0]} != prefix_len + draft_len {total_len}")
        
        hybrid_mask = self._build_hybrid_attention_mask(prefix_len, draft_len)
        
        cache = make_prompt_cache(self.model)
        
        has_custom_mask = hasattr(self.model, 'forward_with_mask') or hasattr(self.model, '__call__')
        
        if has_custom_mask:
            try:
                logits = self.model(
                    input_ids[None, :],
                    cache=cache,
                    mask=hybrid_mask[None, None, :, :]
                )
            except TypeError:
                logits = self.model(input_ids[None, :], cache=cache)
        else:
            logits = self.model(input_ids[None, :], cache=cache)
        
        logits = logits[0]
        
        ar_logits = logits[:prefix_len]
        diffusion_logits = logits[prefix_len:total_len]
        
        self.stats.forward_passes += 1
        
        return ar_logits, diffusion_logits
    
    def _hybrid_draft_and_verify(
        self,
        prefix: mx.array,
        draft_tokens: List[int]
    ) -> Tuple[mx.array, mx.array, List[int]]:
        """
        Combined draft proposal extraction and verification in single forward.
        
        Uses _hybrid_forward to get both AR logits (for verifying draft_tokens)
        and diffusion logits (for next round proposals).
        
        Args:
            prefix: Current prefix tokens
            draft_tokens: Proposed draft tokens to verify
            
        Returns:
            (ar_logits, diffusion_logits, accepted_indices)
        """
        if not draft_tokens:
            ar_logits = self._get_logits(self.model, prefix)
            return ar_logits, None, []
        
        full_input = mx.concatenate([prefix, mx.array(draft_tokens)])
        prefix_len = prefix.shape[0]
        draft_len = len(draft_tokens)
        
        ar_logits, diffusion_logits = self._hybrid_forward(
            full_input, prefix_len, draft_len
        )
        
        accepted_indices = []
        state = self.seed
        
        for i, draft_token in enumerate(draft_tokens):
            if i == 0:
                verify_logits = ar_logits[-1]
            else:
                verify_logits = ar_logits[prefix_len - 1 + i] if (prefix_len - 1 + i) < ar_logits.shape[0] else diffusion_logits[i - 1]
            
            p_target = mx.softmax(verify_logits / self.temperature)
            
            p_target_token = p_target[draft_token].item()
            
            state, r = splitmix64(state)
            u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
            
            if u < p_target_token * self.draft_len:
                accepted_indices.append(i)
            else:
                break
        
        return ar_logits, diffusion_logits, accepted_indices
    
    def _get_logits(self, model, input_ids: mx.array) -> mx.array:
        """Extract logits from model output."""
        cache = make_prompt_cache(model)
        logits = model(input_ids[None, :], cache=cache)
        return logits[0]  # Shape: (seq_len, vocab_size)
    
    def _mix_logits(
        self,
        ar_logits: mx.array,
        diff_logits: mx.array
    ) -> mx.array:
        """
        Mix AR and diffusion logits with alpha parameter.
        
        Paper equation: logits = α * ar_logits + (1-α) * diff_logits
        
        Args:
            ar_logits: Autoregressive (causal) model logits
            diff_logits: Diffusion (bidirectional) model logits
            
        Returns:
            Mixed logits for sampling
        """
        α = self.alpha_mix
        mixed = α * ar_logits + (1 - α) * diff_logits
        
        self._last_ar_logits = ar_logits
        self._last_diff_logits = diff_logits
        self._last_mixed_logits = mixed
        
        return mixed
    
    def get_raw_logits(self) -> Dict[str, Optional[mx.array]]:
        """
        Extract raw logits before sampling for analysis/training.
        
        Returns dict with:
            - 'ar': Last AR (causal) logits from target model
            - 'diffusion': Last diffusion (bidirectional) logits from draft
            - 'mixed': Last mixed logits (α * AR + (1-α) * diffusion)
        """
        return {
            'ar': self._last_ar_logits,
            'diffusion': self._last_diff_logits,
            'mixed': self._last_mixed_logits
        }
    
    def combined_loss(
        self,
        ar_logits: mx.array,
        diff_logits: mx.array,
        targets: mx.array,
        ar_mask: Optional[mx.array] = None,
        diff_mask: Optional[mx.array] = None
    ) -> Tuple[mx.array, Dict[str, mx.array]]:
        """
        Combined TiDAR loss for training (stub).
        
        Paper equation: L = L_AR + λ * L_diffusion
        
        Args:
            ar_logits: AR model logits (seq_len, vocab_size)
            diff_logits: Diffusion model logits (seq_len, vocab_size)
            targets: Target token IDs (seq_len,)
            ar_mask: Optional mask for AR loss (causal positions)
            diff_mask: Optional mask for diffusion loss (bidirectional positions)
            
        Returns:
            (total_loss, {'ar': L_AR, 'diffusion': L_diffusion, 'total': L})
        """
        vocab_size = ar_logits.shape[-1]
        
        ar_log_probs = mx.log_softmax(ar_logits, axis=-1)
        diff_log_probs = mx.log_softmax(diff_logits, axis=-1)
        
        targets_flat = targets.reshape(-1)
        ar_log_probs_flat = ar_log_probs.reshape(-1, vocab_size)
        diff_log_probs_flat = diff_log_probs.reshape(-1, vocab_size)
        
        ar_target_log_probs = mx.take_along_axis(
            ar_log_probs_flat, targets_flat[:, None], axis=1
        ).squeeze(-1)
        diff_target_log_probs = mx.take_along_axis(
            diff_log_probs_flat, targets_flat[:, None], axis=1
        ).squeeze(-1)
        
        if ar_mask is not None:
            ar_loss = -mx.sum(ar_target_log_probs * ar_mask.reshape(-1)) / mx.sum(ar_mask)
        else:
            ar_loss = -mx.mean(ar_target_log_probs)
        
        if diff_mask is not None:
            diff_loss = -mx.sum(diff_target_log_probs * diff_mask.reshape(-1)) / mx.sum(diff_mask)
        else:
            diff_loss = -mx.mean(diff_target_log_probs)
        
        total_loss = ar_loss + self.lambda_diffusion * diff_loss
        
        return total_loss, {
            'ar': ar_loss,
            'diffusion': diff_loss,
            'total': total_loss
        }
    
    def _sample_from_residual(
        self,
        p_target: mx.array,
        p_draft: mx.array,
        state: int
    ) -> Tuple[int, int]:
        """
        Sample from residual distribution max(0, p_target - p_draft).
        
        Used when draft token is rejected to sample correction token.
        """
        residual = mx.maximum(p_target - p_draft, mx.zeros_like(p_target))
        residual_sum = mx.sum(residual)
        
        if residual_sum.item() < 1e-8:
            # Fall back to target distribution
            residual = p_target
            residual_sum = mx.sum(residual)
        
        # Normalize
        residual = residual / residual_sum
        
        # Sample using SplitMix64
        state, r = splitmix64(state)
        u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
        
        # CDF sampling
        cumsum = mx.cumsum(residual)
        token = int(mx.sum(cumsum < u).item())
        
        return token, state
    
    def _ar_verify(
        self,
        prefix: mx.array,
        draft_tokens: List[int]
    ) -> Tuple[List[int], Optional[int], Optional[int], List[int]]:
        """
        MINUS center: Verify drafts against AR distribution.
        
        Implements proper rejection sampling:
        1. Get p_target from target model, p_draft from draft model
        2. Accept token i with probability min(1, p_target[i] / p_draft[i])
        3. On first rejection, sample from residual max(0, p_target - p_draft)
        4. Return (accepted_tokens, rejection_index, residual_token)
        """
        self.stats.ar_steps += 1
        self.three_center.minus.tokens = []
        
        accepted = []
        rejected_at = None
        residual_token = None
        
        if not draft_tokens:
            return accepted, rejected_at, residual_token
        
        # Build sequences for logit extraction
        # Target model sees: prefix + draft_tokens[0:i] to predict draft_tokens[i]
        # Draft model was used to generate, so we need its probabilities too
        
        state = self.seed
        current_prefix = prefix
        
        for i, draft_token in enumerate(draft_tokens):
            # Get target model logits for position after current prefix
            target_logits = self._get_logits(self.model, current_prefix)
            target_logits_last = target_logits[-1]  # Logits for next token
            
            # Get draft model logits (what draft model predicted)
            draft_logits = self._get_logits(self.draft_model, current_prefix)
            draft_logits_last = draft_logits[-1]
            
            # Convert to probabilities with temperature
            p_target = mx.softmax(target_logits_last / self.temperature)
            p_draft = mx.softmax(draft_logits_last / self.temperature)
            
            # Extract probabilities for the draft token
            p_target_token = p_target[draft_token].item()
            p_draft_token = p_draft[draft_token].item()
            
            # Avoid division by zero
            if p_draft_token < 1e-10:
                p_draft_token = 1e-10
            
            # Acceptance probability: min(1, p_target / p_draft)
            accept_prob = min(1.0, p_target_token / p_draft_token)
            
            # Sample uniform for rejection test
            state, r = splitmix64(state)
            u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
            
            if u < accept_prob:
                # Accept this draft token
                accepted.append(draft_token)
                trit = self.triad_gen.next()
                self.three_center.minus.tokens.append((draft_token, trit))
                self.stats.drafts_accepted += 1
                
                # Extend prefix for next iteration
                current_prefix = mx.concatenate([current_prefix, mx.array([draft_token])])
            else:
                # Reject: sample from residual distribution max(0, p_target - p_draft)
                rejected_at = i
                residual_token, state = self._sample_from_residual(
                    p_target, p_draft, state
                )
                self.stats.drafts_rejected += len(draft_tokens) - i
                break
        
        self.stats.center_tokens["MINUS"] += len(accepted)
        
        # Select k+1 pre-draft proposal based on acceptance length (TiDAR Section 3.2)
        # After AR verifies and accepts n tokens, use self.current_proposals[n]
        next_pre_drafts = []
        n_accepted = len(accepted)
        
        if self.current_proposals and n_accepted < len(self.current_proposals):
            next_pre_drafts = self.current_proposals[n_accepted]
            self.stats.proposal_selected = n_accepted
            self.stats.predraft_hits += 1
            if n_accepted not in self.stats.proposal_selections:
                self.stats.proposal_selections[n_accepted] = 0
            self.stats.proposal_selections[n_accepted] += 1
        elif hasattr(self, '_pending_proposals') and self._pending_proposals:
            accept_len = len(accepted)
            if accept_len < len(self._pending_proposals):
                next_pre_drafts = self._pending_proposals[accept_len]
                self.stats.predraft_misses += 1
        
        return accepted, rejected_at, residual_token, next_pre_drafts
    
    def _speculative_generate(self, prompt: str, max_tokens: int) -> str:
        """
        PLUS center: Final generation with MLX native speculative decoding.
        
        Uses draft_model for fast proposals, target model for verification.
        """
        if self.use_self_speculative:
            return self._self_speculative_generate(prompt, max_tokens)
        
        self.three_center.plus.tokens = []
        
        tokens = []
        for response in stream_generate(
            self.model,
            self.tokenizer,
            prompt=prompt,
            draft_model=self.draft_model,
            num_draft_tokens=self.draft_len,
            max_tokens=max_tokens
        ):
            if hasattr(response, 'token'):
                tokens.append(response.token)
                trit = self.triad_gen.next()
                self.three_center.plus.tokens.append((response.token, trit))
                self.stats.tokens_generated += 1
        
        self.stats.center_tokens["PLUS"] += len(tokens)
        return self.tokenizer.decode(tokens)
    
    def _self_speculative_generate(self, prompt: str, max_tokens: int) -> str:
        """
        Self-speculative generation: SAME model with different attention modes.
        
        Paper insight: "batch size 1 is memory-bound, extra tokens are free compute"
        
        Uses single model for both drafting and verification:
        - Diffusion mode: bidirectional attention within draft block (parallel decode)
        - AR mode: causal attention for acceptance/rejection (sequential verify)
        
        The key is that extra tokens in the KV cache are essentially "free"
        when memory-bound, so we can draft k tokens in parallel and verify
        them with the same forward pass using mixed attention patterns.
        """
        self.three_center.plus.tokens = []
        
        input_ids = self.tokenizer.encode(prompt)
        if not isinstance(input_ids, mx.array):
            input_ids = mx.array(input_ids)
        
        prefix_len = len(input_ids)
        tokens = []
        state = self.seed
        current_prefix = input_ids
        
        while len(tokens) < max_tokens:
            # === PHASE 1: Diffusion draft (bidirectional attention) ===
            # Generate k draft tokens with block-bidirectional attention
            # All k positions attend to each other (parallel decode)
            draft_tokens = []
            
            # Create mask input for diffusion: [prefix | MASK^k]
            mask_block = mx.full((self.draft_len,), self.MASK_TOKEN_ID, dtype=mx.int32)
            diffusion_input = mx.concatenate([current_prefix, mask_block])
            
            # Get logits for all positions in single forward pass
            cache = make_prompt_cache(self.model)
            all_logits = self.model(diffusion_input[None, :], cache=cache)
            
            # Extract logits for draft positions (last k positions)
            draft_logits = all_logits[0, -self.draft_len:, :]  # (k, vocab_size)
            
            # Sample draft tokens in parallel (bidirectional context)
            for i in range(self.draft_len):
                probs = mx.softmax(draft_logits[i] / self.temperature)
                state, r = splitmix64(state)
                u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
                cumsum = mx.cumsum(probs)
                token = int(mx.sum(cumsum < u).item())
                draft_tokens.append(token)
            
            # === PHASE 2: AR verification (causal attention) ===
            # Verify each draft token sequentially with causal attention
            accepted = []
            verify_prefix = current_prefix
            
            for i, draft_token in enumerate(draft_tokens):
                # Get causal logits for position after verify_prefix
                cache = make_prompt_cache(self.model)
                ar_logits = self.model(verify_prefix[None, :], cache=cache)
                target_probs = mx.softmax(ar_logits[0, -1] / self.temperature)
                
                # For self-speculative: draft probs came from bidirectional
                # AR probs come from causal - compare them
                draft_probs = mx.softmax(draft_logits[i] / self.temperature)
                
                p_target = target_probs[draft_token].item()
                p_draft = draft_probs[draft_token].item()
                
                if p_draft < 1e-10:
                    p_draft = 1e-10
                
                accept_prob = min(1.0, p_target / p_draft)
                
                state, r = splitmix64(state)
                u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
                
                if u < accept_prob:
                    # Accept
                    accepted.append(draft_token)
                    verify_prefix = mx.concatenate([verify_prefix, mx.array([draft_token])])
                    trit = self.triad_gen.next()
                    self.three_center.plus.tokens.append((draft_token, trit))
                    self.stats.drafts_accepted += 1
                else:
                    # Reject: sample from residual max(0, p_target - p_draft)
                    residual = mx.maximum(target_probs - draft_probs, mx.zeros_like(target_probs))
                    residual_sum = mx.sum(residual)
                    if residual_sum.item() < 1e-8:
                        residual = target_probs
                        residual_sum = mx.sum(residual)
                    residual = residual / residual_sum
                    
                    state, r = splitmix64(state)
                    u = (r & 0xFFFFFFFF) / 0xFFFFFFFF
                    cumsum = mx.cumsum(residual)
                    correction_token = int(mx.sum(cumsum < u).item())
                    
                    accepted.append(correction_token)
                    trit = self.triad_gen.next()
                    self.three_center.plus.tokens.append((correction_token, trit))
                    self.stats.drafts_rejected += len(draft_tokens) - i
                    break
            
            tokens.extend(accepted)
            self.stats.tokens_generated += len(accepted)
            current_prefix = mx.concatenate([current_prefix, mx.array(accepted)])
            
            # Check EOS
            eos_id = self.tokenizer.eos_token_id or 2
            if tokens and tokens[-1] == eos_id:
                break
        
        self.stats.center_tokens["PLUS"] += len(tokens)
        return self.tokenizer.decode(tokens[:max_tokens])
    
    def generate_3center(
        self,
        prompt: str,
        max_tokens: int = 50
    ) -> Tuple[str, ThreeCenter]:
        """
        Complete 3-center TiDAR generation.
        
        1. ERGODIC: Diffusion drafting (bidirectional)
        2. MINUS: AR verification (causal)
        3. PLUS: Speculative generation (verified + corrected)
        
        Maintains GF(3) = 0 across all centers.
        """
        start = time.time()
        self.triad_gen.reset()
        self.three_center = ThreeCenter.create(self.seed)
        
        formatted = self._format_prompt(prompt)
        input_ids = self.tokenizer.encode(formatted)
        if not isinstance(input_ids, mx.array):
            input_ids = mx.array(input_ids)
        
        generated_tokens = []
        
        # Iterate through 3-center passes
        iterations = (max_tokens + self.draft_len - 1) // self.draft_len
        
        for i in range(iterations):
            self.stats.forward_passes += 1
            
            # Current prefix
            if generated_tokens:
                prefix = mx.concatenate([input_ids, mx.array(generated_tokens)])
            else:
                prefix = input_ids
            
            # 1. ERGODIC: Diffusion draft
            draft_tokens = self._diffusion_draft(prefix, self.draft_len)
            
            # Generate k+1 pre-draft proposals for parallel pre-drafting optimization
            # proposal[i] assumes i tokens from current draft will be accepted
            self._last_draft_tokens = draft_tokens
            self._generate_all_proposals(prefix, self.draft_len)
            
            # 2. MINUS: AR verification with proper rejection sampling
            accepted, rejected_at, residual_token, next_pre_drafts = self._ar_verify(
                prefix, draft_tokens
            )
            
            # 3. PLUS: Accept verified tokens
            generated_tokens.extend(accepted)
            
            # On rejection, use residual-sampled token (proper speculative decoding)
            if rejected_at is not None and residual_token is not None:
                # Add the token sampled from max(0, p_target - p_draft)
                generated_tokens.append(residual_token)
                trit = self.triad_gen.next()
                self.three_center.plus.tokens.append((residual_token, trit))
                self.stats.center_tokens["PLUS"] += 1
            elif rejected_at == 0 and residual_token is None:
                # Fallback: use speculative for correction only if residual failed
                correction = self._speculative_generate(
                    self.tokenizer.decode(prefix.tolist()),
                    max_tokens=1
                )
                correction_ids = self.tokenizer.encode(correction)
                if correction_ids:
                    generated_tokens.append(correction_ids[0])
            
            # Use k+1 pre-draft proposal for next iteration (TiDAR Section 3.2)
            # This avoids re-drafting when we already have the appropriate proposal
            if next_pre_drafts and self.use_one_step_diffusion:
                # Store as pending drafts for next iteration
                self._pending_next_drafts = next_pre_drafts
            
            # Check termination
            if len(generated_tokens) >= max_tokens:
                break
            
            # Check EOS
            eos_id = self.tokenizer.eos_token_id or 2
            if generated_tokens and generated_tokens[-1] == eos_id:
                break
        
        self.stats.total_time = time.time() - start
        
        # Balance tokens across centers for GF(3) = 0 per triplet
        self.three_center.balance_tokens()
        
        # Update Forward-Forward goodness for each center
        self.three_center.update_all_goodness(threshold=2.0)
        
        # Verify GF(3) conservation (should now be 0)
        self.stats.gf3_violations = self.three_center.count_token_violations()
        
        output = self.tokenizer.decode(generated_tokens[:max_tokens])
        return output, self.three_center
    
    def generate(self, prompt: str, max_tokens: int = 50) -> str:
        """Simple generation interface."""
        output, _ = self.generate_3center(prompt, max_tokens)
        return output


def main():
    parser = argparse.ArgumentParser(
        description="TiDAR MLX Diffusion: NVIDIA TiDAR + MLX + GF(3) 3-Center"
    )
    parser.add_argument("--prompt", type=str, default="Explain quantum entanglement briefly:")
    parser.add_argument("--max-tokens", type=int, default=50)
    parser.add_argument("--draft-len", type=int, default=4)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--seed", type=int, default=0x42D)
    parser.add_argument("--model", type=str, default="mlx-community/gemma-3-1b-it-qat-4bit")
    parser.add_argument("--draft-model", type=str, default="mlx-community/gemma-3-270m-it-8bit")
    # TiDAR-specific options (arXiv:2511.08923)
    parser.add_argument("--one-step-diffusion", action="store_true", default=True,
                        help="Use one-step diffusion: MASK^k → tokens in single forward")
    parser.add_argument("--no-one-step-diffusion", dest="one_step_diffusion", action="store_false")
    parser.add_argument("--block-causal", action="store_true", default=True,
                        help="Use block-causal attention: causal prefix + bidirectional draft")
    parser.add_argument("--no-block-causal", dest="block_causal", action="store_false")
    parser.add_argument("--num-proposals", type=int, default=None,
                        help="Number of k+1 pre-draft proposals (default: draft_len + 1)")
    parser.add_argument("--alpha-mix", type=float, default=0.5,
                        help="Logit mixing: α * AR + (1-α) * diffusion (default: 0.5)")
    parser.add_argument("--lambda-diffusion", type=float, default=1.0,
                        help="Loss weight: L = L_AR + λ * L_diffusion (default: 1.0)")
    parser.add_argument("--self-speculative", action="store_true", default=True,
                        help="Self-speculative: SAME model for draft + verify (batch size 1 is free)")
    parser.add_argument("--no-self-speculative", dest="self_speculative", action="store_false",
                        help="Use separate draft model instead of self-speculative")
    args = parser.parse_args()
    
    print("=" * 70)
    print("TiDAR MLX DIFFUSION: NVIDIA TiDAR + MLX Native + GF(3) 3-Center")
    print("=" * 70)
    print(f"Target:     {args.model}")
    print(f"Draft:      {args.draft_model}")
    print(f"Draft len:  {args.draft_len}")
    print(f"Max tokens: {args.max_tokens}")
    print(f"Seed:       0x{args.seed:X}")
    print("--- TiDAR Options (arXiv:2511.08923) ---")
    print(f"One-step diffusion:   {args.one_step_diffusion}")
    print(f"Block-causal attn:    {args.block_causal}")
    num_props = args.num_proposals or (args.draft_len + 1)
    print(f"k+1 proposals:        {num_props}")
    print(f"Alpha mix (α):        {args.alpha_mix}")
    print(f"Lambda diffusion (λ): {args.lambda_diffusion}")
    print(f"Self-speculative:     {args.self_speculative}")
    if args.self_speculative:
        print("  → SAME model for diffusion + AR (extra tokens are free compute)")
    print("-" * 70)
    
    engine = TidarMLXDiffusion(
        model_name=args.model,
        draft_model_name=args.draft_model,
        draft_len=args.draft_len,
        temperature=args.temperature,
        seed=args.seed,
        use_one_step_diffusion=args.one_step_diffusion,
        use_block_causal=args.block_causal,
        num_proposals=args.num_proposals,
        alpha_mix=args.alpha_mix,
        lambda_diffusion=args.lambda_diffusion,
        use_self_speculative=args.self_speculative
    )
    engine.load()
    
    print(f"\nPrompt: {args.prompt}\n")
    print("-" * 70)
    
    output, three_center = engine.generate_3center(args.prompt, args.max_tokens)
    
    print("-" * 70)
    print(f"\nGenerated:\n{output}\n")
    
    # 3-Center breakdown with Forward-Forward goodness
    print("=" * 70)
    print("3-CENTER BREAKDOWN (with Forward-Forward Goodness)")
    print("=" * 70)
    print(f"  MINUS (verify):    {three_center.minus.token_count():3d} tokens, trit={three_center.minus.trit:+d}, goodness={three_center.minus.goodness:.4f}")
    print(f"  ERGODIC (diffuse): {three_center.ergodic.token_count():3d} tokens, trit={three_center.ergodic.trit:+d}, goodness={three_center.ergodic.goodness:.4f}")
    print(f"  PLUS (generate):   {three_center.plus.token_count():3d} tokens, trit={three_center.plus.trit:+d}, goodness={three_center.plus.goodness:.4f}")
    print(f"  Token trit sum:    {three_center.token_trit_sum()} (mod 3 = {three_center.token_trit_sum() % 3})")
    print(f"  GF(3) conserved:   {'✓' if three_center.is_conserved() else '✗'}")
    
    # Stats
    print("\n" + "=" * 70)
    print("STATISTICS")
    print("=" * 70)
    s = engine.stats
    print(f"Forward passes:     {s.forward_passes}")
    print(f"Tokens generated:   {s.tokens_generated}")
    print(f"Drafts accepted:    {s.drafts_accepted}")
    print(f"Drafts rejected:    {s.drafts_rejected}")
    accept_rate = s.drafts_accepted / (s.drafts_accepted + s.drafts_rejected) if (s.drafts_accepted + s.drafts_rejected) > 0 else 0
    print(f"Acceptance rate:    {accept_rate:.1%}")
    print(f"Diffusion steps:    {s.diffusion_steps}")
    print(f"AR verify steps:    {s.ar_steps}")
    print(f"GF(3) violations:   {s.gf3_violations}")
    print(f"Total time:         {s.total_time:.2f}s")
    print(f"Tokens/second:      {s.tokens_generated / s.total_time:.2f}" if s.total_time > 0 else "N/A")
    
    # k+1 Pre-draft proposal stats
    print("\n--- k+1 Pre-Draft Proposals ---")
    print(f"Proposals generated: {s.proposals_generated}")
    print(f"Last selected:       proposal[{s.proposal_selected}]")
    print(f"Pre-draft hits:      {s.predraft_hits}")
    print(f"Pre-draft misses:    {s.predraft_misses}")
    if s.proposal_selections:
        print("Selection distribution:")
        for n_accepted, count in sorted(s.proposal_selections.items()):
            bar = "█" * count
            print(f"  proposal[{n_accepted}]: {count:3d} {bar}")
    
    # Center token distribution
    print("\n--- Center Token Distribution ---")
    for name, count in s.center_tokens.items():
        bar = "█" * (count // 2)
        print(f"  {name:8s}: {count:3d} {bar}")
    
    print("=" * 70)


if __name__ == "__main__":
    main()
