# RAMA-MLX-TIDAR Skill

> *"Tree-structured Iterative Decomposition and Aggregation with Rollup on Apple Silicon"*

## Overview

This skill integrates Red Planet Labs **Rama** distributed backend with Apple Silicon **MLX** inference for agent-level parallelism using the **TIDAR** pattern and **GF(3) conservation**.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           RAMA-MLX-TIDAR                                     │
│   Block-STM Orderless Execution + MLX Speculative Decoding + GF(3) = 0      │
└─────────────────────────────────────────────────────────────────────────────┘

                    ┌─────────────────────────────────────┐
                    │          USER TASK                  │
                    └────────────────┬────────────────────┘
                                     │
                    ┌────────────────▼────────────────────┐
                    │        FORWARD PASS (Spawn)         │
                    │  Build agent tree with GF(3) trits  │
                    └────────────────┬────────────────────┘
                                     │
           ┌─────────────────────────┼─────────────────────────┐
           │                         │                         │
    ┌──────▼──────┐          ┌───────▼───────┐         ┌───────▼───────┐
    │   Root 0    │          │    Root 1     │         │    Root N     │
    │  trit = -1  │          │   trit = 0    │         │   trit = +1   │
    │  VALIDATOR  │          │  COORDINATOR  │         │   GENERATOR   │
    └──────┬──────┘          └───────┬───────┘         └───────┬───────┘
           │                         │                         │
    ┌──────┼──────┐          ┌───────┼───────┐         ┌───────┼───────┐
    │      │      │          │       │       │         │       │       │
  leaf   leaf   leaf       leaf    leaf    leaf      leaf    leaf    leaf
  (-1)   (0)    (+1)       (-1)    (0)    (+1)       (-1)    (0)    (+1)
           │                         │                         │
           └─────────────────────────┼─────────────────────────┘
                                     │
                    ┌────────────────▼────────────────────┐
                    │       BACKWARD PASS (Gather)        │
                    │   Batch MLX + Speculative Decode    │
                    └────────────────┬────────────────────┘
                                     │
                    ┌────────────────▼────────────────────┐
                    │      GF(3) CONSERVATION = 0 ✓       │
                    └─────────────────────────────────────┘
```

## Key Components

### 1. TIDAR (Tree-structured Iterative Decomposition and Aggregation with Rollup)

From NVIDIA arXiv:2511.08923 - adapted for agent parallelism:

| NVIDIA TiDAR (Token-level) | RAMA-MLX-TIDAR (Agent-level) |
|----------------------------|------------------------------|
| Diffusion drafting | Parallel leaf generation |
| AR verification | Branch aggregation |
| One-step denoising | Batch MLX inference |
| Block-causal attention | GF(3) triplet structure |

### 2. GF(3) Conservation

Every operation maintains balanced ternary conservation:

```python
TRIAD = [-1, 0, +1]  # Sum = 0

def gf3_balanced(trits: List[int]) -> bool:
    return sum(trits) % 3 == 0
```

### 3. MLX Native APIs

- `mlx_lm.load()` - Load quantized models (4-bit, 8-bit)
- `mlx_lm.stream_generate()` - Streaming generation
- `mlx_lm.models.cache.make_prompt_cache()` - Prompt caching
- Speculative decoding with draft models

### 4. Block-STM Strong Parallelism Invariance (SPI)

From Aptos Move VM:

```
∀ permutation π of transactions T: Execute(T) ≡ Execute(π(T))
```

This orderless property maps directly to GF(3) conservation.

## Files

| Path | Description |
|------|-------------|
| `scripts/tidar_full.py` | Full TIDAR with all optimizations |
| `scripts/tidar_mlx_diffusion.py` | TiDAR with 3-center structure |
| `src/clj/com/rpl/agent_o_rama/wev.clj` | WEV triplet construction |
| `scripts/world_tesseract.bb` | 26-world tesseract verification |

## Usage

### Run TIDAR Full

```bash
# Basic run: 7 roots × 3 children × 2 iterations
python scripts/tidar_full.py --roots 7 --children 3 --iterations 2

# With speculative decoding
python scripts/tidar_full.py --roots 3 --children 3 --speculative

# Quick test
python scripts/tidar_full.py --roots 3 --children 3 --iterations 1 --max-tokens 15
```

### Run TiDAR MLX Diffusion

```bash
# 3-center with one-step diffusion
python scripts/tidar_mlx_diffusion.py --prompt "Explain AI" --draft-len 4

# Multiple iterations
python scripts/tidar_mlx_diffusion.py --prompt "Write code" --centers 3 --iterations 2
```

### Verify GF(3) Conservation

```bash
# Via Babashka tesseract
bb scripts/world_tesseract.bb gf3

# Via ruler
just ruler-gf3
```

## Models

### Target Models (MLX)
- `mlx-community/gemma-3-1b-it-qat-4bit` - 1B params, 4-bit quantized
- `mlx-community/gemma-3-4b-it-qat-4bit` - 4B params, 4-bit quantized

### Draft Models (Speculative)
- `mlx-community/gemma-3-270m-it-8bit` - 270M params, fast drafting

## Timing Breakdown

Typical run (3 roots × 3 children × 1 iteration):

```
TIMING BREAKDOWN
  Model load:             2.06s
  Forward pass:         0.0001s
  Batch generate:         4.61s
  Branch aggregate:       2.17s
  Speculative decode:     0.00s
  ────────────────────────────────────────
  TOTAL:                  8.84s

Throughput: 1.02 leaves/second
```

## 3-Center Structure

From Gay-MCP deterministic coloring:

| Center | Trit | Role | Color Range |
|--------|------|------|-------------|
| MINUS | -1 | Verification/rejection | Cold (180-300°) |
| ERGODIC | 0 | Diffusion/coordination | Neutral (60-180°) |
| PLUS | +1 | Generation/acceptance | Warm (0-60°, 300-360°) |

## Forward-Forward Goodness

Layer-wise verification via Hinton's FF algorithm:

```python
def ff_layer_goodness(token_ids: List[int], threshold: float = 2.0) -> float:
    activations = [(t % 256) / 256.0 for t in token_ids]
    return sum(a ** 2 for a in activations)
```

## WEV (World Extractable Value)

Knowledge transfer mediated by GF(3)-balanced triplets:

```clojure
(defn wev-triplet [from-world to-world]
  (let [from-trit (world-trit from-world)
        to-trit (world-trit to-world)
        needed-trit (- (+ from-trit to-trit))]
    {:from from-world
     :to to-world
     :mediator (find-world-with-trit needed-trit)
     :sum 0
     :orderless true}))
```

## Adjunction: Spawn ⊣ Gather

```
       L (Spawn)              η/ε               R (Gather)
        PLUS +1    ─────────────────────→   MINUS -1
       Generate               Transport         Validate
       
Triangle identities:
  (εL) ∘ (Lη) = id_L   Spawned agents return to spawn point
  (Rε) ∘ (ηR) = id_R   Gathered results return to gather point
```

## Justfile Recipes

```just
# Run TIDAR full
tidar-full ROOTS="7" CHILDREN="3" ITERS="2":
    /tmp/mlx-env/bin/python scripts/tidar_full.py \
        --roots {{ROOTS}} --children {{CHILDREN}} --iterations {{ITERS}}

# Run TIDAR with speculative
tidar-speculative:
    /tmp/mlx-env/bin/python scripts/tidar_full.py --roots 3 --children 3 --speculative

# Quick TIDAR test
tidar-quick:
    /tmp/mlx-env/bin/python scripts/tidar_full.py \
        --roots 3 --children 3 --iterations 1 --max-tokens 15

# World tesseract verification
tesseract-verify THREAD_ID:
    bb scripts/world_tesseract.bb verify {{THREAD_ID}} 1069

# WEV triplet
wev-triplet FROM="A" TO="Z":
    bb scripts/world_tesseract.bb wev {{FROM}} {{TO}}
```

## Integration with Rama

Rama provides:
- **Block-STM**: Orderless execution for parallel safety
- **Depot**: Immutable append-only log for skill history
- **PState**: Partitioned state for world wallets
- **Topology**: Dataflow for WEV extraction

```clojure
(ns com.rpl.agent-o-rama.tidar-topology
  (:require [com.rpl.rama :as r]))

(r/defmodule TidarModule [setup topo]
  (r/declare-depot setup *task-depot :random)
  (r/declare-pstate setup *results (r/map-schema String Object))
  
  (r/topology topo "tidar-pipeline"
    (r/source> *task-depot :> *task)
    (r/|hash *task)  ;; Partition by task
    (tidar-forward *task :> *tree)
    (tidar-backward *tree :> *result)
    (r/local-transform> [(r/keypath (:id *task)) (r/termval *result)] *results)))
```

## Dependencies

```bash
# Python environment
python3 -m venv /tmp/mlx-env
/tmp/mlx-env/bin/pip install mlx mlx-lm

# Babashka for tesseract
brew install babashka

# Clojure for WEV
brew install clojure
```

## See Also

- `mlx-apple-silicon` - MLX model loading skill
- `parallel-fanout` - Interaction-entropy parallelism
- `bisimulation-game` - Skill dispersal verification
- `aptos-agent` - Blockchain integration
- `world-hopping` - Tesseract navigation
- `gay-mcp` - Deterministic color generation

## References

- [TiDAR: Think in Diffusion, Act in AR](https://arxiv.org/abs/2511.08923) - NVIDIA
- [Rama](https://redplanetlabs.com/rama) - Red Planet Labs
- [MLX](https://github.com/ml-explore/mlx) - Apple Machine Learning
- [Block-STM](https://arxiv.org/abs/2203.06871) - Aptos Labs
- [Forward-Forward](https://arxiv.org/abs/2212.13345) - Hinton

---

*"TIDAR on RAMA with MLX: Agent-level parallelism with GF(3) conservation."*
