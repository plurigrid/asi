# Aequitas Order Fairness Skill

**Trit**: 0 (ERGODIC - coordination/synthesis)

## Overview

Order fairness protocols for blockchain transaction ordering to prevent MEV extraction. Based on the Aequitas paper (Kelkar, Ghodsi, Gafni, Jules 2020) and follow-ups including Themis.

## Key Concepts

### Time-Based Order Fairness (Aequitas)
If most miners receive transaction TX₁ before TX₂, then TX₁ should precede TX₂ in the final ordering.

**Problem**: Condorcet cycles - circular ordering preferences that cannot be resolved.

**Solution**: Block order fairness - place unresolvable cycles in the same block.

### Blind Order Fairness
Three phases:
1. **Commit**: Users commit to transactions with hiding commitment scheme
2. **Order**: Validators order commitments (blind to content)
3. **Reveal**: Transactions revealed for execution

### Protocols

| Protocol | Approach | n/f | Communication |
|----------|----------|-----|---------------|
| **Aequitas** | Time-based | BFT | O(n²) |
| **Themis** | Strong ordering | ≥4f+1 | Improved |
| **Quick Order Fairness** | Fast finality | BFT | O(n²) |

## Commitment Schemes for Blind Fairness

### 1. Collateral-Based
```
User locks collateral → Commits to TX → Reveals TX or loses collateral
```

### 2. Threshold Cryptography
```
Validators DKG → User encrypts to threshold PK → Validators MPC decrypt
```

### 3. Secret Sharing (User-Side)
```
User generates symmetric key → Shares key to validators (IDA) → Encrypts TX → Validators MPC reconstruct key
```

### 4. VDF Time-Lock Puzzles
```
User generates trapdoor VDF params → Computes encryption key fast → Encrypts TX
Anyone can reveal by computing VDF slowly (time Δ)
```

## GF(3) Integration

Order fairness maps to triadic roles:
- **MINUS (-1)**: Validators constraining orderings
- **ERGODIC (0)**: Consensus coordinating final order
- **PLUS (+1)**: Users generating transactions

Conservation: Σ trits ≡ 0 (mod 3) across ordering participants.

## MEV-Boost Architecture

Proposer-Builder Separation (PBS):
```
Searchers → Builders → Relays → Proposers
         bundles    blocks   headers  signatures
```

Key insight: Block proposers hold power, can extract MEV profits from searchers.

## Research Papers

1. **Aequitas** (Crypto 2020): Kelkar, Ghodsi, Gafni, Jules
   - First formalization of order fairness
   - Revealed Condorcet paradox connection

2. **Themis** (ePrint 2021/1465): Kelkar, Deb, Long, Juels, Kannan
   - Strongest fair ordering to date
   - Standard liveness (not weaker relaxation)
   - n ≥ 4f + 1

3. **Ordering with Bounded Unfairness** (ePrint 2023/1253)
   - Minimize distance from ideal ordering

4. **SoK: Consensus for Fair Message Ordering** (arXiv 2411.09981)
   - Comprehensive survey

## Transcript Source

BIU Research Center lecture by Dan Boneh and Valeria Nikolaenko on MEV and Fair Ordering (March 2023).

Key points:
- MEV ~$250M paid to validators since Nov 2020
- Coming from end users via worse exchange rates
- Suave: next-gen with MPC/enclaves for private transactions until signed

## References

- https://eprint.iacr.org/2020/269 (Aequitas)
- https://eprint.iacr.org/2021/1465 (Themis)
- https://github.com/flashbots/mev-boost
- https://writings.flashbots.net/

Base directory for this skill: file:///Users/alice/.agents/skills/aequitas-order-fairness
