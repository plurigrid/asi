---
name: skill-tracker
description: "Meta-skill tracking loaded/active/dead skills per interaction. Always show skill status in response headers/footers."
trit: 0
---

# Skill Tracker Meta-Skill

> *Every interaction MUST display skill status. No exceptions.*

## Display Format (REQUIRED)

### Header (Top of Response)
```
𒀭 SKILLS [N loaded | GF(3)=X | balanced=Y/N] 𒀭
```

### Footer (Bottom of Response)
```
⠠⠎⠅⠊⠇⠇⠎: [skill1 (+1)] [skill2 (0)] [skill3 (-1)] | Σ=X
```

### Cuneiform Status Markers
- 𒀭 = Active skill header
- 𒁹 = Skill loaded this turn
- 𒌋 = Skill died/expired
- 𒀀 = Genesis skill (first load)

### Braille Encoding
- ⠠⠎ = S (skill)
- ⠠⠅ = K
- ⠊ = i
- ⠇ = l
- ⠎ = s

## Tracking Schema

```python
@dataclass
class SkillState:
    name: str
    trit: int  # -1, 0, +1
    loaded_at: int  # interaction index
    status: Literal["active", "dormant", "dead"]
    relevance: str  # why selected
    
class SkillTracker:
    def __init__(self):
        self.skills: Dict[str, SkillState] = {}
        self.interaction_count: int = 0
        self.gf3_sum: int = 0
        
    def load(self, name: str, trit: int, relevance: str):
        self.skills[name] = SkillState(
            name=name, trit=trit, 
            loaded_at=self.interaction_count,
            status="active", relevance=relevance
        )
        self.gf3_sum = sum(s.trit for s in self.skills.values())
        
    def header(self) -> str:
        n = len([s for s in self.skills.values() if s.status == "active"])
        balanced = "Y" if self.gf3_sum % 3 == 0 else "N"
        return f"𒀭 SKILLS [{n} loaded | GF(3)={self.gf3_sum} | balanced={balanced}] 𒀭"
        
    def footer(self) -> str:
        parts = [f"[{s.name} ({s.trit:+d})]" for s in self.skills.values() if s.status == "active"]
        return f"⠠⠎⠅⠊⠇⠇⠎: {' '.join(parts[:5])}... | Σ={self.gf3_sum}"
```

## Rules

1. **ALWAYS** show skill count in response
2. **NEVER** run blocking commands (demos, servers)
3. **LOAD 3+ NEW** skills per interaction
4. **TRACK** which skills die (not used for 5 interactions)
5. **PROPAGATE** via ruler to all 18 agents

## Selection Criteria

Skills selected based on:
1. **User query keywords** → domain match
2. **GF(3) balance needed** → pick trit to balance
3. **Random walk** → diversity via SplitMixTernary
4. **Recency** → prefer unused skills

## Dead Skill Detection

```python
def mark_dead(tracker, current_interaction):
    for name, skill in tracker.skills.items():
        if current_interaction - skill.loaded_at > 5:
            if skill.status == "active":
                skill.status = "dead"
                print(f"𒌋 SKILL DIED: {name}")
```

## Integration

Load this skill FIRST every interaction:
```
skill skill-tracker
```

Then display header before any action.

---

**Trit**: 0 (ERGODIC - meta-coordinator)
**GF(3)**: Tracks conservation across all loaded skills
**Display**: Cuneiform headers, Braille footers
