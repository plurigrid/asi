---
name: catp
description: Category-theoretic pipes combining dplyr %>% semantics with Clojure threading macros and GF(3) flow control. Use for data transformation pipelines, notetaking shorthand, and ACSet query chains.
---

# catp: Categorical Pipes

**Trit**: +1 (PLUS - generator/executor)  
**Principle**: Data flows through morphism chains  
**Syntax**: `source %>% transform %>% sink`

## Core Operators

| Operator | Origin | Semantics | Trit |
|----------|--------|-----------|------|
| `%>%` | R/dplyr | Forward pipe: `x %>% f` = `f(x)` | +1 |
| `->>` | Clojure | Thread-last: `(->> x f g)` = `(g (f x))` | +1 |
| `->` | Clojure | Thread-first: `(-> x f g)` = `(g (f x))` | +1 |
| `\|>` | Elixir/R 4.1+ | Native pipe | +1 |
| `<%>` | catp | Balanced pipe (auto-GF(3)) | 0 |
| `<<%` | catp | Reverse validate pipe | -1 |

## GF(3) Flow Control

```
source (-1: read) %>% transform (0: coordinate) %>% sink (+1: write)
─────────────────────────────────────────────────────────────────────
Σ trits = -1 + 0 + 1 = 0 ✓ (balanced pipeline)
```

### Pipeline Trit Assignment

```python
PIPE_TRITS = {
    # Sources (MINUS -1): Data ingestion
    "read": -1, "fetch": -1, "query": -1, "search": -1, "list": -1,
    
    # Transforms (ERGODIC 0): Shape-preserving
    "filter": 0, "select": 0, "rename": 0, "mutate": 0, "arrange": 0,
    "group_by": 0, "join": 0, "pivot": 0, "map": 0,
    
    # Sinks (PLUS +1): Data output
    "write": +1, "save": +1, "send": +1, "create": +1, "print": +1,
    "summarize": +1, "reduce": +1, "aggregate": +1,
}
```

## Babashka Integration

```clojure
;; Threading macros as pipes
(->> (slurp "data.csv")
     (str/split-lines)
     (map #(str/split % #","))
     (filter #(> (count %) 2))
     (take 10))

;; With GF(3) balance check
(defn balanced-pipe [steps]
  (let [trits (map :trit steps)]
    (assert (zero? (mod (reduce + trits) 3)) "GF(3) violation!")))
```

## Notetaking Shorthand

| Shorthand | Expansion | Trit |
|-----------|-----------|------|
| `>` | pipe forward | +1 |
| `<` | pipe backward (validate) | -1 |
| `~` | transform in place | 0 |
| `>>` | deep thread | +1 |
| `<<` | deep validate | -1 |
| `><` | bidirectional (lens) | 0 |

### Example: Drive Query

```
drive:search "report" > filter:pdf > share:team@
─────────────────────────────────────────────────
Expands to:
  search_drive_files("report")        # -1
  %>% filter(mime_type == "pdf")      #  0  
  %>% share_drive_file(team@)         # +1 (but share is 0!)
  
GF(3): -1 + 0 + 0 = -1 ≠ 0 ❌
Auto-balance: append list_drive_items (+1 read confirmation)
```

## ACSet Query Chains

```python
# Query chain with catp syntax
acset %>% select(:Interaction) %>% where(trit=-1) %>% join(:Thread) %>% count()

# Equivalent to:
[i for i in acset.get_parts("Interaction") 
 if i["trit"] == -1]
```

## Shared With ≡ Shared By

**Key equivalence for Drive operations:**

```python
# "Shared with" and "shared by" are symmetric morphisms
# In categorical terms: sharing is a symmetric relation

def drive_shared(file_id: str, person_email: str) -> bool:
    """
    shared_with(file, person) ≡ shared_by(person, file)
    
    The Partner morphism in DriveACSet is bidirectional:
    src --partner--> tgt  ⟺  tgt --partner--> src
    """
    perms = get_drive_file_permissions(file_id)
    return any(p["emailAddress"] == person_email for p in perms)

# Query: "files shared with me" ≡ "files others shared by them to me"
# Query: "files I shared" ≡ "files shared with others by me"
```

## R Statistics Bridge

```r
# dplyr pipe chain
library(dplyr)

data %>%
  filter(year == 2024) %>%        # ERGODIC (0)
  select(name, value) %>%         # ERGODIC (0)
  mutate(scaled = value / max(value)) %>%  # ERGODIC (0)
  summarize(mean = mean(scaled))  # PLUS (+1)

# GF(3): 0 + 0 + 0 + 1 = +1
# Auto-balance by prepending read_csv (-1)
```

## Commands

```bash
# Execute pipe chain via babashka
bb -e '(->> "input.txt" slurp str/split-lines (map str/upper-case) (str/join "\n"))'

# Python pipe simulation
python -c "from functools import reduce; print(reduce(lambda x,f: f(x), [str.upper, str.strip], '  hello  '))"

# R pipe chain
Rscript -e 'library(dplyr); mtcars %>% filter(cyl==4) %>% summarize(mean(mpg))'
```

## Integration

| Skill | Trit | Integration |
|-------|------|-------------|
| [babashka](file:///Users/alice/.agents/skills/babashka/SKILL.md) | +1 | Threading macros |
| [drive-acset](file:///Users/alice/agent-o-rama/agent-o-rama/.agents/skills/drive-acset/SKILL.md) | 0 | Query chains |
| [gmail-anima](file:///Users/alice/agent-o-rama/agent-o-rama/.agents/skills/gmail-anima/SKILL.md) | 0 | Message flows |
| [l-space](file:///Users/alice/.agents/skills/l-space/SKILL.md) | 0 | Narrative pipes |

---

**Skill Name**: catp  
**Type**: Data Flow / Pipe Operators  
**Trit**: +1 (PLUS)  
**GF(3)**: Balances via source/sink pairing
