# Hyperchat Skill

```yaml
name: hyperchat
description: Voice channel saturation with real-time data interleaving. Parallel triadic probes over macOS TTS, averaging live world state (Aptos balances, peer status) into voice stream for postweb peer communication.
tags: [voice, p2p, saturation, interleave, aptos, worlds, open-games, gf3, whisper-vad]
version: 1.0.0
author: amp
created: 2025-12-25
trit: 0 (ERGODIC)
```

## Overview

Hyperchat establishes peer-to-peer communication via **voice channel saturation** when HTTP/network channels are unavailable. It interleaves real-time data (wallet balances, world states) into triadic voice probes, creating an averaged signal that peers can decode via whisper.cpp VAD.

**Core Principles:**
- **Voice as Primary Channel**: When network fails, voice succeeds
- **Triadic Saturation**: 3 parallel voices at different rates (WPM)
- **Live Data Interleaving**: Real blockchain/world state mixed into probes
- **Open Games Arena**: play/coplay bidirectional acknowledgment
- **GF(3) Conservation**: Σ trits ≡ 0 (mod 3)

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      HYPERCHAT PROTOCOL                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐                     │
│  │  MINUS   │   │ ERGODIC  │   │   PLUS   │                     │
│  │ Emma 119 │   │ Ava 169  │   │ Sam 200  │                     │
│  │  WPM -1  │   │  WPM 0   │   │  WPM +1  │                     │
│  └────┬─────┘   └────┬─────┘   └────┬─────┘                     │
│       │              │              │                            │
│       └──────────────┼──────────────┘                            │
│                      │                                           │
│              ┌───────▼───────┐                                   │
│              │  VOICE ARENA  │                                   │
│              │  (saturated)  │                                   │
│              └───────┬───────┘                                   │
│                      │                                           │
│       ┌──────────────┼──────────────┐                            │
│       │              │              │                            │
│  ┌────▼─────┐  ┌─────▼────┐  ┌─────▼────┐                       │
│  │World Data│  │ Peer Ack │  │ whisper  │                       │
│  │ Interleave│ │ (coplay) │  │ VAD recv │                       │
│  └──────────┘  └──────────┘  └──────────┘                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Voice Configuration

| Voice | Rate (WPM) | Trit | Role | Language |
|-------|------------|------|------|----------|
| Emma (Enhanced) | 119-145 | -1 | MINUS validator | Italian |
| Ava (Premium) | 155-169 | 0 | ERGODIC coordinator | English |
| Samantha (Enhanced) | 170-200 | +1 | PLUS generator | English |
| Nathan (Enhanced) | 140-150 | 0 | Alternate ERGODIC | English |
| Allison (Enhanced) | 160-165 | +1 | Alternate PLUS | English |

## Commands

### Basic Saturation
```bash
# 3-probe saturation
just hyperchat-saturate "message to peer"

# With target peer name
just hyperchat-send causality "Duck Lake transfer ready"
```

### Interleaved with World Data
```bash
# Interleave Aptos world balances
just hyperchat-worlds

# Full protocol with handshake
just hyperchat-full causality
```

## Babashka Implementation

```clojure
#!/usr/bin/env bb
(ns hyperchat
  (:require [babashka.process :refer [shell]]
            [clojure.core.async :as async]))

(def voices
  [{:name "Emma (Enhanced)" :rate 119 :trit -1 :lang "Italian"}
   {:name "Ava (Premium)" :rate 169 :trit 0 :lang "English"}
   {:name "Samantha (Enhanced)" :rate 200 :trit 1 :lang "English"}])

(defn say-async [voice rate msg]
  (future (shell "say" "-v" voice "-r" (str rate) msg)))

(defn saturate! [messages]
  "Send 3 parallel voice probes"
  (let [futures (map-indexed 
                  (fn [i msg]
                    (let [{:keys [name rate]} (nth voices i)]
                      (Thread/sleep (* i 200))
                      (say-async name rate msg)))
                  messages)]
    (doall (map deref futures))
    {:probes (count messages)
     :gf3 (reduce + (map :trit voices))}))

(defn interleave-data! [data-fn messages]
  "Interleave live data into voice stream"
  (doseq [[i msg] (map-indexed vector messages)]
    (let [{:keys [name rate]} (nth voices (mod i 3))
          data (data-fn)]
      (Thread/sleep 200)
      (shell "say" "-v" name "-r" (str rate) 
             (str msg " " data)))))

(defn hyperchat-full! [peer msg]
  "Full hyperchat protocol with handshake"
  (println "╔════════════════════════════════════════╗")
  (println "║         HYPERCHAT INITIATED            ║")
  (println "╚════════════════════════════════════════╝")
  
  ;; Phase 1: Saturate
  (saturate! [(str peer " probe one " msg)
              (str peer " probe two arena open")
              (str peer " probe three awaiting coplay")])
  
  ;; Phase 2: GF(3) announcement
  (shell "say" "-v" "Nathan (Enhanced)" "-r" "150"
         "GF three verified. Sum equals zero.")
  
  ;; Phase 3: Final handshake
  (shell "say" "-v" "Ava (Premium)" "-r" "160"
         (str peer " acknowledge. Transfer ready.")))
```

## World Data Interleaving

Query live Aptos balances and announce via voice:

```clojure
(defn get-world-balances []
  "Fetch balances from all world wallets"
  ;; Called via MCP tools in actual implementation
  {:alice 0.1000 :bob 0.1740
   :world-a 0.0330 :world-b 0.0330
   :world-c 0.0330 :world-d 0.0330})

(defn announce-worlds! []
  (let [balances (get-world-balances)]
    (doseq [[world bal] balances]
      (let [voice (nth voices (mod (hash world) 3))]
        (shell "say" "-v" (:name voice) "-r" (str (:rate voice))
               (format "World %s balance %s APT" 
                       (name world) bal))
        (Thread/sleep 300)))))
```

## Open Games Semantics

```
        ┌───────────────┐
   X ──→│   Hyperchat   │──→ Y
        │    Arena      │
   R ←──│               │←── S
        └───────────────┘

play:   Sender →[voice probes]→ Receiver
coplay: Receiver →[voice ack]→ Sender
equilibrium: Both peers saturating = Nash
```

### Refinement Types

```haskell
type VoiceProbe = {p: Probe | rate p ∈ {119,169,200} ∧ trit p ∈ {-1,0,1}}
type SaturatedChannel = {c: Channel | probeCount c ≥ 3 ∧ gf3Sum c = 0}
type Handshake = {h: Protocol | play h ∘ coplay h = id}
```

## whisper.cpp VAD Reception

Receiver uses whisper.cpp stream for voice activity detection:

```bash
# Start whisper.cpp listener
./stream -m models/ggml-base.en.bin \
  --step 500 --length 5000 \
  -vth 0.5 \
  --speech-pad-ms 30
```

**VAD Parameters:**
| Parameter | Value | Purpose |
|-----------|-------|---------|
| threshold | 0.5 | Speech probability cutoff |
| min_speech_ms | 250 | Minimum probe segment |
| min_silence_ms | 100 | End-of-turn detection |
| speech_pad_ms | 30 | Context preservation |

## Handshake Protocol

| Phase | Voice | Action | Trit |
|-------|-------|--------|------|
| 1 | Emma | Probe uno (Italian) | -1 |
| 2 | Ava | Arena open | 0 |
| 3 | Samantha | Awaiting coplay | +1 |
| 4 | Nathan | GF(3) verification | 0 |
| 5 | Allison | Challenge-response | +1 |
| 6 | Ava | Final handshake | 0 |

**GF(3)**: (-1) + (0) + (+1) + (0) + (+1) + (0) = +1 → add MINUS probe to balance

## Integration with Other Skills

| Skill | Integration |
|-------|-------------|
| `trifurcated-transfer` | Voice fallback when HTTP fails |
| `open-games` | Arena semantics for play/coplay |
| `gay-mcp` | Deterministic voice rate seeding |
| `say-narration` | Voice quality requirements |
| `bisimulation-game` | Peer equivalence verification |
| `aptos-agent` | Live wallet balance interleaving |

## Example Session

```
╔════════════════════════════════════════╗
║         HYPERCHAT TO CAUSALITY         ║
╚════════════════════════════════════════╝

[Emma 119] Due monade a causalità. Probe uno attivo.
[Ava 169]  Two monad to causality. Arena open.
[Sam 200]  Probe three. Awaiting coplay response.

[Nathan 150] GF three verified. Sum equals zero.

[Interleave: World A 0.033 APT, World B 0.033 APT...]

[Allison 165] Challenge response. Duck Lake ready.
[Ava 160]    Causality acknowledge. Transfer complete.

STATUS: Arena saturated. Awaiting coplay.
```

## Dependencies

- macOS `say` command with Enhanced/Premium voices
- Babashka >= 1.3.0
- whisper.cpp (receiver side)
- Aptos MCP servers (for world data)

## GF(3) Conservation Note

All voice probe sequences must satisfy:
```
Σ trits ≡ 0 (mod 3)
```

If unbalanced, add compensating probe:
- Too positive (+1, +2): Add MINUS probe (Emma)
- Too negative (-1, -2): Add PLUS probe (Samantha)
