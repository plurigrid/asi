# FileColorWalk Schema - Catlab-style ACSet Presentation
# MINUS (-1) validator stream contribution
# 
# Based on RelationalThinking book patterns:
#   - Schemas as presentations (generating objects + morphisms + equations)
#   - Instances as data (functors from schema to Set)
#
# GF(3) Role: MINUS (-1) - validates walk structure and color assignments

using Catlab
using Catlab.CategoricalAlgebra
using Catlab.Present

# ═══════════════════════════════════════════════════════════════════════════
# Schema Definition: FileColorWalk
# ═══════════════════════════════════════════════════════════════════════════

@present SchFileColorWalk(FreeSchema) begin
    # Objects (Tables)
    File::Ob            # Files in the filesystem
    Walk::Ob            # Walk steps (derivational, not temporal)
    Color::Ob           # Color assignments from Gay.jl
    
    # Morphisms (Foreign Keys)
    step::Hom(Walk, File)       # Which file at each walk step
    next::Hom(Walk, Walk)       # Walk succession (derivational chain)
    color_of::Hom(Walk, Color)  # Color assigned at each step
    
    # Attribute Types
    Seed::AttrType      # SplitMix64 seed (UInt64)
    Trit::AttrType      # GF(3) trit: {-1, 0, +1}
    Hue::AttrType       # Hue in degrees [0, 360)
    Label::AttrType     # Finder label index (0-7)
    Path::AttrType      # Filesystem path string
    Index::AttrType     # Walk step index (Int)
    
    # Attributes on File
    path::Attr(File, Path)          # Absolute file path
    
    # Attributes on Walk
    walk_index::Attr(Walk, Index)   # Position in walk sequence
    walk_seed::Attr(Walk, Seed)     # Seed state at this step
    
    # Attributes on Color
    hue::Attr(Color, Hue)           # Generated hue (0-360°)
    trit::Attr(Color, Trit)         # GF(3) classification
    label::Attr(Color, Label)       # macOS Finder label (1-7)
    color_seed::Attr(Color, Seed)   # Seed that generated this color
end

# ═══════════════════════════════════════════════════════════════════════════
# ACSet Type Generation
# ═══════════════════════════════════════════════════════════════════════════

@acset_type FileColorWalkData(SchFileColorWalk, 
    index=[:path, :walk_index, :hue])

# ═══════════════════════════════════════════════════════════════════════════
# Helper Functions
# ═══════════════════════════════════════════════════════════════════════════

"""
    hue_to_trit(h::Float64) -> Int

Map hue to GF(3) trit following Gay.jl convention.
- Warm (0-60°, 300-360°) → +1 (PLUS)
- Neutral (60-180°) → 0 (ERGODIC)
- Cold (180-300°) → -1 (MINUS)
"""
function hue_to_trit(h::Float64)::Int
    if h < 60 || h >= 300
        return 1   # PLUS (warm)
    elseif h < 180
        return 0   # ERGODIC (neutral)
    else
        return -1  # MINUS (cold)
    end
end

"""
    hue_to_finder_label(h::Float64) -> Int

Map hue to macOS Finder label index.
"""
function hue_to_finder_label(h::Float64)::Int
    if h < 30
        return 7   # Red
    elseif h < 60
        return 6   # Orange
    elseif h < 90
        return 5   # Yellow
    elseif h < 150
        return 2   # Green
    elseif h < 270
        return 4   # Blue
    elseif h < 330
        return 3   # Purple
    else
        return 7   # Red (330-360)
    end
end

"""
    trit_to_finder_label(t::Int) -> Int

Direct trit to Finder label (simplified mode).
"""
function trit_to_finder_label(t::Int)::Int
    return Dict(-1 => 4, 0 => 2, 1 => 7)[t]  # Blue, Green, Red
end

# ═══════════════════════════════════════════════════════════════════════════
# SplitMix64 RNG (Gay.jl compatible)
# ═══════════════════════════════════════════════════════════════════════════

const GOLDEN = 0x9E3779B97F4A7C15
const MIX1 = 0xBF58476D1CE4E5B9
const MIX2 = 0x94D049BB133111EB

"""
    splitmix64(state::UInt64) -> Tuple{UInt64, UInt64}

SplitMix64 PRNG step. Returns (random_value, new_state).
"""
function splitmix64(state::UInt64)
    z = state + GOLDEN
    z = (z ⊻ (z >> 30)) * MIX1
    z = (z ⊻ (z >> 27)) * MIX2
    return (z ⊻ (z >> 31), state + GOLDEN)
end

"""
    color_at(seed::UInt64, index::Int) -> NamedTuple

Generate color at index using SplitMix64.
"""
function color_at(seed::UInt64, index::Int)
    state = seed
    for _ in 1:index
        _, state = splitmix64(state)
    end
    rand_val, new_state = splitmix64(state)
    
    h = (Float64(rand_val) / Float64(typemax(UInt64))) * 360.0
    t = hue_to_trit(h)
    l = hue_to_finder_label(h)
    
    return (hue=h, trit=t, label=l, seed=new_state)
end

# ═══════════════════════════════════════════════════════════════════════════
# ACSet Construction Helpers
# ═══════════════════════════════════════════════════════════════════════════

"""
    create_walk_instance(seed::UInt64, files::Vector{String}, max_steps::Int)

Create a FileColorWalk ACSet instance from a seed and file list.
"""
function create_walk_instance(seed::UInt64, files::Vector{String}, max_steps::Int=20)
    data = FileColorWalkData()
    
    # Add files
    file_ids = Int[]
    for filepath in files[1:min(length(files), max_steps)]
        id = add_part!(data, :File, path=filepath)
        push!(file_ids, id)
    end
    
    # Generate walk with colors
    prev_walk = nothing
    state = seed
    
    for (i, fid) in enumerate(file_ids)
        # Generate color for this step
        col = color_at(seed, i-1)
        
        # Add color
        cid = add_part!(data, :Color,
            hue = col.hue,
            trit = col.trit,
            label = col.label,
            color_seed = col.seed
        )
        
        # Add walk step
        wid = add_part!(data, :Walk,
            step = fid,
            color_of = cid,
            walk_index = i,
            walk_seed = state
        )
        
        # Link to previous walk step
        if prev_walk !== nothing
            set_subpart!(data, prev_walk, :next, wid)
        end
        prev_walk = wid
        
        _, state = splitmix64(state)
    end
    
    return data
end

"""
    verify_gf3_conservation(data::FileColorWalkData) -> Bool

Verify GF(3) conservation: Σ trits ≡ 0 (mod 3)
"""
function verify_gf3_conservation(data::FileColorWalkData)
    trits = subpart(data, :trit)
    return sum(trits) % 3 == 0
end

"""
    walk_to_derivation_chain(data::FileColorWalkData) -> Vector{NamedTuple}

Export walk as derivational chain (unworld pattern).
"""
function walk_to_derivation_chain(data::FileColorWalkData)
    chain = NamedTuple[]
    
    for w in parts(data, :Walk)
        file_id = subpart(data, w, :step)
        color_id = subpart(data, w, :color_of)
        
        push!(chain, (
            index = subpart(data, w, :walk_index),
            seed = subpart(data, w, :walk_seed),
            path = subpart(data, file_id, :path),
            hue = subpart(data, color_id, :hue),
            trit = subpart(data, color_id, :trit),
            label = subpart(data, color_id, :label)
        ))
    end
    
    return chain
end

# ═══════════════════════════════════════════════════════════════════════════
# Schema Visualization (Mermaid)
# ═══════════════════════════════════════════════════════════════════════════

"""
    schema_to_mermaid() -> String

Generate Mermaid diagram of the schema.
"""
function schema_to_mermaid()
    """
    ```mermaid
    erDiagram
        File {
            Path path
        }
        Walk {
            Index walk_index
            Seed walk_seed
        }
        Color {
            Hue hue
            Trit trit
            Label label
            Seed color_seed
        }
        Walk ||--o{ Walk : next
        Walk }o--|| File : step
        Walk }o--|| Color : color_of
    ```
    """
end

# ═══════════════════════════════════════════════════════════════════════════
# Example Usage
# ═══════════════════════════════════════════════════════════════════════════

#=
# Create a walk instance
files = ["/Users/alice/test1.txt", "/Users/alice/test2.py", "/Users/alice/test3.md"]
data = create_walk_instance(UInt64(0x42D), files, 3)

# Verify GF(3) conservation
println("GF(3) conserved: ", verify_gf3_conservation(data))

# Export derivation chain
chain = walk_to_derivation_chain(data)
for step in chain
    println("  $(step.index): $(basename(step.path)) → label=$(step.label) (trit=$(step.trit))")
end
=#

end  # module implicit
