---
name: finder-color-walk
description: Navigate file systems via deterministic random walks with GF(3)-colored triadic agents and SplitMixTernary seeded traversal.
version: 0.1.0
trit: 0
---

# finder-color-walk

> Navigate file systems via deterministic random walks with GF(3)-colored triadic agents

**Version**: 0.1.0  
**Trit**: 0 (ERGODIC - coordination)  
**Schema**: ACSet-based with Walk, File, Agent, Color objects  
**Algorithm**: SplitMixTernary seeded file traversal

## Overview

**finder-color-walk** combines file system navigation with deterministic coloring:

1. **Random Walk**: Traverse filesystem via seed-deterministic paths
2. **Color Assignment**: Each file gets OkLCH color from Gay-MCP
3. **Triadic Routing**: Walks dispatched to MINUS/ERGODIC/PLUS agents
4. **GF(3) Conservation**: Σ trits ≡ 0 (mod 3) across all walks

## Schema

```julia
@present SchFileColorWalk(FreeSchema) begin
  File::Ob           # Filesystem entries
  Walk::Ob           # Random walk trajectories
  Agent::Ob          # Triadic agents {-1, 0, +1}
  Color::Ob          # Deterministic colors
  
  visits::Hom(Walk, File)
  walker::Hom(Walk, Agent)
  colored::Hom(File, Color)
  step::Hom(Walk, Walk)
  
  seed::Attr(Walk, Seed)
  trit::Attr(Agent, Trit)
  path::Attr(File, Path)
end
```

## Data Migration

| Functor | Operation | Use Case |
|---------|-----------|----------|
| **Δ** | Restrict/Pullback | Filter to visited files |
| **Σ** | Aggregate | Count walks per trit |
| **Π** | Universal | All possible colorings |

## Triadic Agents

| Agent | Trit | Role | Hue Range |
|-------|------|------|-----------|
| MINUS | -1 | Validator | 180-300° (cold) |
| ERGODIC | 0 | Coordinator | 60-180° (neutral) |
| PLUS | +1 | Generator | 0-60°, 300-360° (warm) |

## Fibers

Extract subagent views:

```julia
fiber_minus   = fiber(acset, -1)  # Validation walks
fiber_ergodic = fiber(acset, 0)   # Coordination walks
fiber_plus    = fiber(acset, 1)   # Generation walks
```

## Commands

```bash
# Start walk from directory
just finder-walk ~/projects seed=0x42D

# Extract fiber
just finder-fiber MINUS

# Verify GF(3)
just finder-verify

# Show colors
just finder-colors
```

## Integration

See [INTERLEAVED.md](./INTERLEAVED.md) for the 4-corpus synthesis:
- RelationalThinking-Book: Schemas/instances
- asi-main: Tripartite skills
- py-acsets: Python ACSet
- CatColab: CRDT diagrams

## Key Files

- [`acset.clj`](file:///Users/alice/agent-o-rama/agent-o-rama/src/clj/com/rpl/agent_o_rama/acset.clj) - Core ACSet
- [`ordered_locale.jl`](file:///Users/alice/agent-o-rama/agent-o-rama/dev/gadgets/ordered_locale.jl) - Ordered locale
- [`gay_integration.jl`](file:///Users/alice/agent-o-rama/agent-o-rama/dev/gadgets/gay_integration.jl) - Gay-MCP

---

**Skill Name**: finder-color-walk  
**Type**: File Navigation / ACSet Integration  
**Trit**: 0 (ERGODIC)  
**GF(3)**: Conserved
