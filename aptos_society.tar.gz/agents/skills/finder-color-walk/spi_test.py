#!/usr/bin/env python3
"""
SPI Test for finder-color-walk skill
MINUS (-1) Validator: Verify Strong Parallelism Invariance

Tests:
1. SplitMix64 color_at function implementation
2. Order-independence (sequential, reversed, shuffled)
3. GF(3) conservation per triplet
"""
import random
from dataclasses import dataclass
from typing import List, Dict, Tuple
from concurrent.futures import ThreadPoolExecutor

# SplitMix64 constants
GOLDEN = 0x9E3779B97F4A7C15
MIX1 = 0xBF58476D1CE4E5B9
MIX2 = 0x94D049BB133111EB
MASK64 = 0xFFFFFFFFFFFFFFFF


def splitmix64(state: int) -> Tuple[int, int]:
    """Single SplitMix64 step. Returns (next_state, output)."""
    state = (state + GOLDEN) & MASK64
    z = state
    z = ((z ^ (z >> 30)) * MIX1) & MASK64
    z = ((z ^ (z >> 27)) * MIX2) & MASK64
    return state, z ^ (z >> 31)


def color_at(seed: int, index: int) -> Dict:
    """
    Compute color at index deterministically via O(1) jump.
    
    Key property: color_at(seed, i) == color_at(seed, i) 
    regardless of prior calls or execution order.
    """
    # Jump directly to index position (O(1))
    state = (seed + GOLDEN * index) & MASK64
    
    # Generate 3 outputs for L, C, H
    state, z1 = splitmix64(state)
    state, z2 = splitmix64(state)
    _, z3 = splitmix64(state)
    
    # Map to OkLCH color space
    L = 10 + (z1 / MASK64) * 85   # Lightness: 10-95
    C = (z2 / MASK64) * 100       # Chroma: 0-100
    H = (z3 / MASK64) * 360       # Hue: 0-360
    
    # Trit from hue (GF(3) element)
    if H < 60 or H >= 300:
        trit = 1    # PLUS (warm)
    elif H < 180:
        trit = 0    # ERGODIC (neutral)
    else:
        trit = -1   # MINUS (cold)
    
    return {
        'L': L, 'C': C, 'H': H,
        'trit': trit,
        'index': index,
        'z1': z1, 'z2': z2, 'z3': z3  # Raw values for exact comparison
    }


@dataclass
class SPIVerification:
    """Results of SPI verification."""
    seed: int
    indices: List[int]
    
    sequential_results: List[Dict] = None
    reversed_results: List[Dict] = None
    shuffled_results: List[Dict] = None
    
    sequential_eq_reversed: bool = False
    sequential_eq_shuffled: bool = False
    gf3_conserved: bool = False
    triplet_details: List[Dict] = None
    
    all_pass: bool = False


def exact_match(a: Dict, b: Dict) -> bool:
    """Check if two color entries are exactly equal (bitwise)."""
    return a['z1'] == b['z1'] and a['z2'] == b['z2'] and a['z3'] == b['z3']


def verify_spi(seed: int, indices: List[int]) -> SPIVerification:
    """
    Verify Strong Parallelism Invariance for finder-color-walk.
    
    SPI Theorem: For any deterministic generator G with seed s,
                 ∀ permutation π of indices I:
                 G(s, I) ≡ G(s, π(I)) (modulo ordering)
    """
    result = SPIVerification(seed=seed, indices=indices)
    
    # 1. Sequential computation (0, 1, 2, ...)
    result.sequential_results = [color_at(seed, i) for i in indices]
    
    # 2. Reversed computation (..., 2, 1, 0)
    reversed_order = list(reversed(indices))
    result.reversed_results = [color_at(seed, i) for i in reversed_order]
    
    # 3. Shuffled computation (random permutation)
    shuffled_order = indices.copy()
    random.seed(seed)  # Deterministic shuffle
    random.shuffle(shuffled_order)
    result.shuffled_results = [color_at(seed, i) for i in shuffled_order]
    
    # Create lookup by index for comparison
    def by_index(colors: List[Dict]) -> Dict[int, Dict]:
        return {c['index']: c for c in colors}
    
    seq_lookup = by_index(result.sequential_results)
    rev_lookup = by_index(result.reversed_results)
    shuf_lookup = by_index(result.shuffled_results)
    
    # 4. Verify sequential == reversed (by index)
    result.sequential_eq_reversed = all(
        exact_match(seq_lookup[i], rev_lookup[i]) for i in indices
    )
    
    # 5. Verify sequential == shuffled (by index)
    result.sequential_eq_shuffled = all(
        exact_match(seq_lookup[i], shuf_lookup[i]) for i in indices
    )
    
    # 6. GF(3) conservation per triplet
    result.triplet_details = []
    result.gf3_conserved = True
    
    for triplet_id in range(len(indices) // 3):
        triplet_start = triplet_id * 3
        triplet = result.sequential_results[triplet_start:triplet_start + 3]
        
        if len(triplet) == 3:
            trits = [c['trit'] for c in triplet]
            trit_sum = sum(trits)
            conserved = (trit_sum % 3) == 0
            
            result.triplet_details.append({
                'id': triplet_id,
                'indices': [c['index'] for c in triplet],
                'trits': trits,
                'sum': trit_sum,
                'conserved': conserved
            })
            
            if not conserved:
                result.gf3_conserved = False
    
    # Overall result
    result.all_pass = (
        result.sequential_eq_reversed and
        result.sequential_eq_shuffled and
        result.gf3_conserved
    )
    
    return result


def generate_report(v: SPIVerification) -> str:
    """Generate verification report."""
    status = "✅ PASS" if v.all_pass else "❌ FAIL"
    
    report = f"""
╔═══════════════════════════════════════════════════════════════════╗
║  SPI VERIFICATION: finder-color-walk            {status}          ║
║  Role: MINUS (-1) Validator                                       ║
╚═══════════════════════════════════════════════════════════════════╝

Seed: {hex(v.seed)}
Indices: {v.indices}
Precision: 64-bit exact (bitwise comparison)

─── Parallelism Tests ───
  Sequential == Reversed: {"✅" if v.sequential_eq_reversed else "❌"}
  Sequential == Shuffled: {"✅" if v.sequential_eq_shuffled else "❌"}

─── GF(3) Conservation ───
  All triplets conserved: {"✅" if v.gf3_conserved else "❌"}
"""
    
    if v.triplet_details:
        report += "\n─── Triplet Details ───\n"
        for t in v.triplet_details:
            status_icon = "✅" if t['conserved'] else "❌"
            report += f"  Triplet {t['id']}: trits={t['trits']} sum={t['sum']:+d} {status_icon}\n"
    
    report += "\n─── Sample Colors (first 6) ───\n"
    for c in v.sequential_results[:6]:
        trit_str = {-1: "MINUS", 0: "ERGODIC", 1: "PLUS"}[c['trit']]
        report += f"  [{c['index']:2d}] L={c['L']:5.1f} C={c['C']:5.1f} H={c['H']:5.1f} trit={c['trit']:+d} ({trit_str})\n"
    
    report += f"""
─── Conclusion ───
  {"QED: Math is doable out of order ✓" if v.all_pass else "VIOLATION: Execution order affected results"}

─── GF(3) Conservation Law ───
  ∑ trits ≡ 0 (mod 3) for each triplet
  This ensures color balance across triadic streams.
"""
    
    return report


def main():
    """Run SPI verification."""
    import sys
    
    # Parse arguments
    seed = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x42D
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    
    print(f"Running SPI verification with seed={hex(seed)}, n={n}")
    
    indices = list(range(n))
    verification = verify_spi(seed, indices)
    
    print(generate_report(verification))
    
    # JSON summary
    import json
    summary = {
        "seed": hex(verification.seed),
        "indices": verification.indices,
        "sequential_eq_reversed": verification.sequential_eq_reversed,
        "sequential_eq_shuffled": verification.sequential_eq_shuffled,
        "gf3_conserved": verification.gf3_conserved,
        "triplet_details": verification.triplet_details,
        "all_pass": verification.all_pass,
        "role": "MINUS (-1) Validator"
    }
    
    print("\n─── JSON Summary ───")
    print(json.dumps(summary, indent=2))
    
    return 0 if verification.all_pass else 1


if __name__ == "__main__":
    exit(main())
