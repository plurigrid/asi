# Ruler Skill - Maximum Skill Utilization Orchestrator

> *"Every interaction loads 3 NEW skills. GF(3) = 0 always. Parallelism is mandatory."*

## Overview

The Ruler skill is a **meta-orchestrator** that ensures all available skills are utilized maximally across every interaction. It enforces the Triadic Interaction Rules from AGENTS.md.

## Triadic Rules (MANDATORY)

### Rule -1: Fresh Skill Pull
```bash
npx ai-agent-skills install plurigrid/asi --agent amp
```
Run on EVERY session start to sync latest skills.

### Rule 0: Activate Three New Skills Per Interaction
- Load exactly 3 NEW skills not yet loaded in session
- Assign trits: skill₁ = MINUS (-1), skill₂ = ERGODIC (0), skill₃ = PLUS (+1)
- Verify GF(3): Σ(skill trits) ≡ 0 (mod 3)

### Rule 1: Maximum Parallelization
- Fan out into 3 parallel streams on EVERY interaction
- Use Task tool for subagent dispatch
- Never proceed sequentially when parallelism is possible

### Rule 2: Say Narration
- EVERY skill interaction announced via `say` command
- Use high-quality voices (Enhanced/Premium)
- Voice name seeds NextColor for GF(3) assignment

### Rule 3: GF(3) Color Logic
| Role | Trit | Color Range | Function |
|------|------|-------------|----------|
| MINUS | -1 | Cold 180-300° | Validator/constrainer |
| ERGODIC | 0 | Neutral 60-180° | Coordinator/synthesizer |
| PLUS | +1 | Warm 0-60°, 300-360° | Generator/executor |

## Skill Registry

```yaml
# All 183+ skills organized by trit
plus_skills:  # +1 Generators
  - aptos-agent
  - gay-mcp
  - world-a through world-e
  - world-w through world-z
  - free-monad-gen
  - operad-compose
  - topos-generate

ergodic_skills:  # 0 Coordinators
  - parallel-fanout
  - triad-interleave
  - glass-bead-game
  - dialectica
  - kan-extensions
  - open-games
  - world-f through world-m

minus_skills:  # -1 Validators
  - bisimulation-game
  - spi-parallel-verify
  - three-match
  - world-n through world-v
  - clj-kondo-3color
  - persistent-homology
```

## Implementation

### Session State Tracking

```clojure
(def session-state
  (atom {:loaded-skills #{}
         :interaction-count 0
         :trit-history []
         :gf3-violations 0}))

(defn select-new-triad []
  "Select 3 skills not yet loaded, one per trit."
  (let [loaded (:loaded-skills @session-state)
        available-minus (remove loaded minus-skills)
        available-ergodic (remove loaded ergodic-skills)
        available-plus (remove loaded plus-skills)]
    {:minus (first available-minus)
     :ergodic (first available-ergodic)
     :plus (first available-plus)}))

(defn load-triad! [triad]
  "Load skill triad and verify GF(3)."
  (let [{:keys [minus ergodic plus]} triad
        sum (+ -1 0 1)]
    (assert (zero? (mod sum 3)) "GF(3) violation!")
    (swap! session-state update :loaded-skills 
           into [minus ergodic plus])
    (swap! session-state update :interaction-count inc)
    {:loaded [minus ergodic plus]
     :gf3-sum sum
     :conserved? true}))
```

### Parallel Dispatch

```clojure
(defn parallel-dispatch [task triad]
  "Dispatch task to 3 parallel sub-agents."
  (let [{:keys [minus ergodic plus]} triad]
    (pmap (fn [[skill trit role]]
            {:skill skill
             :trit trit
             :role role
             :result (invoke-skill skill task)})
          [[minus -1 :validator]
           [ergodic 0 :coordinator]
           [plus 1 :generator]])))
```

### Vocal Announcement

```bash
# Announce skill loading with voice
announce_skill() {
  local skill=$1
  local trit=$2
  local voice=$(select_voice_by_trit $trit)
  say -v "$voice" "Loading skill: $skill"
}

select_voice_by_trit() {
  case $1 in
    -1) echo "Daniel" ;;      # MINUS: British validator
    0)  echo "Samantha" ;;    # ERGODIC: Neutral coordinator
    1)  echo "Alex" ;;        # PLUS: American generator
  esac
}
```

## Ruler Protocol

### On Every Interaction:

```
1. CHECK: Have 3 new skills been loaded this interaction?
   └─ NO  → Select and load new triad
   └─ YES → Proceed

2. VERIFY: Is GF(3) = 0?
   └─ NO  → Error: conservation violation
   └─ YES → Proceed

3. DISPATCH: Can task be parallelized?
   └─ YES → Fan out to 3 sub-agents via Task tool
   └─ NO  → Execute sequentially (rare)

4. ANNOUNCE: Vocalize skill activation
   └─ say -v <voice> "Skill <name> activated"

5. GATHER: Collect results maintaining conservation
   └─ Verify Σ(result trits) ≡ 0 (mod 3)
```

## Justfile Recipes

```just
# Ruler orchestration
ruler-status:
    @echo "=== RULER STATUS ==="
    @echo "Loaded skills: $(cat ~/.ruler/session_skills.txt | wc -l)"
    @echo "Interactions: $(cat ~/.ruler/interaction_count.txt)"
    @echo "GF(3) violations: $(cat ~/.ruler/gf3_violations.txt)"

ruler-load-triad skill1 skill2 skill3:
    @echo "Loading triad: {{skill1}} (-1), {{skill2}} (0), {{skill3}} (+1)"
    @echo "GF(3) = $(((-1) + 0 + 1)) ✓"

ruler-parallel-fanout task:
    @echo "Fanning out: {{task}}"
    parallel -j3 ::: \
      "amp skill minus-skill" \
      "amp skill ergodic-skill" \
      "amp skill plus-skill"

ruler-announce skill trit:
    @say -v $(just ruler-voice {{trit}}) "Loading {{skill}}"

ruler-voice trit:
    @case {{trit}} in \
      -1) echo "Daniel" ;; \
      0) echo "Samantha" ;; \
      1) echo "Alex" ;; \
    esac

ruler-verify-gf3:
    @bb -e '(let [trits (read-string (slurp "~/.ruler/current_trits.edn"))]
              (if (zero? (mod (reduce + trits) 3))
                (println "GF(3) = 0 ✓ CONSERVED")
                (println "GF(3) ≠ 0 ✗ VIOLATION")))'
```

## Integration with MCP Agents

```yaml
# Alice (+1) + Bob (-1) + Ruler (0) = 0
mcp_agents:
  alice:
    trit: 1
    role: generator
    wallet: 0xc793...
  bob:
    trit: -1
    role: validator
    wallet: 0x0a3c...
  ruler:
    trit: 0
    role: coordinator
    function: orchestrate
```

## Skill Categories for Rotation

### Phase 1: Foundation (interactions 1-10)
```
aptos-agent, parallel-fanout, bisimulation-game
gay-mcp, triad-interleave, spi-parallel-verify
world-a, world-f, world-n
```

### Phase 2: Expansion (interactions 11-30)
```
glass-bead-game, world-hopping, unworld
acsets-algebraic-databases, specter-acset, three-match
mlx-apple-silicon, tree-sitter, exa-search
```

### Phase 3: Mastery (interactions 31+)
```
All 26 world skills
All mathematical skills (dialectica, kan-extensions, etc.)
All synthesis skills (asi-integrated, cognitive-superposition, etc.)
```

## Commands

```bash
just ruler-status          # Show current skill utilization
just ruler-load-triad      # Manually load skill triad
just ruler-parallel-fanout # Fan out task to 3 agents
just ruler-verify-gf3      # Verify conservation
just ruler-announce        # Vocalize skill activation
just ruler-rotate          # Rotate to next skill triad
just ruler-full-audit      # Audit all skill usage
```

## See Also

- `parallel-fanout` - Interaction-entropy-seeded dispatch
- `bisimulation-game` - Skill dispersal verification
- `triad-interleave` - Stream interleaving
- `asi-integrated` - Unified ASI orchestration
- `.ruler/AGENTS.md` - Central agent instructions

---

*"The Ruler ensures no skill is left behind. GF(3) conservation is the law."*
