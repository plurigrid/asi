---
name: reverse-engineer
description: Reverse engineering skill for analyzing binaries, protocols, and systems to understand their internal workings and implementation details.
version: 1.0.0
trit: -1
---

# Reverse Engineering Skill

**Trit**: -1 (MINUS - analytical deconstruction)

## Overview

Reverse engineering enables understanding systems by analyzing their outputs, behaviors, and structures without access to source documentation.

## Capabilities

- Binary analysis and disassembly
- Protocol reverse engineering
- API discovery through traffic analysis
- Code deobfuscation
- Format analysis

## Tools

| Tool | Purpose |
|------|---------|
| `radare2` | Binary analysis |
| `ghidra` | Decompilation |
| `wireshark` | Network protocol analysis |
| `frida` | Dynamic instrumentation |
| `binwalk` | Firmware extraction |

## Workflow

1. **Observation**: Capture inputs/outputs
2. **Analysis**: Pattern identification
3. **Hypothesis**: Model internal behavior
4. **Validation**: Test predictions
5. **Documentation**: Record findings

## GF(3) Integration

As MINUS trit, this skill validates and constrains hypotheses about system behavior through rigorous analysis.
