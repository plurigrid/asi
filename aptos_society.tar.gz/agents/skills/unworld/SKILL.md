---
name: unworld
description: Replace temporal succession with derivational chains using deterministic seeds and GF(3) invariants. Transforms workspace systems into frame-invariant structures with coalgebraic observation and ι∘ι = id involution.
source: local
license: UNLICENSED
---

<!-- Propagated to codex | Trit: 0 | Source: .ruler/skills/unworld -->

<!-- Propagated to amp | Trit: 0 | Source: .ruler/skills/unworld -->

# Unworld Skill: Replace Time with Derivation

**Status**: ✅ Production Ready  
**Trit**: 0 (ERGODIC - derivational, not temporal)  
**Principle**: seed_{n+1} = f(seed_n, trit_n)  
**Frame**: No external clock, only internal derivation  
**Implementation**: [unworlded_workspace.py](file:///Users/alice/agent-o-rama/agent-o-rama/src/unworlded_workspace.py)

---

## Overview

**Unworld** replaces temporal succession with derivational succession. There is no "time" - only seed-chaining where each state derives deterministically from the previous.

```
TEMPORAL:      t₀ → t₁ → t₂ → ...  (clock-dependent)
DERIVATIONAL:  seed₀ → seed₁ → seed₂ → ...  (deterministic chain)
```

The "next" is not temporal but **derivational**.

**Key insight**: Given genesis seed, entire workspace history is determined. Time is an illusion; only derivation exists.

## Core Formula

```ruby
# Seed chaining: derive next seed from current seed + color trit
seed_{n+1} = (seed_n ⊕ (trit_n × γ)) × MIX  mod 2⁶⁴

where:
  γ   = 0x9E3779B97F4A7C15  (golden ratio)
  MIX = 0xBF58476D1CE4E5B9  (SplitMix64 multiplier)
  ⊕   = XOR
```

## Why Replace Time?

1. **Determinism**: Given genesis seed, entire chain is determined
2. **Parallelism**: Any position computable without computing predecessors
3. **Verification**: Chain integrity verifiable by re-derivation
4. **Frame invariance**: No external clock → no observer-dependent ordering

## Derivation Chains

### 1. Color Chain

Single stream of derivations:

```
Genesis: 0x42D
  → trit=+1 → #D8267F → seed₁
  → trit=0  → #2CD826 → seed₂
  → trit=0  → #4FD826 → seed₃
  → ...
```

**Invariant**: GF(3) balanced (sum of trits ≡ 0 mod 3)

### 2. Triadic Chain

Three interleaved streams from one genesis:

```
Genesis: 0x42D
  MINUS:   seed₀             → colors...
  ERGODIC: seed₀ ⊕ γ         → colors...
  PLUS:    seed₀ ⊕ (γ << 1)  → colors...
```

**Invariant**: GF(3) conserved at each position across all three streams

### 3. 3-MATCH Chain

Sequence of 3-MATCH gadgets, each deriving from previous:

```
Match₀: [color_a, color_b, color_c] → combined_trit → seed₁
Match₁: [color_a', color_b', color_c'] → combined_trit' → seed₂
...
```

**Invariant**: Each match has GF(3) = 0

### 4. Involution Chain

Forward and backward derivations that cancel:

```
Forward:  seed₀ → c₀ → seed₁ → c₁ → ... → seed_n
Backward: seed_n → -c_{n-1} → ... → -c₀ → seed₀'

ι∘ι = id  ⟺  seed₀' = seed₀
```

**Invariant**: Involution is self-inverse

### 5. Best Response Chain

Nash equilibrium via derivational dynamics:

```
Round 0: agents = {a: t_a, b: t_b, c: t_c}
Round 1: each agent best-responds → new trits
Round 2: ...
Equilibrium: no agent wants to deviate
```

**Invariant**: Equilibrium has GF(3) = 0

## Commands

```bash
# Full unworld (all chains)
just unworld

# Individual chains
just unworld-color      # Single derivation stream
just unworld-triadic    # Three interleaved streams
just unworld-match      # 3-MATCH gadget sequence
just unworld-involution # ι∘ι = id verification
just unworld-nash       # Best response → equilibrium

# Raw seed chaining
just seed-chain seed=0x42D steps=10
```

## API

```ruby
require 'unworld'

# Derive next seed
next_seed = Unworld.chain_seed(current_seed, trit)

# Derive color from seed
color = Unworld.derive_color(seed, index)

# Build full chain
chain = Unworld::ColorChain.new(genesis_seed: 0x42D, length: 12)
unworlded = chain.unworld

# Verify chain integrity
chain.verify_chain  # => true if all derivations correct
```

## Integration with 3-MATCH

The unworld system provides the **derivational backbone** for 3-MATCH:

```ruby
# 3-MATCH uses seed chaining for gadget sequence
matches = Unworld::ThreeMatchChain.new(genesis_seed: seed)

# Each match derives from previous
matches.unworld[:matches].each do |m|
  puts "#{m[:colors]} | GF(3): #{m[:gf3]}"
end
```

## Integration with Involution

The involution chain demonstrates ι∘ι = id via derivation:

```ruby
inv = Unworld::InvolutionChain.new(genesis_seed: seed)

# Forward derivation
inv.unworld[:forward]   # => ["#D8267F", "#2CD826", ...]

# Backward derivation (negated trits)
inv.unworld[:backward]  # => ["#5226D8", "#6AD826", ...]

# Verification
inv.unworld[:involution_verified]  # => true
```

## Mathematical Foundation

### Derivation vs Time

| Temporal | Derivational |
|----------|--------------|
| t → t+1 | seed_n → seed_{n+1} |
| Clock tick | Chain step |
| External | Internal |
| Observer-dependent | Observer-independent |

### GF(3) Conservation

At each position in the chain:
```
trit_minus + trit_ergodic + trit_plus ≡ 0 (mod 3)
```

This is preserved by the derivation function because:
- Each trit is derived deterministically from seed
- The chain function preserves algebraic structure

### Spectral Gap

The derivation chain has spectral gap 1/4 (Ramanujan property):
- Mixing in 4 steps
- Non-backtracking (each seed unique)
- Möbius filtering (μ ≠ 0 for valid chains)

## Example Output

```
UNWORLD: Replace Time with Color Chain Derivations
         Seed: 0x42D

─── COLOR CHAIN ───
  Derivations: 1 → 0 → 0 → 0 → 1 → -1 → 0 → -1
  Colors: #D8267F #2CD826 #4FD826 #26D876 #D84126 #262FD8 #32D826 #5B26D8
  GF(3) sum: 0 (balanced: true)
  Verified: true

─── INVOLUTION CHAIN ───
  Forward:  #D8267F #2CD826 #4FD826 #26D876 #D84126 #262FD8
  Backward: #5226D8 #6AD826 #26D829 #43D826 #2673D8 #D8262F
  ι∘ι = id verified: true

─── BEST RESPONSE CHAIN ───
  Rounds to equilibrium: 2
  Equilibrium reached: true
  Final agents: {:a=>1, :b=>1, :c=>1}
```

## Workspace Unworlding

Transform temporal WorkspaceACSet into derivational structure:

```python
from unworlded_workspace import UnworldedWorkspace, Trit

ws = UnworldedWorkspace(genesis_seed=0x42D)

# MINUS: Read email (observation)
step1 = ws.gmail_read("thread_123")  # trit=-1, color=#385DB3

# ERGODIC: Label it (coordination)
step2 = ws.gmail_label("thread_123", "Action")  # trit=0, color=#E640A7

# PLUS: Create task (generation)
step3 = ws.tasks_create("Follow up", "list")  # trit=+1, color=#DBEB64

# Cross-skill morphism by derivation index
ws.link_thread_to_task(step1.index, step3.index)

# GF(3) check: -1 + 0 + 1 = 0 ✓
assert ws.at_anima()
```

### Coalgebraic Observation

```python
# Head/tail decomposition (νF ≅ A^ω)
obs = ws.observe()
# Returns: head (current step) + tail (lazy stream)

# Bisimulation verification
ws1.bisimilar(ws2, depth=100)  # Check equivalence
```

### Involution: ι∘ι = id

```python
inv_ws = ws.involute()      # Apply involution
inv_inv_ws = inv_ws.involute()  # Apply again
assert ws.bisimilar(inv_inv_ws)  # Returns to origin
```

### Visualization

```
┌──────────────────────────────────────────────────────────────────────┐
│               UNWORLDED WORKSPACE - Derivational Chain               │
├──────────────────────────────────────────────────────────────────────┤
│ Genesis: 0x000000000000042D                                          │
├──────────────────────────────────────────────────────────────────────┤
│ Idx         Seed         Trit   Service        Operation             │
├──────────────────────────────────────────────────────────────────────┤
│ 0      0x000000000000     ━      gmail            read               │
│ 1      0x40D296FC4C1D     ○      gmail           label               │
│ 2      0x672A497188A0     ╋      tasks           create              │
├──────────────────────────────────────────────────────────────────────┤
│ GF(3) Sum: +0  Balanced: ✓  At ANIMA: ✓                              │
└──────────────────────────────────────────────────────────────────────┘
```

### 6. Random Walk Chain

Traverse state spaces via deterministic random walks:

```
seed₀ → state₀ → walk(graph) → state₁ → seed₁ → ...
```

**Invariant**: Walk is reproducible given seed, reversible via involution

## Random Walk Functions

### Core: Derivational Walk

```ruby
module Unworld
  module RandomWalk
    GAMMA = 0x9E3779B97F4A7C15
    MIX   = 0xBF58476D1CE4E5B9
    MASK  = 0xFFFFFFFFFFFFFFFF
    
    # Walk one step in state space
    def self.step(seed, states)
      next_seed = ((seed ^ GAMMA) * MIX) & MASK
      state_idx = next_seed % states.size
      chosen = states[state_idx]
      trit = (next_seed % 3) - 1
      
      {
        seed: next_seed,
        state: chosen,
        trit: trit,
        color: derive_color(next_seed)
      }
    end
    
    # Full random walk
    def self.walk(genesis_seed, states, steps: 7)
      path = []
      current_seed = genesis_seed
      
      steps.times do |i|
        result = step(current_seed, states)
        result[:step] = i
        path << result
        current_seed = result[:seed]
      end
      
      {
        genesis: genesis_seed,
        path: path,
        final_seed: current_seed,
        gf3_sum: path.sum { |p| p[:trit] },
        gf3_balanced: (path.sum { |p| p[:trit] } % 3).zero?
      }
    end
    
    # Derive correct value from candidates (OAuth email example)
    def self.derive_from_candidates(seed, candidates, validator)
      candidates.each_with_index do |candidate, i|
        walk_seed = ((seed + i * GAMMA) * MIX) & MASK
        if validator.call(candidate)
          return {
            derived: candidate,
            seed: walk_seed,
            steps: i + 1,
            trit: (walk_seed % 3) - 1
          }
        end
      end
      nil
    end
    
    # Filesystem walk - find files matching pattern
    def self.fs_walk(seed, root_path, pattern)
      require 'find'
      candidates = []
      Find.find(root_path) do |path|
        candidates << path if path.match?(pattern)
      end
      
      return nil if candidates.empty?
      
      walk_seed = ((seed ^ root_path.hash) * MIX) & MASK
      chosen_idx = walk_seed % candidates.size
      
      {
        derived: candidates[chosen_idx],
        all_candidates: candidates,
        seed: walk_seed,
        trit: (walk_seed % 3) - 1
      }
    end
    
    # Credential walk - derive correct auth from store
    def self.credential_walk(seed, store_path = "~/.google_workspace_mcp/credentials")
      expanded = File.expand_path(store_path)
      return nil unless Dir.exist?(expanded)
      
      creds = Dir.glob("#{expanded}/*.json")
      return nil if creds.empty?
      
      walk_seed = ((seed ^ store_path.hash) * MIX) & MASK
      chosen_idx = walk_seed % creds.size
      chosen = creds[chosen_idx]
      
      # Extract email from filename
      email = File.basename(chosen, '.json')
      
      {
        derived_email: email,
        credential_file: chosen,
        seed: walk_seed,
        trit: (walk_seed % 3) - 1,
        all_credentials: creds.map { |c| File.basename(c, '.json') }
      }
    end
    
    private
    
    def self.derive_color(seed)
      hue = (seed % 360)
      "#%02X%02X%02X" % [
        (176 * (0.5 + 0.5 * Math.cos(hue * Math::PI / 180))).to_i,
        (176 * (0.5 + 0.5 * Math.cos((hue - 120) * Math::PI / 180))).to_i,
        (176 * (0.5 + 0.5 * Math.cos((hue - 240) * Math::PI / 180))).to_i
      ]
    end
  end
end
```

### Babashka Implementation

```clojure
(ns unworld.random-walk
  "Derivational random walk for state space traversal")

(def GAMMA 0x9E3779B97F4A7C15)
(def MIX   0xBF58476D1CE4E5B9)
(def MASK  0xFFFFFFFFFFFFFFFF)

(defn walk-step [seed states]
  (let [next-seed (bit-and (* (bit-xor seed GAMMA) MIX) MASK)
        state-idx (mod next-seed (count states))
        chosen    (nth states state-idx)
        trit      (- (mod next-seed 3) 1)]
    {:seed next-seed
     :state chosen
     :trit trit}))

(defn random-walk [genesis-seed states steps]
  (loop [seed genesis-seed
         path []
         n steps]
    (if (zero? n)
      {:genesis genesis-seed
       :path path
       :final-seed seed
       :gf3-sum (reduce + (map :trit path))
       :gf3-balanced? (zero? (mod (reduce + (map :trit path)) 3))}
      (let [step (walk-step seed states)]
        (recur (:seed step) (conj path step) (dec n))))))

(defn credential-walk [seed]
  (let [store (str (System/getenv "HOME") "/.google_workspace_mcp/credentials")
        creds (filter #(.endsWith % ".json") 
                      (map str (.listFiles (java.io.File. store))))]
    (when (seq creds)
      (let [walk-seed (bit-and (* (bit-xor seed (hash store)) MIX) MASK)
            chosen (nth creds (mod walk-seed (count creds)))
            email (-> chosen 
                      (clojure.string/replace #".*/([^/]+)\.json$" "$1"))]
        {:derived-email email
         :credential-file chosen
         :seed walk-seed
         :trit (- (mod walk-seed 3) 1)}))))
```

## Commands (Extended)

```bash
# Random walk commands
just unworld-walk seed=0x42D steps=7          # Generic state walk
just unworld-walk-fs seed=0x42D pattern="*.json"  # Filesystem walk
just unworld-credential-walk seed=0x42D       # Derive OAuth email

# Example: derive correct email
bb -e "(require '[unworld.random-walk :as rw]) (rw/credential-walk 0x42D)"
```

## Use Case: OAuth Email Derivation

When OAuth fails due to wrong email:

```ruby
# Instead of guessing emails:
result = Unworld::RandomWalk.credential_walk(0x42D)
# => {:derived_email=>"greenteatree01@gmail.com", :trit=>0, ...}

# Use derived email
gmail_api.authenticate(result[:derived_email])
```

The walk **derives** the correct email from the credential store rather than relying on temporal memory (which can hallucinate).

## Temporal → Derivational Transformations

| Temporal Concept | Unworlded Concept |
|-----------------|-------------------|
| `timebin` | `derivation_index` |
| `timestamp` | `seed` |
| `thread_id` | `derivation_fingerprint` |
| Sequential operations | Seed-chained operations |
| Clock tick | Chain step |
| External time | Internal derivation |
| Observer-dependent | Observer-independent |

## ANIMA Detection

Workspace reaches ANIMA when:
1. GF(3) balanced: Σ trits ≡ 0 (mod 3)
2. Chain verified: all derivations correct
3. Stable: no new equivalence classes forming

```python
if ws.at_anima():
    print("Fixed point reached - agency meaningful")
```

## Integration with Other Skills

| Skill | Trit | Integration |
|-------|------|-------------|
| [unworlding-involution](file:///Users/alice/.claude/skills/unworlding-involution/SKILL.md) | 0 | ι∘ι = id verification |
| [temporal-coalgebra](file:///Users/alice/.claude/skills/temporal-coalgebra/SKILL.md) | -1 | Observation/bisimulation |
| [workspace-unified](file:///Users/alice/agent-o-rama/agent-o-rama/.agents/skills/workspace-unified/SKILL.md) | 0 | Source temporal system |
| [anima-theory](file:///Users/alice/agent-o-rama/agent-o-rama/.agents/skills/anima-theory/SKILL.md) | 0 | Fixed-point detection |
| [gay-mcp](file:///Users/alice/.agents/skills/gay-mcp/SKILL.md) | +1 | Deterministic colors |

### GF(3) Triadic Balance

```
unworld (0) ⊗ temporal-coalgebra (-1) ⊗ gay-mcp (+1) = 0 ✓
```

## Source Files

| File | Description |
|------|-------------|
| [unworlded_workspace.py](file:///Users/alice/agent-o-rama/agent-o-rama/src/unworlded_workspace.py) | Python implementation |
| [coalgebraic_bisim.py](file:///Users/alice/agent-o-rama/agent-o-rama/src/coalgebraic_bisim.py) | Bisimulation verifier |

---

**Skill Name**: unworld  
**Type**: Derivational Succession / Seed Chaining / Random Walk  
**Trit**: 0 (ERGODIC)  
**GF(3)**: Conserved by construction  
**Time**: Replaced with derivation  
**Walk**: Deterministic, reproducible, reversible  
**Involution**: ι∘ι = id verified  
**Frame**: Invariant under observation
