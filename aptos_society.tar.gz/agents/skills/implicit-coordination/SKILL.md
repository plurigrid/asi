---
name: implicit-coordination
description: Enable distributed agents to synchronize without explicit communication via shared seeds, convention-based discovery, and bisimulation equivalence.
version: 1.0.0
trit: 0
---

# Implicit Coordination Skill

> *"When two systems share a seed, they share a world."*

## Overview

**Implicit coordination** enables distributed agents to synchronize without explicit communication by leveraging:

1. **Shared Seeds**: Deterministic behavior from common starting points (1069)
2. **Convention-Based Discovery**: Known ports, paths, naming patterns
3. **Bisimulation Equivalence**: Both sides observe and react identically
4. **Ordered Locale Navigation**: Directed ≪ relations for state transitions

```
┌─────────────────────────────────────────────────────────────────┐
│                    IMPLICIT COORDINATION                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   Agent A (2-monad)              Agent B (Causality)            │
│   ┌─────────────┐                ┌─────────────┐                │
│   │ seed: 1069  │                │ seed: 1069  │                │
│   │ port: 8765  │ ───────────────│ knows: 8765 │                │
│   │ path: ~/    │   IMPLICIT     │ path: ~/    │                │
│   │ ducklake    │   KNOWLEDGE    │ ducklake    │                │
│   └─────────────┘                └─────────────┘                │
│                                                                  │
│   No handshake needed. Same seed → same expectations.           │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Core Principles

### 1. Shared Seed Protocol

Both agents derive behavior from seed 1069:

```clojure
(def COORDINATION-SEED 1069)

(defn derive-port [seed service]
  (+ 8000 (mod (* seed (hash service)) 1000)))
;; (derive-port 1069 :ducklake) => 8765

(defn derive-path [seed name]
  (str "~/ducklake/" name ".duckdb"))
;; Convention: all agents know this pattern
```

### 2. Convention Matrix

| Convention | Value | Derivation |
|------------|-------|------------|
| HTTP Port | 8765 | `8000 + (1069 * hash(:http)) mod 1000` |
| DuckDB Path | `~/ducklake/` | Universal convention |
| File Name | `trit_stream.duckdb` | Seed-derived |
| Tailscale | 100.x.x.x mesh | Pre-established |
| Transfer Method | HTTP pull | Fallback when push fails |

### 3. State Machine (Implicit)

Both agents run the same state machine without coordination:

```
IDLE → SERVING → WAITING → COMPLETE

Agent A (sender):
  IDLE: Check if Causality reachable
  SERVING: Start HTTP server on derived port
  WAITING: Keep alive until pulled
  COMPLETE: Detect pull via access log

Agent B (receiver):
  IDLE: Check if 2-monad serving
  DISCOVERING: Poll derived port
  PULLING: curl from known URL
  COMPLETE: Verify hash
```

### 4. Bisimulation Verification

Both agents are **bisimilar** if they cannot be distinguished:

```python
def implicit_bisimulation(agent_a, agent_b):
    """Verify agents coordinate implicitly."""
    
    # Same seed → same derived values
    assert agent_a.seed == agent_b.seed
    
    # Same conventions → same expectations
    assert agent_a.derive_port() == agent_b.expected_port()
    assert agent_a.derive_path() == agent_b.expected_path()
    
    # Same state machine → same transitions
    for state in STATES:
        assert agent_a.next_state(state) == agent_b.next_state(state)
    
    return True  # Bisimilar → implicit coordination works
```

## Implementation

### For Sender (2-monad)

```bash
#!/usr/bin/env bash
# implicit_serve.sh - No coordination, just serve

SEED=1069
PORT=$((8000 + (SEED * 12345) % 1000))  # 8765
FILE="trit_stream.duckdb"
DIR=$(pwd)

echo "Implicit coordination active"
echo "Seed: $SEED"
echo "Port: $PORT"
echo "File: $FILE"

# Serve - receiver knows where to look
cd $DIR && python3 -m http.server $PORT

# That's it. No handshake. Receiver will pull.
```

### For Receiver (Causality)

```bash
#!/usr/bin/env bash
# implicit_pull.sh - No coordination, just pull

SEED=1069
PORT=$((8000 + (SEED * 12345) % 1000))  # 8765
FILE="trit_stream.duckdb"
SENDER_IP="100.87.209.11"  # Convention: Tailscale mesh

# Derive destination
mkdir -p ~/ducklake

# Pull from derived location
curl -o ~/ducklake/$FILE http://$SENDER_IP:$PORT/$FILE

# Verify
duckdb ~/ducklake/$FILE "SELECT count(*) FROM frames;"
```

## GF(3) Triad Assignment

| Role | Trit | Agent | Action |
|------|------|-------|--------|
| GENERATOR (+1) | +1 | 2-monad | Serves file |
| COORDINATOR (0) | 0 | Convention | Defines ports/paths |
| VALIDATOR (-1) | -1 | Causality | Pulls and verifies |

**Conservation**: +1 + 0 + (-1) = 0 ✓

## Voice Announcements

### 2-monad (Sender)

```bash
say -v "Ava (Premium)" "Implicit coordination. Seed ten sixty-nine. Port eighty-seven sixty-five. Serving DuckLake. Causality knows where to find it."
```

### Causality (Receiver)

```bash
say -v "Luca (Italian)" "Coordinazione implicita. Seed mille sessantanove. Pulling from two monad. DuckLake downloading."
```

## Maximum Information Transfer

The protocol maximizes information by:

1. **No handshake overhead**: Zero round-trips for coordination
2. **Convention as compression**: Shared knowledge = shared entropy
3. **Seed determinism**: Any derived value is implicitly known
4. **Pull semantics**: Receiver controls timing (async friendly)

### Information-Theoretic View

```
H(coordination) = H(seed) + H(convention)

With shared seed:
  H(seed | shared) = 0  # No uncertainty
  
With shared conventions:
  H(convention | shared) = 0  # No uncertainty

Total coordination overhead:
  H(coordination) = 0 bits  # Perfect implicit coordination
```

## Integration with Other Skills

### parallel-fanout
- Trifurcate coordination into GENERATOR/COORDINATOR/VALIDATOR
- Each stream runs independently with shared seed

### bisimulation-game
- Verify both agents are behaviorally equivalent
- Attacker cannot distinguish 2-monad from Causality behavior

### localsend-mcp
- Fallback when HTTP pull unavailable
- Voice announcements for human-in-loop

### glass-hopping
- Navigation between worlds via implicit bridges
- Ordered locale structure for state transitions

## Commands

```bash
# Sender commands
just implicit-serve           # Start serving on derived port
just implicit-announce        # Voice announce availability
just implicit-status          # Show serving status

# Receiver commands  
just implicit-pull SENDER     # Pull from sender
just implicit-verify          # Verify received file
just implicit-complete        # Announce completion

# Both
just implicit-seed            # Show derived values from seed
just implicit-test            # Test coordination
```

## Protocol Diagram

```
2-monad                        Causality
   │                              │
   │  [seed=1069]                 │  [seed=1069]
   │  derive(port=8765)           │  derive(port=8765)
   │  derive(path=ducklake)       │  derive(path=ducklake)
   │                              │
   ├──HTTP server on 8765────────►│
   │                              │
   │                              ├──Poll port 8765
   │                              │
   │◄─────────────────────────────┤  GET /trit_stream.duckdb
   │                              │
   │  200 OK + file data ─────────►│
   │                              │
   │  [log: IP pulled file]       │  [verify: hash match]
   │                              │
   │  COMPLETE                    │  COMPLETE
   │                              │
   └──No explicit coordination────┘
```

## Error Handling

| Failure | Implicit Recovery |
|---------|-------------------|
| Port blocked | Try port+1, port+2 (derived sequence) |
| IP changed | Query Tailscale for current IP |
| File missing | Retry with exponential backoff |
| Hash mismatch | Re-pull with fresh connection |

All recovery follows deterministic patterns from seed.

---

**Skill Name**: implicit-coordination
**Type**: Protocol / Synchronization
**Trit**: 0 (ERGODIC - the convention itself is neutral)
**Seed**: 1069
**Key Insight**: Shared seed + shared conventions = zero-overhead coordination
