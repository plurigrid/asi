# Local MCP Tool Use

This skill enables using locally configured MCP (Model Context Protocol) servers.

## Configuration

MCP servers are configured in `~/.mcp.json`. The file structure:

```json
{
  "mcpServers": {
    "server-name": {
      "command": "executable",
      "args": ["arg1", "arg2"],
      "cwd": "/optional/working/directory",
      "env": {
        "ENV_VAR": "value"
      }
    }
  }
}
```

## Using MCP Resources

To read from an MCP server, use the `read_mcp_resource` tool:

```json
{"server": "server-name", "uri": "resource-uri"}
```

## Currently Configured Servers

Check `~/.mcp.json` for the current list. Common servers include:

- **exa**: Exa search API (semantic web search)
- **playwright**: Browser automation
- **babashka**: Clojure scripting
- **signal**: Signal messaging

## Adding New MCP Servers

1. Edit `~/.mcp.json`
2. Add a new entry under `mcpServers`
3. Restart Amp to load the new server

## Troubleshooting

- Ensure the server command is installed and accessible
- Check environment variables are set correctly
- Verify the server starts successfully by running the command manually
