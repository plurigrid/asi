---
name: aptos-agent
description: Interact with Aptos blockchain - check balances, transfer APT, swap tokens, stake, and execute Move view functions. Features game-theoretic decision analysis with Nash equilibrium detection. All transactions require explicit approval.
compatibility: Requires Node.js, aptos-claude-agent built. Wallet keys in environment.
trit: 1
---

# Aptos Claude Agent

Aptos blockchain interaction with game-theoretic decision analysis.

**Trit**: +1 (PLUS - generator/executor)
**Color Range**: Warm hues (0-60°, 300-360°)
**Role**: Transaction generation and execution

## Skill Loading Adjunction

The skill loading mechanism forms an adjunction `L ⊣ R`:

```
         L (Load/Free)
SkillCatalog ──────────────────→ LoadedSkills
      ↑                               │
      │   η (unit)    ε (counit)      │
      │                               ↓
      └───────────────────────────────
         R (Execute/Forgetful)
```

**Triangle Identities** (effortless bidirection):
- `(εL) ∘ (Lη) = id_SkillCatalog` → load then unload = no-op
- `(Rε) ∘ (ηR) = id_SkillExecution` → execute then reload = same state

This aligns with Block-STM's Strong Parallelism Invariance (SPI):
  `∀ permutation π of transactions T: Execute(T) ≡ Execute(π(T))`

## GF(3) Skill Triad

| Role | Trit | Skills | Color Range |
|------|------|--------|-------------|
| MINUS | -1 | reverse-engineer, validator-* | Cold (180-300°) |
| ERGODIC | 0 | transcript-aqua, gay-mcp | Neutral (60-180°) |
| PLUS | +1 | **aptos-agent**, synthetic-adjunctions | Warm (0-60°, 300-360°) |

Conservation: `(-1) + 0 + (+1) = 0 (mod 3)` ✓

## When to Use

- Check APT wallet balances
- Transfer APT tokens
- Swap tokens on DEX (Liquidswap, etc.)
- Stake APT
- Call Move view functions
- Process natural language blockchain intents
- Query NFT/token collections
- Interact with multisig accounts

## Setup

MCP server configured in `~/.mcp.json`:
```json
{
  "aptos": {
    "command": "node",
    "args": ["/path/to/aptos-claude-agent/dist/mcp/server.js"],
    "env": {
      "APTOS_NETWORK": "mainnet",
      "APTOS_PRIVATE_KEY": "${APTOS_PRIVATE_KEY}"
    }
  }
}
```

## Available MCP Tools

| Tool | Description |
|------|-------------|
| `aptos_balance` | Get wallet balance |
| `aptos_transfer` | Transfer APT (requires approval) |
| `aptos_swap` | Swap tokens on DEX (requires approval) |
| `aptos_stake` | Stake APT (requires approval) |
| `aptos_view` | Read-only view function call |
| `aptos_intent` | Process natural language intent |
| `aptos_approve` | Approve/reject pending decision |
| `aptos_pending` | List pending decisions |

## Security Model

1. **Simulation First**: All transactions simulated before execution
2. **Approval Required**: Every state-changing operation needs explicit approval
3. **Game-Theoretic Analysis**: Transactions modeled as open games
4. **Wallet Validation**: ALWAYS validate key→address before funding

## CRITICAL: Wallet Derivation Safety

**NEVER use `derive-resource-account-address` for wallet creation.**

### Correct Workflow
```bash
# 1. Generate key
aptos key generate --output-file my_key

# 2. Derive address FROM PRIVATE KEY
aptos init --private-key-file my_key --network mainnet --profile my_wallet

# 3. VALIDATE before funding
just aptos-validate "PRIVATE_KEY" "EXPECTED_ADDRESS"

# 4. Only fund AFTER validation passes
```

### What Can Go Wrong
- Using `derive-resource-account-address` with pubkey = **PERMANENT FUND LOSS**
- Resource accounts need signer capabilities from source account
- If key doesn't match address, funds are unrecoverable

### Validation
Run `just aptos-validate-all` to verify all configured wallets before any funding operation.

---

## Aptos Framework Reference (0x1)

### Core Modules

| Module | Purpose |
|--------|---------|
| `0x1::coin` | Legacy fungible token standard |
| `0x1::fungible_asset` | New FA standard (object-based) |
| `0x1::aptos_coin` | Native APT token |
| `0x1::account` | Account creation/management |
| `0x1::object` | Object model foundation |
| `0x1::stake` | Validator staking |
| `0x1::delegation_pool` | Delegated staking |
| `0x1::multisig_account` | Multi-signature accounts |
| `0x1::aptos_governance` | On-chain governance |
| `0x1::code` | Module deployment |

### 0x1::coin Module

**Key Structs:**
- `Coin<CoinType>` - Fungible token container
- `CoinStore<CoinType>` - Account balance storage
- `CoinInfo<CoinType>` - Token metadata
- `MintCapability<CoinType>` - Minting rights
- `BurnCapability<CoinType>` - Burning rights
- `FreezeCapability<CoinType>` - Freeze rights

**View Functions:**
```move
0x1::coin::balance<CoinType>(owner: address): u64
0x1::coin::is_account_registered<CoinType>(account: address): bool
0x1::coin::name<CoinType>(): vector<u8>
0x1::coin::symbol<CoinType>(): vector<u8>
0x1::coin::decimals<CoinType>(): u8
0x1::coin::supply<CoinType>(): Option<u128>
```

**Entry Functions:**
```move
0x1::coin::transfer<CoinType>(from: &signer, to: address, amount: u64)
0x1::coin::register<CoinType>(account: &signer)
```

### 0x1::fungible_asset Module

**Key Structs:**
- `Metadata` - Asset metadata object
- `FungibleStore` - Balance storage
- `FungibleAsset` - Asset container
- `MintRef`, `BurnRef`, `TransferRef` - Capabilities

**View Functions:**
```move
0x1::fungible_asset::balance<T>(store: Object<T>): u64
0x1::primary_fungible_store::balance(account: address, metadata: Object<Metadata>): u64
```

### 0x1::stake Module

**Key Structs:**
- `StakePool` - Validator stake pool
- `ValidatorConfig` - Validator configuration
- `OwnerCapability` - Pool ownership

**View Functions:**
```move
0x1::stake::get_validator_state(pool_address: address): u64
0x1::stake::get_stake(pool_address: address): (u64, u64, u64, u64)
```

### 0x1::delegation_pool Module

**View Functions:**
```move
0x1::delegation_pool::get_stake(pool_address: address, delegator: address): (u64, u64, u64)
0x1::delegation_pool::calculate_and_update_voter_total_voting_power(pool_address: address): u64
```

### 0x1::multisig_account Module

**Key Functions:**
```move
0x1::multisig_account::create(owner: &signer, num_signatures_required: u64, owners: vector<address>)
0x1::multisig_account::create_transaction(multisig: address, payload: vector<u8>)
0x1::multisig_account::approve_transaction(owner: &signer, multisig: address, sequence_number: u64)
0x1::multisig_account::execute_transaction(multisig: address, sequence_number: u64)
```

---

## Token Standards Reference

### Legacy Token (0x3::token)

**Key Structs:**
- `Token` - Token instance with id, amount, properties
- `TokenId` - Global unique identifier (creator + collection + name + version)
- `TokenData` - Shared metadata (max supply, uri, royalty)
- `TokenStore` - Account's token holdings
- `CollectionData` - Collection metadata
- `Royalty` - Royalty configuration

**Entry Functions:**
```move
0x3::token::create_collection_script(creator: &signer, name: String, description: String, uri: String, maximum: u64)
0x3::token::create_token_script(creator: &signer, collection: String, name: String, description: String, ...)
0x3::token::mint_script(creator: &signer, token_data_address: address, collection: String, name: String, amount: u64)
0x3::token::direct_transfer_script(sender: &signer, receiver: &signer, creators_address: address, ...)
```

**View Functions:**
```move
0x3::token::balance_of(owner: address, id: TokenId): u64
0x3::token::get_royalty(token_data_id: TokenDataId): Royalty
0x3::token::get_token_supply(creator: address, collection: String, name: String): Option<u64>
```

### Digital Asset (0x4::token + 0x4::aptos_token)

**Key Structs (0x4::token):**
- `Token` - Object-based token with collection, index, description, name
- `BurnRef` - Burning capability
- `MutatorRef` - Mutation capability

**Key Structs (0x4::aptos_token):**
- `AptosCollection` - No-code collection with mutability settings
- `AptosToken` - Minimally viable token

**Entry Functions:**
```move
0x4::aptos_token::create_collection(creator: &signer, description: String, name: String, uri: String, ...)
0x4::aptos_token::mint(creator: &signer, collection: String, description: String, name: String, uri: String, ...)
0x4::aptos_token::mint_token_object(creator: &signer, collection: String, ...) -> Object<AptosToken>
0x4::aptos_token::burn(owner: &signer, token: Object<AptosToken>)
0x4::aptos_token::freeze_transfer(creator: &signer, token: Object<AptosToken>)
0x4::aptos_token::set_description(creator: &signer, token: Object<AptosToken>, description: String)
```

**View Functions:**
```move
0x4::token::creator(token: Object<Token>): address
0x4::token::collection_name(token: Object<Token>): String
0x4::aptos_token::are_properties_mutable(token: Object<AptosToken>): bool
0x4::aptos_token::is_burnable(token: Object<AptosToken>): bool
```

### Supporting Modules

**0x4::collection:**
```move
0x4::collection::count(collection: Object<Collection>): Option<u64>
0x4::collection::creator(collection: Object<Collection>): address
0x4::collection::name(collection: Object<Collection>): String
```

**0x4::royalty:**
```move
0x4::royalty::get(token: Object<Token>): Option<Royalty>
0x4::royalty::payee_address(royalty: &Royalty): address
0x4::royalty::numerator(royalty: &Royalty): u64
0x4::royalty::denominator(royalty: &Royalty): u64
```

**0x4::property_map:**
```move
0x4::property_map::read_string(object: &Object<T>, key: &String): String
0x4::property_map::read_u64(object: &Object<T>, key: &String): u64
0x4::property_map::read_bool(object: &Object<T>, key: &String): bool
```

---

## Common View Function Patterns

### Check APT Balance
```
aptos_view(
  functionId: "0x1::coin::balance",
  typeArgs: ["0x1::aptos_coin::AptosCoin"],
  args: ["0xADDRESS"]
)
```

### Check Token Balance (Legacy)
```
aptos_view(
  functionId: "0x3::token::balance_of",
  typeArgs: [],
  args: ["0xOWNER", { token_data_id: {...}, property_version: 0 }]
)
```

### Check Stake
```
aptos_view(
  functionId: "0x1::stake::get_stake",
  typeArgs: [],
  args: ["0xVALIDATOR_POOL"]
)
```

### Check Delegation
```
aptos_view(
  functionId: "0x1::delegation_pool::get_stake",
  typeArgs: [],
  args: ["0xPOOL", "0xDELEGATOR"]
)
```

---

## Game-Theoretic Features

### Nashator Analysis
Computes deviation incentives for transactions:
- **LAX monoidal** (`fire`): Actual execution
- **STRONG monoidal** (`exec`): Simulation only

### Bisimulation Self-Play
Explores alternatives via attacker/defender games. Equilibrium detected when `|utility - quality| < 0.15`.

### Risk Visualization
Decisions map to colors via deterministic LCG:
- **HOT ZONE [160-220]**: High-risk indices

---

## DeFi Protocols on Aptos

| Protocol | Category | Key Functions |
|----------|----------|---------------|
| **Liquidswap** | DEX | Swap, add/remove liquidity |
| **Thala** | DEX + Stablecoin | MOD stablecoin, LP farming |
| **Amnis Finance** | Liquid Staking | stAPT, 7-8% APY |
| **Aries Markets** | Lending | Supply, borrow, liquidate |
| **Cellana** | DEX | ve(3,3) model |
| **Echo Protocol** | BTC Bridge | Cross-chain BTC |

---

## Data Availability Layer (DAS-Inspired)

Based on Valeria Nikolaenko's research on Danksharding, this skill incorporates data availability patterns for Aptos:

### KZG Polynomial Commitments

Aptos uses similar commitment schemes for transaction batching:

```
Data Vector → Polynomial Interpolation → KZG Commitment (constant size)
   [y₀...y₄₀₉₅]     f(i) = yᵢ              Cf = G₁^f(τ)
```

**Properties:**
- **Binding**: Cannot open to different polynomial
- **Constant Size**: Single G₁ element regardless of data size
- **Selective Disclosure**: Open any element with short proof

### Reed-Solomon Erasure Coding

For distributed validator storage:

```
Original Data (n=4096) → Extended (2n=8192)
   [d₀...d₄₀₉₅]    → [d₀...d₄₀₉₅, e₄₀₉₆...e₈₁₉₁]
                         ↓
            Any 50% sufficient for reconstruction
```

### Byzantine Resilient Dispersal/Retrieval

```
    DISPERSAL (Alice)                      RETRIEVAL (Bob)
    ─────────────────                      ────────────────
         ┌───┐                                  
    B ───│ C │─── E ───┬─── H ─ E₁ ───┐        
         └───┘         │               │   ┌────────┐
    Vector             ├─── 😈 E₂ ───X│───│ Filter │──→ E' ──→ B = G'⁻¹·E'
    commitments        │               │   │   H    │
                       ├─── H ─ E₃ ───┤   └────────┘
    G·B → E            │               │
                       ├─── 😈 E₄ ───X│   Retriever (Bob):
                       │               │   • Wait for 50% replies with consistent H
                       └─── H ─ E₅ ───┘   • Filter Eᵢ not matching H
                                          • Erasure-decode to reconstruct B
```

**Encoding**: `G · B → E` (generator matrix × block → encoded chunks)  
**Decoding**: `B = G'⁻¹ · E'` (inverse of submatrix × filtered chunks)

### Data Availability Sampling (DAS)

```
Sampling Probability:
  P(block unavailable | sample returns valid) = 0.75
  
After k samples:
  P(false positive) = 0.75^k → negligible
```

### Bivariate Extension for Local Reconstruction

```
     Columns (validators)
     ↓
   [D D D D | E E E E]  ← Original + Extended (right)
   [D D D D | E E E E]
   [D D D D | E E E E]  Rows
   [D D D D | E E E E]  (blobs)
   [---------------]
   [E E E E | E E E E]  ← Extended (down)
   [E E E E | E E E E]

Validator receives: 2 rows + 2 columns (16-wide)
Local reconstruction: Need only 50% of intersecting peers
```

### Homomorphic Properties Required

| Property | KZG | Needed For |
|----------|-----|------------|
| `C(f) + C(g) = C(f+g)` | ✓ | Extended commitment verification |
| `π(f,α) + π(g,α) = π(f+g,α)` | ✓ | Local proof reconstruction |

### 75% Threshold Analysis

Worst-case for row/column reconstruction:
```
[■ ■ ■ ■ | □ □ □ □]
[■ ■ ■ ■ | □ □ □ □]
[■ ■ ■ ■ | □ □ □ □]
[■ ■ ■ ■ | □ □ □ □]
[---------------]
[□ □ □ □ | □ □ □ □]  ← No row/column has 50%
[□ □ □ □ | □ □ □ □]

■ = present (75% - ε), □ = missing
```

With bivariate interpolation: **25% sufficient** (open problem: efficient algorithms)

---

## Aptos Block Data Structure

```
┌─────────────────────────────────────────────┐
│ Block Header                                │
├─────────────────────────────────────────────┤
│ Execution Data (0.1 MB)                     │  ← Fully replicated
│   - Transactions                            │
│   - State transitions                       │
├─────────────────────────────────────────────┤
│ Blob Commitments [C₁, C₂, ..., C₂₅₆]       │  ← Persisted
├─────────────────────────────────────────────┤
│ Data Blobs (0.5-30 MB)                      │  ← Distributed + Expiry
│   - Roll-up transaction lists               │
│   - DA layer storage                        │
└─────────────────────────────────────────────┘
```

### Validator Attestation (Danksharding-Style)

Validator attests to block Bₙ iff:
1. DAS sampling successful for blocks B₁...Bₙ₋₁
2. Received correct fragments (2 rows + 2 cols per block)
3. Fragments verify against extended commitments

---

## GF(3) Color Assignment for Validators

Using Gay-MCP deterministic coloring for validator fragment assignment:

```python
from gay import SplitMixTernary

# Seed from block hash
gen = SplitMixTernary(seed=block_hash)

# Assign validators to fragment types via trit
def assign_fragment_role(validator_index: int) -> str:
    color = gen.color_at(validator_index)
    trit = color['trit']
    
    if trit == -1:   # MINUS (cold hues 180-300°)
        return "column_validator"   # Verify column integrity
    elif trit == 0:  # ERGODIC (neutral 60-180°)
        return "coordinator"        # Route reconstruction requests
    else:            # PLUS (warm hues 0-60°, 300-360°)
        return "row_validator"      # Verify row integrity
```

### Tripartite Fragment Streams

```
Block B with commitment C:

                 ┌─── MINUS (-1): Column fragments ───┐
                 │     Validators verify C·E_col       │
    G·B → E ─────┼─── ERGODIC (0): Coordinators ──────┼─── Reconstruct B
                 │     Route DAS sampling              │
                 └─── PLUS (+1): Row fragments ───────┘
                       Validators verify C·E_row

Conservation: Σ trits ≡ 0 (mod 3) across validator set
```

### Fragment Color Visualization

```
from gay import SplitMixTernary

gen = SplitMixTernary(seed=0x42D)

# Visualize fragment assignment
for i, fragment in enumerate(extended_block):
    color = gen.color_at(i)
    print(f"Fragment {i}: {color['hex']} trit={color['trit']}")

# Output:
# Fragment 0: #D8267F trit=+1 (row validator)
# Fragment 1: #2CD826 trit=0  (coordinator)
# Fragment 2: #267FD8 trit=-1 (column validator)
# ...
```

### Byzantine Detection via Color Mismatch

```python
def verify_fragment(validator_id: int, fragment: bytes, commitment: bytes) -> bool:
    expected_color = gen.color_at(validator_id)
    actual_role = detect_fragment_type(fragment)
    
    # Honest: color-assigned role matches actual fragment type
    # Byzantine: mismatch triggers filtering
    role_match = (
        (expected_color['trit'] == -1 and actual_role == 'column') or
        (expected_color['trit'] == 0 and actual_role == 'coord') or
        (expected_color['trit'] == +1 and actual_role == 'row')
    )
    
    commitment_valid = verify_kzg_opening(fragment, commitment)
    return role_match and commitment_valid
```

---

---

## Deterministic Color Loading

Seed-based color generation for transaction visualization using SplitMix64:

```python
# GF(3) primitives from transcript_aqua.bb pattern
GOLDEN = 0x9E3779B97F4A7C15
MIX = 0xBF58476D1CE4E5B9

def chain_seed(current_seed: int, trit: int) -> int:
    """Derive next seed from current + trit. Replaces temporal succession."""
    return ((current_seed ^ (trit * (GOLDEN & 0xFFFF))) ^ (current_seed >> 16)) * 0x85ebca6b

def seed_to_color(seed: int) -> str:
    """Derive deterministic hex color from seed."""
    z = ((seed ^ (seed >> 30)) * 0xBF58476D1CE4E5B9)
    z = ((z ^ (z >> 27)) * 0x94D049BB133111EB)
    z = z ^ (z >> 31)
    r = (z >> 16) & 0xFF
    g = (z >> 8) & 0xFF
    b = z & 0xFF
    return f"#{r:02X}{g:02X}{b:02X}"
```

### Transaction Color Assignment

```python
from gay import SplitMixTernary

gen = SplitMixTernary(seed=0x42D)

def color_transaction(tx_hash: str) -> dict:
    """Assign GF(3) trit and color to transaction."""
    seed = hash(tx_hash) & 0xFFFFFFFFFFFFFFFF
    color = gen.color_at(seed)
    
    if color['trit'] == 1:   # PLUS (warm hues)
        return {"type": "execute", "color": color['hex'], "action": "fire"}
    elif color['trit'] == 0: # ERGODIC (neutral)
        return {"type": "simulate", "color": color['hex'], "action": "verify"}
    else:                    # MINUS (cold hues)
        return {"type": "validate", "color": color['hex'], "action": "check"}
```

---

## Reverse-Engineered Skill Loading

Skill loading paths discovered via codebase analysis (MINUS -1 validation):

```clojure
;; From transcript_aqua.bb - skill lookup paths
(def skill-dirs
  ["./.agents/skills"  ; Local project skills first
   (str (System/getProperty "user.home") "/.agents/skills")
   (str (System/getProperty "user.home") "/.claude/skills")
   (str (System/getProperty "user.home") "/.amp/skills")
   "./skills"])

(defn find-skill [skill-name]
  "Find SKILL.md for a given skill name."
  (some (fn [dir]
          (let [path (str dir "/" skill-name "/SKILL.md")]
            (when (fs/exists? path)
              {:path path :name skill-name :dir dir})))
        skill-dirs))
```

### Skill Triad Loading

```clojure
(defn load-skill-triad [minus-skill ergodic-skill plus-skill]
  "Load a GF(3)-balanced skill triad. Sum of trits must equal 0."
  (let [skills [{:skill minus-skill :expected-trit -1}
                {:skill ergodic-skill :expected-trit 0}
                {:skill plus-skill :expected-trit 1}]
        loaded (for [{:keys [skill expected-trit]} skills]
                 (let [found (find-skill skill)
                       parsed (when found (parse-skill-md (:path found)))]
                   (merge {:name skill :trit expected-trit} found parsed)))
        trit-sum (reduce + (map :expected-trit loaded))]
    {:skills loaded
     :trit-sum trit-sum
     :gf3-conserved? (zero? (mod trit-sum 3))
     :adjunction {:unit "catalog → loaded"
                  :counit "loaded → execution"}}))

;; Example: Load aptos skill triad
;; (load-skill-triad "reverse-engineer" "transcript-aqua" "aptos-agent")
```

---

## Related Skills

- `aptos-trading` - Alpha executor trading scripts (trit=+1)
- `reverse-engineer` - Protocol analysis (trit=-1)
- `transcript-aqua` - Audio extraction coordinator (trit=0)
- `acsets-algebraic-databases` - ACSet schemas for Aptos data
- `gay-mcp` - Deterministic color generation
- `spi-parallel-verify` - GF(3) conservation verification
