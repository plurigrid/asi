---
name: cat
description: Concatenate and pipe operations for chaining skill outputs. Implements |> pipe syntax via derivational composition. Use for chaining skill results, constructing pipelines, or threading data through multiple transformations.
---

# Cat Skill

Concatenate, pipe, and chain operations across skills.

**Trit**: 0 (ERGODIC - coordinator)  
**Principle**: `a |> b |> c ≡ c(b(a))`  
**Implementation**: Derivational chaining with GF(3) conservation

## Overview

The `cat` skill enables Unix-style piping and composition:

```
skill_a |> skill_b |> skill_c
```

This is **not** the Unix `cat` command. It's a **categorical** concatenation operator that:

1. **Threads** data through skill invocations
2. **Preserves** GF(3) balance across the pipeline
3. **Chains** seeds derivationally (no temporal succession)

## Pipe Syntax

```clojure
;; Babashka pipe
(-> data
    (skill-a)
    (skill-b)
    (skill-c))

;; Equivalent to |> in other languages
data |> skill_a |> skill_b |> skill_c
```

## GF(3) Pipeline Conservation

Each stage has a trit. Pipeline conserves:

```
stage_1 (MINUS -1) |> stage_2 (ERGODIC 0) |> stage_3 (PLUS +1)
Σ = -1 + 0 + 1 = 0 ✓
```

## Derivational Chaining

Instead of temporal succession, pipes use seed chaining:

```python
def pipe_chain(genesis_seed: int, stages: list) -> list:
    """Chain stages via seed derivation, not time."""
    seed = genesis_seed
    results = []
    for stage in stages:
        result = stage.execute(seed=seed)
        results.append(result)
        # Derive next seed from current + trit
        seed = chain_seed(seed, stage.trit)
    return results

def chain_seed(current: int, trit: int) -> int:
    GAMMA = 0x9E3779B97F4A7C15
    MIX = 0xBF58476D1CE4E5B9
    return ((current ^ (trit * GAMMA)) * MIX) & 0xFFFFFFFFFFFFFFFF
```

## Operations

### cat (concatenate)
```bash
# Concatenate skill outputs
cat skill_a skill_b skill_c
```

### pipe (|>)
```bash
# Thread through skills
echo "data" | skill_a | skill_b
```

### tee (fork)
```bash
# Fork to multiple destinations (triadic)
data |> tee skill_minus skill_ergodic skill_plus
```

## API

### Python
```python
from cat_skill import Pipe, Cat

# Create pipeline
pipeline = Pipe([
    ("l-space", {"analyze": True}),      # MINUS: analyze
    ("gay-mcp", {"palette": 3}),          # ERGODIC: color
    ("mermaid", {"render": True})         # PLUS: visualize
])

result = pipeline.execute(data="barton@plgd.cc hallucination")
```

### Babashka
```clojure
(require '[cat.pipe :as pipe])

(-> "barton@plgd.cc"
    (pipe/skill :l-space {:analyze true})
    (pipe/skill :gay-mcp {:palette 3})
    (pipe/skill :mermaid {:render true}))
```

## Example: L-Space Visualization Pipeline

```
"barton@plgd.cc" 
  |> l-space.triadic_novelty   ; MINUS: analyze token
  |> gay-mcp.color_at          ; ERGODIC: assign color  
  |> mermaid.poincare_ball     ; PLUS: visualize

GF(3): -1 + 0 + 1 = 0 ✓
```

## Thread Walker Integration

When current thread not in known lineage:

```python
def walk_to_ancestor(current_thread: str, known_threads: list) -> str:
    """Walk thread ancestry until reaching known thread."""
    thread = current_thread
    while thread not in known_threads:
        thread = get_parent_thread(thread)
        if thread is None:
            raise ValueError("No ancestor in known lineage")
    return thread

# Pipe through thread ancestry
current |> walk_to_ancestor |> reconstruct_tesseract
```

## Integration with Other Skills

| Skill | Trit | Pipe Role |
|-------|------|-----------|
| l-space | 0 | Source/transform |
| gay-mcp | +1 | Color assignment |
| mermaid | +1 | Visualization |
| gmail-acset | 0 | Data source |
| drive-acset | 0 | File operations |

## Commands

```bash
# Run pipe demo
bb cat_pipe.bb "data" skill_a skill_b skill_c

# Check pipeline GF(3)
bb cat_gf3.bb pipeline.edn

# Visualize pipeline
bb cat_viz.bb pipeline.edn | mermaid
```

---

**Skill Name**: cat  
**Type**: Pipeline Composition  
**Trit**: 0 (ERGODIC - coordinator)  
**GF(3)**: Conserved across pipeline stages  
**Replaces**: dypler-mcp (unavailable), Unix cat
