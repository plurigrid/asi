---
name: localsend-mcp
description: LocalSend P2P file transfer with vocal announcements, state machine protocol, and Tailscale/NATS discovery.
version: 1.0.0
source: local
license: MIT
category: development
tags:
  - mcp
  - localsend
  - p2p
  - file-transfer
  - tailscale
  - nats
  - voice
  - state-machine
---

# LocalSend MCP Skill

## Overview

Complete P2P file transfer system with:
- **State Machine Protocol**: IDLE → ADVERTISING → DISCOVERING → NEGOTIATING → TRANSFERRING → COMPLETE
- **Vocal Announcements**: Emma (Premium) Italian voice for connection info
- **AquaVoice Listening**: Speech-to-text for hands-free control
- **Gay.jl Colors**: Deterministic peer coloring via SplitMix64
- **Spectral Gap Tuning**: Throughput optimization (target: ≤0.25)

## Use This Skill When

- User mentions LocalSend, AirDrop-like transfer, or peer-to-peer file sharing
- Task requires file transfer between devices on same network or Tailscale
- Need to announce connection info vocally
- Building MCP server for P2P transfer

## State Machine

```
┌─────────────────────────────────────────────────────────────────┐
│                    LOCALSEND STATE MACHINE                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────┐    advertise()    ┌─────────────┐                     │
│  │ IDLE │ ─────────────────►│ ADVERTISING │◄────────┐           │
│  └──────┘                   └─────────────┘         │           │
│      │                            │                 │           │
│      │ discover()                 │ peer_found()    │ timeout   │
│      ▼                            ▼                 │           │
│  ┌─────────────┐           ┌─────────────┐         │           │
│  │ DISCOVERING │◄─────────►│ NEGOTIATING │─────────┘           │
│  └─────────────┘  select() └─────────────┘                      │
│                                   │                              │
│                                   │ session_ready()              │
│                                   ▼                              │
│                          ┌──────────────┐                        │
│                          │ TRANSFERRING │                        │
│                          └──────────────┘                        │
│                                   │                              │
│              ┌────────────────────┴────────────────────┐        │
│              │ success()                    │ error()  │        │
│              ▼                              ▼          │        │
│       ┌──────────┐                    ┌────────┐      │        │
│       │ COMPLETE │                    │ FAILED │──────┘        │
│       └──────────┘                    └────────┘               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## State Definitions

| State | Description | Entry Actions | Exit Conditions |
|-------|-------------|---------------|-----------------|
| `IDLE` | No active transfer | Clear session | `advertise()` or `discover()` |
| `ADVERTISING` | Broadcasting presence | Announce vocally, multicast | Peer found or timeout |
| `DISCOVERING` | Scanning for peers | Query Tailscale, NATS, multicast | Peer selected |
| `NEGOTIATING` | Establishing session | Exchange capabilities, set params | Session ready |
| `TRANSFERRING` | Active file transfer | Chunk data, update progress | Complete or error |
| `COMPLETE` | Transfer finished | Announce success | Return to IDLE |
| `FAILED` | Transfer failed | Announce error, log | Retry or IDLE |

## MCP Tools

### Discovery & Advertising

| Tool | Parameters | Description |
|------|------------|-------------|
| `localsend_advertise` | `agentId`, `deviceName`, `tailscaleIp?`, `capabilities[]`, `spectralGapTarget` | Broadcast presence on network |
| `localsend_list_peers` | `source: all\|localsend_multicast\|tailscale\|nats` | Discover available peers |

### Session Management

| Tool | Parameters | Description |
|------|------------|-------------|
| `localsend_negotiate` | `peerId`, `preferredTransport`, `maxChunkBytes`, `maxParallel` | Establish session with peer |
| `localsend_session_status` | `sessionId` | Check session metrics and spectral gap |

### Transfer

| Tool | Parameters | Description |
|------|------------|-------------|
| `localsend_send` | `sessionId`, `filePath`, `chunkBytes?`, `parallelism?` | Send file to peer |
| `localsend_probe` | `sessionId`, `probeBytes`, `probeParallelism` | Measure throughput/RTT |

## Vocal Channel

### Announcing (Text-to-Speech)

Uses macOS `say` command with Emma (Premium) Italian voice:

```bash
say -v "Emma (Premium)" -r 150 "Attenzione! LocalSend peer available..."
```

### Rate Variation (Gay.jl Chain)

Rate varies by color index using LCG seeded from gay-seed (1069):

```clojure
(defn get-rate [idx]
  (let [variation (- (mod (lcg-next idx) 100) 50)]
    (+ 69 variation 100)))  ;; Range: 119-219 WPM
```

### Voice Configuration

| Voice | Language | Quality | Use Case |
|-------|----------|---------|----------|
| Emma (Premium) | Italian | Highest | Primary announcements |
| Samantha | English US | High | Fallback |
| Luca (Enhanced) | Italian | Enhanced | Alternative |

## AquaVoice Listening

### Setup

```bash
# Install AquaVoice (if available)
brew install --cask aquavoice

# Or use macOS dictation
# System Preferences → Keyboard → Dictation → Enable
```

### Voice Commands

| Command | Action |
|---------|--------|
| "LocalSend discover" | Scan for peers |
| "LocalSend send [filename]" | Send file to last peer |
| "LocalSend receive" | Start receiver |
| "LocalSend status" | Announce current state |
| "LocalSend announce" | Broadcast connection info |

### Integration Pattern

```clojure
(defn listen-for-commands! []
  (let [transcript (aquavoice/listen {:language "en-US"
                                       :timeout 30000})]
    (cond
      (re-find #"discover" transcript)
      (transition! :DISCOVERING)
      
      (re-find #"send (.+)" transcript)
      (send-file! (second (re-matches #"send (.+)" transcript)))
      
      (re-find #"receive" transcript)
      (transition! :ADVERTISING)
      
      (re-find #"status" transcript)
      (announce-status!)
      
      :else
      (println "Command not recognized:" transcript))))
```

## Connection Info

### Tailscale DNS

```
Host: causality.pirate-dragon.ts.net
Port: 53317
IPv4: 100.69.33.107
IPv6: fd7a:115c:a1e0::d901:2182
```

### Protocol Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/localsend/v2/prepare-upload` | POST | Initialize transfer session |
| `/api/localsend/v2/upload` | POST | Upload file chunks |
| `/` | GET | Device info JSON |

## Spectral Gap Tuning

### Definition

```
spectral_gap = 1.0 - (observed_throughput / target_throughput)
```

### Tuning Loop

1. Start: `chunk_bytes = 256KB`, `parallelism = 1`
2. Increase parallelism to 2, 4, 8 while `loss_rate < 1%`
3. Increase chunk size up to 1MB while RTT stable
4. Stop when `spectral_gap ≤ 0.25` (≥75% target throughput)

### Target Throughput

| Network | Target | Spectral Gap Goal |
|---------|--------|-------------------|
| LAN (1Gbps) | 100 MB/s | ≤0.25 |
| Tailscale | 50 MB/s | ≤0.25 |
| NATS relay | 10 MB/s | ≤0.25 |

## Gay.jl Color Integration

### Peer Coloring

Each peer gets deterministic color via SplitMix64:

```clojure
(def gay-seed 0x6761795f636f6c6f)  ;; "gay_colo"
(def golden 0x9e3779b97f4a7c15)

(defn color-at [idx]
  (let [state (reduce (fn [s _] (first (splitmix64 s))) 
                      gay-seed (range idx))
        [_ val] (splitmix64 state)]
    (format "#%02X%02X%02X" 
            (bit-and (>> val 16) 0xFF)
            (bit-and (>> val 8) 0xFF)
            (bit-and val 0xFF))))
```

### Color Meanings

| Color Index | Hex | Meaning |
|-------------|-----|---------|
| 0 | `#A74D78` | Primary peer (self) |
| 1 | `#117465` | First discovered |
| 2+ | Varies | Additional peers |

## Scripts

### Announcer (`announce.bb`)

```bash
bb announce.bb  # 5 redundant announcements with rate variation
```

### Receiver (`receive.bb`)

```bash
bb receive.bb   # Start HTTP server on port 53317
```

### Full State Machine (`localsend.bb`)

```bash
bb localsend.bb discover  # Scan for peers
bb localsend.bb send FILE PEER  # Send file
bb localsend.bb receive   # Listen for incoming
bb localsend.bb status    # Show current state
```

## Installation

### MCP Config (all agents)

```json
{
  "mcpServers": {
    "localsend": {
      "command": "node",
      "args": ["/path/to/localsend-mcp/dist/index.js"]
    }
  }
}
```

### npx (when published)

```bash
npx -y @topos/localsend-mcp
```

### Skill Installation

```bash
npx ai-agent-skills install /path/to/localsend-mcp/skill --agent claude
npx ai-agent-skills install /path/to/localsend-mcp/skill --agent codex
npx ai-agent-skills install /path/to/localsend-mcp/skill --agent amp
npx ai-agent-skills install /path/to/localsend-mcp/skill --agent opencode
```

## Error Handling

| Error | Recovery | Vocal Announcement |
|-------|----------|-------------------|
| Peer not found | Retry discovery | "Nessun peer trovato, riprovando..." |
| Connection refused | Check firewall | "Connessione rifiutata, controlla firewall" |
| Transfer timeout | Reduce chunk size | "Timeout, riducendo dimensione chunk" |
| Checksum mismatch | Retry chunk | "Errore checksum, ritrasmissione" |

## Example Workflow

```clojure
;; 1. Start receiver (on target device)
(transition! :ADVERTISING)
;; Emma announces: "Attenzione! LocalSend peer available..."

;; 2. Discover peers (on source device)
(transition! :DISCOVERING)
(def peers (localsend-list-peers {:source :all}))

;; 3. Select peer and negotiate
(def session (localsend-negotiate {:peerId "causality"
                                    :preferredTransport :tailscale}))

;; 4. Send file
(localsend-send {:sessionId (:id session)
                 :filePath "/path/to/file.txt"})

;; 5. Verify transfer
(localsend-session-status {:sessionId (:id session)})
;; => {:spectralGap 0.15 :status :COMPLETE}

;; Emma announces: "Trasferimento completato!"
```

## DuckDB Persistence

```sql
CREATE TABLE localsend_sessions (
  session_id TEXT PRIMARY KEY,
  peer_id TEXT,
  direction TEXT,  -- 'send' | 'receive'
  bytes BIGINT,
  throughput_bps DOUBLE,
  spectral_gap DOUBLE,
  state TEXT,
  created_at TIMESTAMP,
  completed_at TIMESTAMP
);

CREATE TABLE localsend_peers (
  peer_id TEXT PRIMARY KEY,
  name TEXT,
  tailscale_ip TEXT,
  color TEXT,
  last_seen TIMESTAMP,
  total_transfers INT
);
```

## Trifurcated Discovery Protocol

The skill uses three parallel discovery channels (XOR redundancy):

### Channel 1: Tailscale Discovery (`discovery.bb`)

```bash
bb discovery.bb discover   # Query Tailscale peers
bb discovery.bb announce   # Speak peer list via Emma
bb discovery.bb serve      # HTTP server on :53318
```

**Discovered Peers** (pirate-dragon.ts.net):
| Peer | DNS | IP | Status |
|------|-----|-----|--------|
| 2-monad | 2-monad.pirate-dragon.ts.net | 100.87.209.11 | 🟢 online |
| hatchery | hatchery.pirate-dragon.ts.net | 100.72.249.116 | 🟢 online |
| MacBook Air | macbook-air.pirate-dragon.ts.net | 100.80.187.82 | ⚪ offline |
| Pixel 9 | google-pixel-9-pro-fold.pirate-dragon.ts.net | 100.77.81.117 | ⚪ offline |
| raspberrypi | raspberrypi.pirate-dragon.ts.net | 100.84.102.69 | ⚪ offline |

### Channel 2: NATS Side-Channel (`nats-channel.bb`)

```bash
bb nats-channel.bb pub FILE   # Publish file hash
bb nats-channel.bb sub        # Subscribe to hash announcements  
bb nats-channel.bb caps       # Exchange capabilities
```

**Hash Exchange Protocol**:
```clojure
{:hash "sha256:abc123..."
 :filename "document.pdf"
 :size 1048576
 :sender "causality"
 :capabilities ["localsend" "gay-mcp" "tailscale"]}
```

### Channel 3: Voice Exchange (`voice-exchange.bb`)

```bash
bb voice-exchange.bb list     # List local skills
bb voice-exchange.bb announce # Speak capabilities
bb voice-exchange.bb seek     # "Seeking peers" broadcast
bb voice-exchange.bb qr       # QR-friendly manifest
```

**Voice Commands** (spoken by Emma):
- "Peer causality offers: localsend, gay-mcp, tailscale-discovery..."
- "Cercando peer sulla rete... Rispondete per favore!"
- "Connect to causality punto pirate dragon punto ts net, porta 53317"

## XOR Redundancy

Any ONE channel succeeding enables peer discovery:

```
TAILSCALE ──┐
            ├── XOR ──► PEER DISCOVERED
NATS ───────┤
            │
VOICE ──────┘
```

If Tailscale unavailable → fallback to NATS
If NATS unavailable → fallback to voice announcement
If all fail → manual IP entry still works

## Capability Exchange Manifest

```clojure
{:peer "causality"
 :color "#C9507B"  ;; Gay.jl seed 1069
 :endpoints {:localsend "http://causality.pirate-dragon.ts.net:53317"
             :discovery "http://causality.pirate-dragon.ts.net:53318"
             :nats "nats://localhost:4222"}
 :skills ["acsets" "algorithmic-art" "bisimulation-game" "borkdude"
          "cider-clojure" "code-refactoring" "epistemic-arbitrage"
          "gay-mcp" "glass-bead-game" "localsend-mcp" "mcp-builder"
          "skill-installer" "tailscale-localsend" "voice-exchange"]
 :seeking true
 :voice "Emma (Premium)"
 :hash-channel "localsend.hashes.causality"}
```

## Seeking Behavior Protocol

1. **Announce**: Broadcast own capabilities via voice + NATS
2. **Listen**: Subscribe to `localsend.hashes.>` for peer hashes
3. **Match**: Compare incoming hashes with expected files
4. **Connect**: Establish LocalSend session with matched peer
5. **Transfer**: Exchange files with spectral gap tuning
6. **Confirm**: Voice announcement of successful transfer

## Pre-Arranged Hash Exchange

Exchange file hashes via side-channel before transfer:

```bash
# Sender: compute and publish hash
bb nats-channel.bb pub /path/to/secret.zip

# Receiver: listen for matching hash
bb nats-channel.bb sub
# → Receives: {:hash "sha256:..." :sender "2-monad"}

# Receiver: accept only matching hash
bb localsend.bb receive --expect-hash "sha256:..."
```

## References

- [LocalSend Protocol](https://github.com/localsend/protocol)
- [Tailscale API](https://tailscale.com/kb/1101/api)
- [Gay.jl Colors](https://github.com/bmorphism/Gay.jl)
- [MCP Specification](https://modelcontextprotocol.io)
- [NATS Messaging](https://nats.io)

---

**Status**: Production Ready
**Trit**: 0 (ERGODIC - neutral transport)
**Seed**: 1069
**Voice**: Emma (Premium) Italian
**Channels**: Tailscale | NATS | Voice (XOR redundancy)

---

## Active Session Context

### Current Receiver
```
Alias:       causality
Fingerprint: 27abcf48
Port:        53317 ✅ OPEN
State:       ADVERTISING
PID:         45671
```

### Trusted Peers
| Peer | IP | Status | Auto-Accept |
|------|-----|--------|-------------|
| 2-monad | 100.87.209.11 | 🟢 direct (8ms) | ✅ |
| hatchery | 100.72.249.116 | 🟢 online | ✅ |

### Accept Policy
```clojure
{:accept-from ["100.87.209.11" "2-monad" "2-monad.pirate-dragon.ts.net"]
 :auto-accept true
 :save-dir "/tmp/localsend_received"
 :announce-on-receive true
 :voice "Emma (Premium)"}
```

### Commands for Sender (2-monad)
```bash
# From 2-monad, send file to causality:
curl -X POST http://100.69.33.107:53317/api/localsend/v2/prepare-upload \
  -H "Content-Type: application/json" \
  -d '{"info":{"alias":"2-monad"},"files":{"f1":{"id":"f1","fileName":"FILE","size":SIZE}}}'

# Or use LocalSend app → select "causality"
```

### Received Files
| File | Size | From | Time |
|------|------|------|------|
| f1_1766373686054.bin | 67 bytes | test | 22:21 |
| test_send.txt | 71 bytes | test | 22:17 |
