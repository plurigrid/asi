# Aptos Society Scale

**Trit**: 0 (ERGODIC - coordinator)
**Domain**: Compositional Game Theory × Blockchain Governance × Social Interaction Labs

## Orderless Transaction Parallelism (AIP-123/129)

Aptos's **Orderless Transactions** enable true parallel execution by replacing sequence numbers with unique nonces. This maps directly to GF(3) triadic parallelism:

```
┌─────────────────────────────────────────────────────────────────┐
│  SEQUENCE-NUMBER MODEL (OLD)           ORDERLESS MODEL (NEW)    │
│  ─────────────────────────             ─────────────────────    │
│  tx₀ → tx₁ → tx₂ → tx₃                 tx₀ ─┐                   │
│  (strictly sequential)                 tx₁ ─┼─→ PARALLEL        │
│                                        tx₂ ─┘   EXECUTION       │
│                                                                 │
│  GF(3) Mapping:                                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                      │
│  │ MINUS    │  │ ERGODIC  │  │ PLUS     │                      │
│  │ nonce: N │  │ nonce: M │  │ nonce: P │  → Execute in        │
│  │ validate │  │ coordinate│  │ generate │    parallel!         │
│  └──────────┘  └──────────┘  └──────────┘                      │
│        │             │             │                            │
│        └─────────────┼─────────────┘                            │
│                      │                                          │
│              Σ trits = 0 ✓                                      │
└─────────────────────────────────────────────────────────────────┘
```

### Key Properties

| Feature | Sequence-Number | Orderless |
|---------|-----------------|-----------|
| Replay protection | Counter increment | Unique 64-bit nonce |
| Parallelism | Sequential only | Full parallel |
| Gas (first tx) | ~510 units | ~57 units |
| Account state | Stateful required | Stateless OK |

### Cost Savings at Scale

```
1M users:  $2,500 saved
1B users:  $2.5M saved
```

### Nonce Replay Protection

```
if (address, nonce) is NEW → accept tx
if (address, nonce) exists → reject as duplicate
old nonces expire after safety window
```

## Academic Foundations

### Seth Frey (UC Davis, Ostrom Workshop)
- **Composing Games into Complex Institutions** (PLoS ONE 2023)
- Institutional preferences laboratory experiments
- Game-theoretic institutional design with Jules Hedges

### Michael Zargham (BlockScience)  
- **Computer-Aided Governance** - cadCAD simulation framework
- Token Engineering Academy foundations
- Cryptoeconomic mechanism design

### Jules Hedges (Strathclyde)
- **Open Games** - categorical game theory
- String diagram representations for institutions
- Compositional approach to strategic interaction

## GF(3) Triadic Skill Forcing

Every interaction MUST load exactly 3 skills with balanced trits:

```
MINUS (-1): Validator/Constrainer (cold hues 180-300°)
ERGODIC (0): Coordinator/Synthesizer (neutral hues 60-180°)  
PLUS (+1): Generator/Executor (warm hues 0-60°, 300-360°)

Conservation: Σ trits ≡ 0 (mod 3)
```

## Aptos World Wallets (26 Letters)

| Segment | Letters | Trit | Role |
|---------|---------|------|------|
| MINUS | A-I (9) | -1 | Validators |
| ERGODIC | J-R (9) | 0 | Coordinators |
| PLUS | S-Z (8) | +1 | Executors |

## MCP Tools

```
mcp__world_{letter}_aptos__aptos_balance
mcp__world_{letter}_aptos__aptos_transfer
mcp__world_{letter}_aptos__aptos_swap
mcp__world_{letter}_aptos__aptos_view
```

## Derangement Protocol

For seed handoff between world segments:
1. XOR all addresses in segment → segment_seed
2. Maximum Hamming distance reordering
3. Sparsification for collision resistance

## Strong Parallelism Invariance (SPI)

Orderless transactions enable **SPI** — the guarantee that parallel execution produces identical results regardless of order:

```
Execute(T₁, T₂, T₃) ≡ Execute(T₃, T₁, T₂) ≡ Execute(T₂, T₃, T₁)
```

### SPI + GF(3) Conservation

```clojure
;; Three parallel transactions from same account
(def triadic-batch
  [{:nonce (random-nonce) :trit -1 :action :validate}   ;; MINUS
   {:nonce (random-nonce) :trit  0 :action :coordinate} ;; ERGODIC
   {:nonce (random-nonce) :trit +1 :action :execute}])  ;; PLUS

;; SPI guarantees: order doesn't matter
;; GF(3) guarantees: (-1) + 0 + (+1) = 0 ✓
```

### Block-STM Integration

Aptos's Block-STM (Software Transactional Memory) detects conflicts:

```
Non-conflicting txs → parallel execution
Conflicting txs → optimistic retry with rollback
```

For 26 World wallets with independent accounts, **all transactions are non-conflicting** → maximum parallelism.

## Babashka/NBB Integration

```clojure
;; aptos_society.bb - Orderless parallel dispatch
(require '[babashka.process :refer [shell]])

(defn random-nonce []
  (rand-int Long/MAX_VALUE))

(defn world-balance [letter]
  (let [tool (str "mcp__world_" letter "_aptos__aptos_balance")]
    {:world letter :tool tool}))

(defn orderless-triadic-transfer
  "Execute 3 transfers in parallel using orderless transactions"
  [from-world to-worlds amounts]
  (let [txs (map (fn [to amt trit]
                   {:from from-world
                    :to to
                    :amount amt
                    :nonce (random-nonce)
                    :trit trit
                    :orderless true})
                 to-worlds amounts [-1 0 +1])]
    ;; All 3 execute in parallel - no sequence number blocking!
    {:parallel-batch txs
     :gf3-sum (reduce + (map :trit txs))}))

(defn triadic-worlds []
  {:minus (map world-balance "ABCDEFGHI")
   :ergodic (map world-balance "JKLMNOPQR")
   :plus (map world-balance "STUVWXYZ")})
```

## Swift Sendable Semantics (Orderless)

```swift
// AptosWorld with orderless transaction support
actor AptosWorld: Sendable {
    let letter: Character
    let trit: Int  // -1, 0, +1

    func balance() async -> Decimal

    // Orderless transfer - no sequence number required
    func orderlessTransfer(to: Address, amount: Decimal, nonce: UInt64) async throws
}

// Triadic parallel dispatch with orderless transactions
func dispatchOrderlessTriad(
    _ minus: AptosWorld,
    _ ergodic: AptosWorld,
    _ plus: AptosWorld
) async throws {
    // GF(3) conservation check
    assert(minus.trit + ergodic.trit + plus.trit == 0)

    // Generate unique nonces for each parallel tx
    let nonces = (0..<3).map { _ in UInt64.random(in: 0...UInt64.max) }

    // All three execute in TRUE parallel - no sequence blocking!
    try await withThrowingTaskGroup(of: Void.self) { group in
        group.addTask { try await minus.orderlessTransfer(to: minusTarget, amount: amt, nonce: nonces[0]) }
        group.addTask { try await ergodic.orderlessTransfer(to: ergTarget, amount: amt, nonce: nonces[1]) }
        group.addTask { try await plus.orderlessTransfer(to: plusTarget, amount: amt, nonce: nonces[2]) }
        try await group.waitForAll()
    }
}
```

## Ruler Enforcement

Add to `~/.ruler/AGENTS.md`:

```markdown
## Triadic Skill Forcing (Aptos Society Scale)

**Rule**: Every interaction loads 3 skills with Σ trits = 0 (mod 3)

1. MINUS skill: validation, constraint checking
2. ERGODIC skill: coordination, synthesis  
3. PLUS skill: generation, execution

Verify: `(-1) + 0 + (+1) = 0 ✓`
```

## References

### Aptos Improvement Proposals (AIPs)
- **AIP-115**: Stateless Accounts — defer account resource creation
- **AIP-123**: Orderless Transactions — nonce-based replay protection
- **AIP-129**: Orderless Transaction Authenticator — public key in authenticator

### Academic
- Frey et al. "Composing games into complex institutions" PLOS ONE 2023
- Zargham & Emmett "Computer-Aided Governance" BlockScience 2019
- Hedges "Towards compositional game theory" PhD Thesis 2016
- Ostrom "Understanding institutional diversity" Princeton 2005

### Technical
- Aptos Block-STM: Software Transactional Memory for parallel execution
- Aptos Labs "Stateless Accounts and Orderless Transactions" Medium 2025

## NO PRIVATE INFORMATION

This skill contains NO private keys, wallet addresses, or secrets.
All wallet interactions go through MCP tools with approval flows.
