---
name: shadow-goblin
trit: -1
auto-generated: true
---

# shadow-goblin

Auto-generated skill placeholder.
