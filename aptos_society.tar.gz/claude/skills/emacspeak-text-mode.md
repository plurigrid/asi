---
skill: emacspeak-text-mode
description: Help users with Emacspeak Text-First Mode - semantic Emacs with text output and optional audio
version: 1.0.0
author: Claude
tags: [emacs, emacspeak, accessibility, text-mode, audio]
---

# Emacspeak Text-First Mode Skill

## Context

Emacspeak is installed at `~/emacspeak/` with a custom text-first configuration that:
- **Primary output**: Text to echo area/minibuffer (not audio)
- **Audio**: Disabled by default, toggle with `C-c e a`
- **Semantic awareness**: Preserved from Emacspeak
- **Configuration**: `~/.emacs.d/emacspeak-text-mode.el`
- **Documentation**: `~/emacspeak/TEXTMODE-SETUP.md`

## When to Use This Skill

Invoke this skill when the user asks about:
- Using Emacspeak in text mode
- Configuring Emacspeak text-first behavior
- Troubleshooting text output
- Customizing text-mode settings
- Enabling/disabling audio
- Understanding semantic features
- Text-based audio icon mappings
- **Launching Emacs with text-mode to navigate files**
- **Opening, editing, or analyzing files in Emacs**
- **Using Emacs commands for file operations**

## Key Paths

```
~/emacspeak/                           # Main installation
~/.emacs.d/emacspeak-text-mode.el     # Text-first configuration
~/emacspeak/TEXTMODE-SETUP.md         # User documentation
~/test-emacspeak-text.sh              # Quick test launcher
~/.local/bin/emacspeak-analyze        # File analyzer tool (for Claude)
```

## Helper Tools

### emacspeak-analyze (For Claude to use)

```bash
# Analyze any file with Emacspeak semantic detection
~/.local/bin/emacspeak-analyze /path/to/file

# Shows:
# - File path and detected mode (semantic!)
# - Line/word/character counts
# - First 20 lines of content
# - Text-mode enabled status
```

## Common Tasks

### Launch Emacspeak Text Mode

```bash
# Launch Emacs with text-mode (clean config)
emacs -Q -l ~/.emacs.d/emacspeak-text-mode.el

# Launch and open a specific file
emacs -Q -l ~/.emacs.d/emacspeak-text-mode.el /path/to/file.txt

# Launch in terminal mode (no GUI)
emacs -nw -Q -l ~/.emacs.d/emacspeak-text-mode.el

# Or use test script
~/test-emacspeak-text.sh

# Add to permanent config (edit ~/.emacs or ~/.emacs.d/init.el)
(load-file "~/.emacs.d/emacspeak-text-mode.el")
```

### File Navigation Commands (In Emacs)

**Opening Files:**
```
C-x C-f         # Find file (open/create)
C-x C-r         # Find file read-only
C-x d           # Open dired (directory editor)
C-x C-v         # Visit alternate file (replace current buffer)
```

**Buffer Management:**
```
C-x b           # Switch to buffer
C-x C-b         # List all buffers
C-x k           # Kill (close) buffer
C-x C-s         # Save current buffer
C-x s           # Save all modified buffers
```

**Navigation:**
```
C-n / C-p       # Next/previous line
C-f / C-b       # Forward/backward character
M-f / M-b       # Forward/backward word
C-a / C-e       # Beginning/end of line
M-< / M->       # Beginning/end of buffer
C-v / M-v       # Page down/up
```

**Search:**
```
C-s             # Incremental search forward
C-r             # Incremental search backward
M-x occur       # Show all lines matching pattern
M-x grep        # Search files
```

**Dired (Directory Navigation):**
```
RET             # Open file/directory
d               # Mark for deletion
x               # Execute deletions
C               # Copy file
R               # Rename/move file
g               # Refresh directory listing
```

### Check Current Configuration

```bash
# View text-mode config
cat ~/.emacs.d/emacspeak-text-mode.el

# Check if loaded in running Emacs (M-: in Emacs)
(featurep 'emacspeak-text-mode)

# View full documentation
cat ~/emacspeak/TEXTMODE-SETUP.md
```

### Toggle Audio On/Off

In Emacs:
- **Toggle**: `C-c e a`
- **Check status**: Look for message "📝 Text mode ENABLED" or "🔊 Audio mode ENABLED"

### Customize Text Output

Edit `~/.emacs.d/emacspeak-text-mode.el` to modify:

```elisp
;; Disable text icons (emoji/symbols)
(setq emacspeak-text-icons-enabled nil)

;; Change context format
(defun emacspeak-text-format-context ()
  (format "(%s:%d)" (buffer-name) (line-number-at-pos)))

;; Change audio toggle keybinding
(global-set-key (kbd "C-c t a") 'emacspeak-toggle-audio)
```

## Text Icon Mappings

When audio is disabled, these text symbols replace audio cues:

| Icon | Text Symbol | Meaning |
|------|-------------|---------|
| task-done | ✓ | Task completed |
| open-object | ↗ | Opening |
| close-object | ↙ | Closing |
| select-object | ◉ | Selected |
| delete-object | ⊗ | Deleted |
| warn-user | ⚠ | Warning |
| help | ? | Help |
| item | • | Item |
| scroll | ⇳ | Scroll |
| search-hit | ⊙ | Found |
| search-miss | ⊘ | Not found |

## Troubleshooting

### Messages Not Appearing

```elisp
;; Check echo area isn't suppressed
(setq inhibit-message nil)

;; Ensure messages are shown
(setq emacspeak-speak-messages t)
```

### Audio Won't Enable

```bash
# Check for TTS engines
which say      # macOS built-in
which espeak   # Linux/Unix

# Install espeak if needed (Linux)
sudo apt install espeak

# macOS has 'say' built-in, should work automatically
```

### Unicode Symbols Not Displaying

```elisp
;; Add to config
(set-language-environment "UTF-8")
(set-default-coding-systems 'utf-8)

;; Or disable text icons
(setq emacspeak-text-icons-enabled nil)
```

### Config Not Loading

```bash
# Verify file exists
ls -la ~/.emacs.d/emacspeak-text-mode.el

# Check Emacs can find it
emacs --batch -l ~/.emacs.d/emacspeak-text-mode.el --eval "(message \"Loaded!\")"

# Look for errors in *Messages* buffer (C-h e in Emacs)
```

## Advanced Customization

### Selective Audio by Mode

```elisp
;; Enable audio only in specific modes
(defun emacspeak-auto-audio-mode-hook ()
  "Enable audio in shell/compilation modes."
  (when (member major-mode '(shell-mode compilation-mode))
    (unless emacspeak-audio-enabled
      (emacspeak-toggle-audio))))

(add-hook 'after-change-major-mode-hook 'emacspeak-auto-audio-mode-hook)
```

### Custom Text Output Format

```elisp
;; Minimal output
(defun emacspeak-text-speak (text)
  (message "%s" text))  ; No emoji prefix

;; Verbose output with timestamp
(defun emacspeak-text-speak (text)
  (message "[%s] 🔊 %s" (format-time-string "%H:%M:%S") text))
```

### Logging Output

```elisp
;; Log all text output to file
(defvar emacspeak-text-log-file "~/emacspeak-log.txt")

(defun emacspeak-text-speak (text)
  (let ((msg (format "🔊 %s" text)))
    (message msg)
    (append-to-file (format "%s\n" msg) nil emacspeak-text-log-file)))
```

## Key Variables

```elisp
emacspeak-text-mode-enabled     ; t when text mode active
emacspeak-audio-enabled         ; t when audio mode active
emacspeak-text-icons-enabled    ; t to show text icons
dtk-quiet                       ; t to suppress speech
dtk-program                     ; TTS program path (nil when disabled)
```

## Response Guidelines

When helping users with Emacspeak text mode:

1. **Default assumption**: Audio is OFF, text is ON
2. **Check paths**: Verify files exist before suggesting edits
3. **Test changes**: Suggest `emacs -Q -l ~/.emacs.d/emacspeak-text-mode.el` for testing
4. **Preserve semantics**: Keep Emacspeak's intelligent behavior
5. **Explain text icons**: Users may not know what ✓ ⚠ ◉ mean
6. **Audio as optional**: Frame audio as "enable when needed" not "should be on"

## Example Output

When working correctly, users see:

```
🔊 [emacs-lisp-mode] L42:C15 | Define function emacspeak-toggle-audio
✓ Task completed
🔊 [org-mode] L1:C0 | Heading: Installation
• Item
⚠ Warning: Buffer modified but not saved
🔊 Saved ~/test.el
```

## Integration with Standard Emacspeak

The text-mode config preserves all standard Emacspeak features:

- `C-e` prefix - All Emacspeak commands work
- Semantic awareness - Knows what mode/context you're in
- Smart navigation - Context-aware movement
- Mode-specific behavior - Org, code, shell, etc.

Only the **output** is changed from audio to text.

## Quick Reference Commands

```elisp
;; Toggle audio/text mode
C-c e a

;; Reload config (in Emacs)
M-x load-file RET ~/.emacs.d/emacspeak-text-mode.el RET

;; Check if loaded
M-: (featurep 'emacspeak-text-mode) RET

;; View current mode status
M-: emacspeak-text-mode-enabled RET  ; t = text mode
M-: emacspeak-audio-enabled RET      ; t = audio mode
```

## Philosophy

This configuration embodies:
> **Emacspeak's intelligence + Text-first output + Audio on demand**

Not a screen reader, not pure audio - it's semantic interaction with text as the primary interface and optional audio enhancement.

## Resources

- Configuration: `~/.emacs.d/emacspeak-text-mode.el`
- User guide: `~/emacspeak/TEXTMODE-SETUP.md`
- Emacspeak upstream: https://github.com/tvraman/emacspeak
- Emacspeak manual: `C-e TAB` (in Emacs with Emacspeak loaded)

## How Claude Uses This Skill

### CRITICAL: Silent Operation by Default

**Run commands silently unless user explicitly asks to see output.**

- Use Bash tool normally but **do not** show raw command output to user
- Parse results internally
- Present findings in natural language
- Only show command/output if user requests: "show me the command" or "show output"

### When User Asks to Navigate Files

If user says "use emacspeak to open X" or "navigate to file Y":

1. **Run silently**: Execute emacspeak-analyze or emacs batch commands
2. **Parse results**: Extract mode, content, structure internally
3. **Report naturally**: Present findings in plain language
4. **No bash output**: Unless explicitly requested

### Interactive Session Pattern

```bash
# Launch in background or with limited interaction
emacs -nw -Q -l ~/.emacs.d/emacspeak-text-mode.el --batch \
  --eval "(find-file \"/path/to/file\")" \
  --eval "(message \"%s\" (buffer-string))"

# Or for interactive: launch and provide guidance
emacs -nw -Q -l ~/.emacs.d/emacspeak-text-mode.el /path/to/file
```

### Reading File Contents

To read a file using Emacspeak text-mode:

```bash
# Method 1: Batch mode (non-interactive)
emacs --batch -Q -l ~/.emacs.d/emacspeak-text-mode.el \
  --eval "(progn (find-file \"/path/to/file\") \
                 (message \"File: %s\\nLines: %d\\nContent:\\n%s\" \
                          (buffer-file-name) \
                          (count-lines (point-min) (point-max)) \
                          (buffer-string)))"

# Method 2: Launch interactively
emacs -nw -Q -l ~/.emacs.d/emacspeak-text-mode.el /path/to/file
# Then guide user with commands
```

### Providing File Analysis

When asked to analyze a file with Emacspeak:

1. **Use Read tool first** if just examining contents
2. **Use Emacs** if semantic analysis needed (syntax highlighting, mode detection)
3. **Explain Emacspeak's semantic understanding** of the file type

### Example Interaction

**User**: "Use emacspeak to navigate my .emacs file"

**Claude Response**:
```bash
# Launch Emacs with text-mode and your config
emacs -nw -Q -l ~/.emacs.d/emacspeak-text-mode.el ~/.emacs
```

Then explain:
- Emacspeak will show: `🔊 [emacs-lisp-mode] L1:C0 | ...`
- This tells you it detected Emacs Lisp mode (semantic awareness)
- Use C-s to search, M-< to go to beginning, M-> to go to end
- Text output will show context as you navigate

## Code Modification Guidelines

When user asks to modify the text-mode configuration:

1. **Read current config first**: Always read `~/.emacs.d/emacspeak-text-mode.el`
2. **Test changes**: Create test version or use `emacs -Q -l` to verify
3. **Preserve core logic**: Keep audio toggle, text output routing
4. **Document changes**: Add comments explaining modifications
5. **Backup**: Suggest backing up config before major changes

## Emacs Batch Mode Usage

For non-interactive file operations:

```bash
# Read file and show semantic info
emacs --batch -Q -l ~/.emacs.d/emacspeak-text-mode.el file.py \
  --eval "(message \"Mode: %s\" major-mode)"

# Search in file
emacs --batch -Q -l ~/.emacs.d/emacspeak-text-mode.el file.txt \
  --eval "(progn (goto-char (point-min)) \
                 (while (re-search-forward \"pattern\" nil t) \
                   (message \"Found at line %d\" (line-number-at-pos))))"

# Count lines/words
emacs --batch -Q -l ~/.emacs.d/emacspeak-text-mode.el file.txt \
  --eval "(message \"Lines: %d, Words: %d\" \
                   (count-lines (point-min) (point-max)) \
                   (count-words (point-min) (point-max)))"
```

## Common User Requests

### "Make it more verbose"
Add context, timestamps, buffer info to text output

### "Make it quieter"
Remove emoji prefixes, minimize output

### "Audio for errors only"
Selective audio based on message type/priority

### "Log everything"
Append text output to file

### "Change keybinding"
Modify `global-set-key` for toggle command

### "Different TTS engine"
Set `dtk-program` to preferred engine path

## End of Skill

This skill provides comprehensive guidance for Emacspeak Text-First Mode usage and customization.
